import os
import subprocess
import pandas as pd
import io
import time
import shutil
import yaml
from copy import deepcopy


DTYPE = {'bf16_r': 'B',
         'f32_r': 'S',
         'f16_r': 'H',
         'f8_r': 'F8'}

MAP = {
    'BBS_NT': 'Cijk_Ailk_Bjlk_BBS_BH_BiasSB_HAS_SAV_UserArgs.yaml',
    'BBS_NN': 'Cijk_Ailk_Bljk_BBS_BH_BiasSB_HAS_SAV_UserArgs.yaml',
    'BBS_TT': 'Cijk_Alik_Bjlk_BBS_BH_BiasSB_HAS_SAV_UserArgs.yaml',
    'BBS_TN': 'Cijk_Alik_Bljk_BBS_BH_BiasSB_HAS_SAV_UserArgs.yaml',
    'HHS_NT': 'Cijk_Ailk_Bjlk_HHS_BH_BiasSH_HAS_SAV_UserArgs.yaml',
    'HHS_NN': 'Cijk_Ailk_Bljk_HHS_BH_BiasSH_HAS_SAV_UserArgs.yaml',
    'HHS_TT': 'Cijk_Alik_Bjlk_HHS_BH_BiasSH_HAS_SAV_UserArgs.yaml',
    'HHS_TN': 'Cijk_Alik_Bljk_HHS_BH_BiasSH_HAS_SAV_UserArgs.yaml',
    'S_NT': 'Cijk_Ailk_Bjlk_S_B_BiasS_HAS_SAV_UserArgs.yaml',
    'S_NN': 'Cijk_Ailk_Bljk_S_B_BiasS_HAS_SAV_UserArgs.yaml',
    'S_TT': 'Cijk_Alik_Bjlk_S_B_BiasS_HAS_SAV_UserArgs.yaml',
    'S_TN': 'Cijk_Alik_Bljk_S_B_BiasS_HAS_SAV_UserArgs.yaml',
    'SSS_NT': 'Cijk_Ailk_Bjlk_S_B_BiasS_HAS_SAV_UserArgs.yaml',
    'SSS_NN': 'Cijk_Ailk_Bljk_S_B_BiasS_HAS_SAV_UserArgs.yaml',
    'SSS_TT': 'Cijk_Alik_Bjlk_S_B_BiasS_HAS_SAV_UserArgs.yaml',
    'SSS_TN': 'Cijk_Alik_Bljk_S_B_BiasS_HAS_SAV_UserArgs.yaml',
    'F8BS_NT': 'Cijk_Ailk_Bjlk_F8BS_BH_BiasSB_HAS_SAB_SAV_UserArgs.yaml',
    'F8BS_NN': 'Cijk_Ailk_Bljk_F8BS_BH_BiasSB_HAS_SAB_SAV_UserArgs.yaml',
    'F8BS_TT': 'Cijk_Alik_Bjlk_F8BS_BH_BiasSB_HAS_SAB_SAV_UserArgs.yaml',
    'F8BS_TN': 'Cijk_Alik_Bljk_F8BS_BH_BiasSB_HAS_SAB_SAV_UserArgs.yaml',
}

MERGE_COLS = ['transA', 'transB', 'batch_count', 'm', 'n', 'k', 'a_type', 'c_type', 'compute_type']


def run_hipblaslt_bench(hipblaslt_path, bench_file, output_file, device=0):
    hipblaslt_bench = os.path.join(hipblaslt_path, 'build/release/clients/hipblaslt-bench')
    with open(output_file, "w") as f:
        subprocess.run(
            [hipblaslt_bench, "--yaml", bench_file, "--device", str(device)],
            stdout=f,
            stderr=subprocess.STDOUT,
            check=True,
            text=True
        )

def run_driver_py(config_yaml, hipblaslt_path, output_dir):
    td_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    driver_py = os.path.join(td_path, "ConfigGenerator", "tuning_driver", "Driver.py")
    assert os.path.isfile(driver_py), f"Cannot find Driver.py at {driver_py}"
    subprocess.run(
        [
            'python',
            driver_py,
            config_yaml,
            hipblaslt_path,
            '--outputPath',
            output_dir
        ],
        # stdout=subprocess.DEVNULL,
        # stderr=subprocess.STDOUT,
        check=True,
        text=True
    )
    

def build_library(hipblaslt_path, library_dir, output_dir, arch):
    cmd = os.path.join(hipblaslt_path, 'tensilelite/Tensile/bin/TensileCreateLibrary')
    subprocess.run([cmd,
                    "--code-object-version",
                    "5",
                    "--library-format",
                    "msgpack",
                    "--architecture",
                    arch,
                    os.path.abspath(library_dir),
                    output_dir,
                    "HIP"],
                   stdout=subprocess.DEVNULL,
                   stderr=subprocess.STDOUT,
                   check=True,
                   text=True)


def parse_latency(file: str, output_file: str = None) -> pd.DataFrame:
    """
    Parse hipBLASLt benchmark output file into a pandas DataFrame.

    Args:
        file (str):        Path to the hipBLASLt benchmark output file
        output_file (str): Path to the generated latency report

    Returns:
        pandas.DataFrame: DataFrame containing parsed benchmark results

    Raises:
        FileNotFoundError: If the input file doesn't exist
        ValueError: If the input file content is not valid
    """

    blocks = open(file).read().split('[0]:')[1:]
    if len(blocks) == 0:
        raise ValueError("The benchmark output file does not have the correct format.")

    try:
        header = blocks[0].split("\n")[0]
        data = [header] + [b.split("\n")[1].strip() for b in blocks]
        df = pd.read_csv(io.StringIO("\n".join(data)))
        df['kernel'] = [b.split('\n')[4].lstrip('    --kernel name:    ') for b in blocks]
    except (pd.errors.EmptyDataError, IndexError) as e:
        raise ValueError("The benchmark output file may be corrupted.")

    if output_file:
        df.to_csv(output_file)

    return df


def check_optimization_progress(tuning_dir):
    n_completed = 0
    gemms = []
    for f in os.listdir(tuning_dir):
        if f.endswith('.sh'):
            config_name, _ = os.path.splitext(f)
            if config_name.split('_')[-1] == "all":
                continue
            build_dir = os.path.join(tuning_dir, f'build_{config_name}', '3_LibraryLogic')
            if os.path.isdir(build_dir) and len(os.listdir(build_dir)) > 0:
                n_completed += 1
            gemms.append(f)

    return len(gemms), n_completed


def optimize_run(tuning_dir, devices=[0,1,2,3,4,5,6,7]):
    td_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cmd = os.path.join(td_path, 'ConfigGenerator/tuning_driver/loadbalancer.py')
    assert os.path.isfile(cmd), f"loadbalancer.py not found {cmd}"
    
    devices =','.join([str(d) for d in devices])
    p = subprocess.Popen(['python',
                          cmd,
                          '.',
                          '--outputPath',
                          tuning_dir,
                          "--devices",
                          devices],
                         cwd=tuning_dir,
                         stderr=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL,
                         text=True)
    n_gemms, curr_completed = check_optimization_progress(tuning_dir)
    print(f'Progress ==> {curr_completed}/{n_gemms}...')
    while p.poll() is None:
        time.sleep(10)
        n_gemms, new_completed = check_optimization_progress(tuning_dir)
        if new_completed > curr_completed:
            print(f'Progress ==> {new_completed}/{n_gemms}...')
        curr_completed = new_completed
        


def merge(hipblaslt_path,input_dir, output_dir='lib', workdir='workdir'):
    uniq_libs = []
    for d in os.listdir(input_dir):
        if not d.startswith('build_'):
            continue
        try:
            lib = os.listdir(os.path.join(input_dir, d, '3_LibraryLogic'))[0]
            if lib not in uniq_libs:
                uniq_libs.append(lib)
        except FileNotFoundError:
            print(d)

    if os.path.isdir(output_dir):
        shutil.rmtree(output_dir)
        
    td_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    merge_gridbased_py = os.path.join(td_path, "workflow_py",  "merge_gridbased.py")
    assert os.path.isfile(merge_gridbased_py), f"Cannot find merge_gridbased.py at {merge_gridbased_py}"

    for lib in uniq_libs:
        subprocess.run(['python',
                        merge_gridbased_py,
                        lib,
                        input_dir,
                        output_dir],
                       stdout=subprocess.DEVNULL,
                       stderr=subprocess.STDOUT,
                       check=True,
                       text=True)        
    
    convertLogicYamlToBIAS_py = os.path.join(td_path, "workflow_py",  "convertLogicYamlToBIAS.py")
    assert os.path.isfile(convertLogicYamlToBIAS_py), f"Cannot find convertLogicYamlToBIAS.py at {convertLogicYamlToBIAS_py}"
    
    for f in os.listdir(output_dir):
        subprocess.run(['python',
                        convertLogicYamlToBIAS_py,
                        f'{output_dir}/{f}'],
                       stdout=subprocess.DEVNULL,
                       stderr=subprocess.STDOUT,
                       check=True,
                       text=True)

        os.remove(f'{output_dir}/{f}')
    
    lib = [f for f in os.listdir(output_dir)][0]
    arch = yaml.safe_load(open( os.path.join(output_dir, lib)))[2]
    
    build_library(hipblaslt_path, output_dir, os.path.join(workdir, 'tensile'), arch)


def postprocess(hipblaslt_path, 
                output_dir, 
                lib_dir='lib', 
                tensile_dir='tensile', 
                log_summary=None,
                device=0,
                error_thr=0.03,
                up_thr=1.03,
                workdir="./workdir"):
    cols = ['hipblaslt-Gflops', 'hipblaslt-GB/s', 'us', 'error', 'kernel']

    benchmarks = os.path.join(workdir, 'benchmarks')
    os.makedirs(benchmarks, exist_ok=True)

    td_path = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    hipblaslt_benchInputCreator_py = os.path.join(td_path, "workflow_py",  "hipblaslt_benchInputCreator.py")
    assert os.path.isfile(hipblaslt_benchInputCreator_py), f"Cannot find hipblaslt_benchInputCreator.py at {hipblaslt_benchInputCreator_py}"
   
    subprocess.run(['python',
                    hipblaslt_benchInputCreator_py,
                    "--duration",
                    "1",
                    "--verify",
                    lib_dir,
                    benchmarks],
                   stdout=subprocess.DEVNULL,
                   stderr=subprocess.STDOUT,
                   check=True,
                   text=True)

    for bench_file in os.listdir(benchmarks):
        if 'beta' in bench_file or bench_file.endswith('bench.yaml') or bench_file.endswith('bench-strided.yaml'):
            os.remove(os.path.join(benchmarks, bench_file))

    df = None
    for backend in ['reference', 'tuned']:
        if backend != 'reference':
            os.environ['HIPBLASLT_TENSILE_LIBPATH'] = f'{tensile_dir}/library'

        dfs = []
        dfs_verify = []
        print(f'Benchmarking {backend} libraries...')
        for bench_file in sorted(os.listdir(benchmarks)):
            if not bench_file.endswith('.yaml'):
                continue

            if 'verify' in bench_file and backend == 'reference':
                continue

            if 'verify' in bench_file:
                logfile = os.path.join(benchmarks, bench_file.replace('.yaml', f'-{backend}.log'))    
                if os.path.isfile(logfile):
                    try:
                        parse_latency(logfile)
                    except:
                        print(f'Running hipblaslt-bench, output will be saved in {logfile}')
                        run_hipblaslt_bench(hipblaslt_path, os.path.join(benchmarks, bench_file), logfile, device=device)
                else:
                    print(f'Running hipblaslt-bench, output will be saved in {logfile}')
                    run_hipblaslt_bench(hipblaslt_path, os.path.join(benchmarks, bench_file), logfile, device=device)
                dfs_verify.append(parse_latency(logfile))
            else:
                logfile = os.path.join(benchmarks, bench_file.replace('.yaml', f'-{backend}.log'))
                if os.path.isfile(logfile):
                    try:
                        parse_latency(logfile)
                    except:
                        print(f'Running hipblaslt-bench, output will be saved in {logfile}')
                        run_hipblaslt_bench(hipblaslt_path, os.path.join(benchmarks, bench_file), logfile, device=device)
                else:
                    print(f'Running hipblaslt-bench, output will be saved in {logfile}')
                    run_hipblaslt_bench(hipblaslt_path, os.path.join(benchmarks, bench_file), logfile, device=device)
                dfs.append(parse_latency(logfile))

        if 'HIPBLASLT_TENSILE_LIBPATH' in os.environ:
            del os.environ['HIPBLASLT_TENSILE_LIBPATH']

        dflib = pd.concat(dfs, ignore_index=True).reset_index(drop=True)
        dflib.rename({c: c + '_' + backend for c in cols}, axis=1, inplace=True)

        if len(dfs_verify) > 0:
            df_verify = pd.concat(dfs_verify, ignore_index=True).reset_index(drop=True)
            df_verify = df_verify[['transA', 'transB', 'm', 'n', 'k', 'batch_count', 'a_type', 'norm_error']]

            dflib['error_tuned'] = dflib.merge(
                df_verify, on=[c for c in df_verify.columns if c != 'norm_error'])['norm_error']
            dflib['error_tuned'] = dflib['error_tuned'] / dflib['batch_count']

        if df is None:
            df = dflib
        else:
            df = df.merge(dflib, on=[c for c in df.columns if c.split('_')[0] not in cols])

    df['ratio'] = df['us_reference'] / df['us_tuned']
    df['pass'] = df['error_tuned'] < error_thr

    results_dir = os.path.join(workdir, 'results')
    os.makedirs(results_dir, exist_ok=True)
    df.to_csv(os.path.join(results_dir, f'raw_results.csv'), index=False)

    mask = (df['ratio'] >= up_thr) * df['pass']
    df = df[mask]
    if mask.sum() == 0:
        print(f'No kernels improve over the base library.')
        return

    os.makedirs(output_dir, exist_ok=True)

    uplift = 100 * (df["ratio"].mean() - 1)
    print(f'Average GEMM uplift ==> {uplift:.4f}% for a total of {len(df)} GEMMS.')
    if log_summary:
        if not os.path.isfile(log_summary):
            raise ValueError(f'File {log_summary} not found.')
        weights = pd.read_csv(log_summary)
        
        wdf = df.merge(weights, on=MERGE_COLS)
        if len(wdf) != len(df):
            raise ValueError(f'Format error in {log_summary}.')
        e2e_uplift = 100 * (wdf["% of total"] / 100 * (df["ratio"].mean() - 1)).sum()
        print(f'Weighted GEMM uplift ==> {e2e_uplift:.4f}%.')

    df.drop(['pass'], axis=1, inplace=True)
    df.to_csv(f'{results_dir}/final_results.csv', index=False)

    n_kernels = len(df)

    schedule = yaml.safe_load(open([os.path.join(lib_dir, f) for f in os.listdir(lib_dir)][0]))[1]
    
    processed = 0
    for key, group in df.groupby(['a_type', 'c_type', 'compute_type', 'transA', 'transB']):
        dtype = f'{DTYPE[key[0]]}{DTYPE[key[1]]}{DTYPE[key[2].lstrip("c_")]}_{key[3]}{key[4]}' if 'a_type' != 'f32_r' else f'S_{key[3]}{key[4]}'
        final_lib = None
        final_libname = None
        kernels = []
        sizes = []
        base_lib = None
        for _, row in group.iterrows():
            size = [row['m'], row['n'], row['batch_count'], row['k']]
            libpath = os.path.join(lib_dir, f"{schedule}_{MAP[dtype]}")
            if base_lib is None:
                base_lib = yaml.safe_load(open(libpath))

            sz = [sz for sz in base_lib[7] if sz[0] == list(size)]
            if len(sz) == 0:
                raise ValueError(f'{size} not found in {libpath}')
            sz = deepcopy(sz[0])
            kernel = deepcopy(base_lib[5][sz[1][0]])
            idx = len(kernels)
            kernel['SolutionIndex'] = idx
            sz[1][0] = idx
            kernels.append(kernel)
            sizes.append(sz)

            if final_lib is None:
                final_lib = deepcopy(base_lib)
                final_libname = f"{schedule}_{MAP[dtype]}"

        final_lib[5] = kernels
        final_lib[7] = sizes
        final_lib[-1] = 'Equality'

        processed += len(sizes)

        yaml.safe_dump(final_lib, open(os.path.join(output_dir, final_libname), 'w'), default_flow_style=None)

    assert processed == n_kernels  # TODO change to raise

    print(f"Optimized libraries have been written on '{os.path.abspath(output_dir)}'.")
