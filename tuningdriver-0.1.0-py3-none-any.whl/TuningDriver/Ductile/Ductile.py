################################################################################
#
# Copyright (C) 2022-2025 Advanced Micro Devices, Inc. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
################################################################################

if __name__ == "__main__":
    print("This file can no longer be run as a script.  Run 'Ductile/bin/Ductile' instead.")
    exit(1)

import os
import subprocess
import sys
import argparse

from datetime import datetime
from pathlib import Path
from typing import Dict

from Ductile import __version__
from Tensile.Common import print1, printExit, printWarning, ensurePath, HR, isRhel8, \
                           LIBRARY_LOGIC_DIR, setVerbosity, IsaInfo, makeDebugConfig, \
                           DebugConfig, IsaVersion, coVersionMap
from Tensile.Common.Architectures import detectGlobalCurrentISA, isaToGfx
from Tensile.Common.Capabilities import makeIsaInfoMap
from Tensile.Common.GlobalParameters import globalParameters, assignGlobalParameters, \
                                            restoreDefaultGlobalParameters
from Tensile.Toolchain.Assembly import AssemblyToolchain, makeAssemblyToolchain
from Tensile.Toolchain.Source import SourceToolchain, makeSourceToolchain
from Tensile.Toolchain.Validators import validateToolchain, ToolchainDefaults
from Tensile.Utilities.Decorators.Profile import profile
from Ductile import BenchmarkProblems
from Ductile.Utilities import convert_config
from Tensile import ClientWriter
from Tensile import LibraryIO
from Tensile import LibraryLogic
from Tensile.Tensile import TENSILE_CLIENT_PATH
from Tensile.Tensile import get_gpu_max_frequency_smi, get_gpu_max_frequency, \
                            get_user_max_frequency, store_max_frequency, \
                            argUpdatedGlobalParameters


###############################################################################
# Execute Steps in Config
# called from Ductile() below
# calls
#   BenchmarkProblems.main() to run benchmark steps
#   LibraryLogic.main() to analyse final benchmark data and produce logic/yaml
#   ClientWriter.main() to create client which calls library based on above yaml
################################################################################
@profile
def executeStepsInConfig(
        config: dict,
        outputPath: Path,
        asmToolchain: AssemblyToolchain,
        srcToolchain: SourceToolchain,
        isaInfoMap: Dict[str, IsaInfo],
        cCompiler: str,
        debugConfig: DebugConfig,
        deviceId: int
   ):
    """Conducts the steps in the provided ``config`` according to the Ductile/Tensile workflow.

    The top-level steps are:
    1. BenchmarkProblems: Runs the benchmarking steps and generates the directories
        build_tmp, 1_BenchmarkProblems, 2_BenchmarkData
    2. LibraryLogic: Analyzes the benchmark data, makes logic files, and generates
        the directory 3_LibraryLogic
    3. LibraryClient: Makes the client callable libraries and generates the
        directory 4_LibraryClient

    Args:
        config (dict): The configuration dictionary.
        outputPath (Path): The path to the top-level build directory.
        asmToolchain (AssemblyToolchain): The toolchain for making assembly kernels.
        srcToolchain (SourceToolchain): The toolchain for making source kernels.
        cCompiler (str): The C compiler to use.
    """

    buildTmpPath = outputPath / "build_tmp"
    ##############################################################################
    # Benchmark Problems
    ##############################################################################
    gfxName = isaToGfx(next(iter(isaInfoMap)))
    if "BenchmarkProblems" in config:
        BenchmarkProblems.main(
            config.get("ductile", {}),
            config["BenchmarkProblems"],
            config["UseCache"],
            asmToolchain,
            srcToolchain,
            cCompiler,
            outputPath,
            buildTmpPath,
            debugConfig,
            deviceId,
            gfxName,
            isaInfoMap,
        )
        print1("")

    ##############################################################################
    # Library Logic
    ##############################################################################
    libraryLogicDataPath = os.path.join(outputPath, LIBRARY_LOGIC_DIR)
    if "LibraryLogic" in config:
        if os.path.exists(libraryLogicDataPath):
            libraryLogicFiles = os.listdir(libraryLogicDataPath)
        else:
            libraryLogicFiles = []
        if len(libraryLogicFiles) < 1 or globalParameters["ForceRedoLibraryLogic"]:
            if config["LibraryLogic"] != None:
                libraryLogicConfig = config["LibraryLogic"]
            else:
                libraryLogicConfig = {}
            LibraryLogic.main(
                libraryLogicConfig,
                srcToolchain.compiler,
                outputPath,
                debugConfig.splitGSU,
                debugConfig.printSolutionRejectionReason,
                debugConfig.printIndexAssignmentInfo,
                isaInfoMap,
            )
            print1("")
        else:
            print1("# LibraryLogic already done.")
        print1("")

    ##############################################################################
    # Write Client
    ##############################################################################
    if "LibraryClient" in config:
        if config["LibraryClient"] != None:
            libraryClientConfig = config["LibraryClient"]
        else:
            libraryClientConfig = {}
        ClientWriter.main(
            libraryClientConfig,
            asmToolchain.assembler,
            cCompiler,
            isaInfoMap,
            outputPath,
            deviceId,
            gfxName,
        )
        print1("")


def addCommonArguments(argParser):
    """
    Add a common set of arguments to `argParser`.

    Currently used by the main Ductile/Tensile script and the unit tests but could also be used for TensileCreateLibrary.
    """

    def splitExtraParameters(par):
        """
        Allows the --global-parameters option to specify any parameters from the command line.
        """
        (key, value) = par.split("=")
        value = eval(value)
        return (key, value)

    argParser.add_argument("-d", "--device", dest="device", default=0, type=int, \
        help="override which device to benchmark")
    argParser.add_argument("-p", "--platform", dest="platform", type=int, \
        help="override which OpenCL platform to benchmark")
    argParser.add_argument("--runtime-language", dest="RuntimeLanguage", \
        choices=["HIP", "OCL"], help="override which runtime language to use")
    argParser.add_argument("--code-object-version", dest="CodeObjectVersion", \
        choices=["4", "5", "V4", "V5", "default"], action="store", default="4", help="HSA code-object version")
    argParser.add_argument("-v", "--verbose", action="store_true", \
        help="set PrintLevel=2")
    argParser.add_argument("--debug", dest="debug", action="store_true", \
        help="set PrintLevel=2 and CMakeBuildType=Debug")
    argParser.add_argument("--cxx-compiler", dest="CxxCompiler", \
        action="store", default=ToolchainDefaults.CXX_COMPILER, help="select which C++/HIP compiler to use")
    argParser.add_argument("--c-compiler", dest="CCompiler", \
        action="store", default=ToolchainDefaults.C_COMPILER, help="select which C compiler to use")
    argParser.add_argument("--assembler", dest="Assembler", \
        action="store", default=ToolchainDefaults.ASSEMBLER, help="select which assembler to use")
    argParser.add_argument("--offload-bundler", dest="OffloadBundler", \
        action="store", default=ToolchainDefaults.OFFLOAD_BUNDLER, help="select which offload bundler to use")
    argParser.add_argument("--device-enumerator", dest="DeviceEnumerator", \
        action="store", default=ToolchainDefaults.DEVICE_ENUMERATOR, help="select which device enumerator to use")
    argParser.add_argument("--logic-format", dest="LogicFormat", choices=["yaml", "json"], \
        action="store", default="yaml", help="select which logic format to use")
    argParser.add_argument("--library-format", dest="LibraryFormat", choices=["yaml", "msgpack"], \
        action="store", default="yaml", help="select which library format to use")
    argParser.add_argument("--client-lock", default=None)
    argParser.add_argument("--prebuilt-client", default=str(TENSILE_CLIENT_PATH),
        type=os.path.abspath, help="Specify the full path to a pre-built tensilelite-client executable")

    argParser.add_argument("--global-parameters", nargs="+", type=splitExtraParameters, default=[])

################################################################################
# Ductile
# - below entry points call here
################################################################################
def Ductile(userArgs):
    global globalParameters

    print1("")
    print1(HR)
    print1("#")
    print1("#  Ductile v%s" % (__version__))

    argParser = argparse.ArgumentParser()
    argParser.add_argument("ConfigFile", type=os.path.realpath, nargs="+",
            help="Benchmark config.yaml file")
    argParser.add_argument("OutputPath", \
            help="Path to conduct benchmark and write output files")
    argParser.add_argument("--version", action="version", \
            version="%(prog)s {version}".format(version=__version__))
    argParser.add_argument("--alternate-format", dest="AlternateFormat", action="store_true",
            help="Alternate format for config_file(s): first file is alternate config "
            "and optional second file is size list")
    argParser.add_argument("--use-cache", dest="useCache", action="store_true",
            help="Ignore cache; redo parameter forking and solution generation")
    argParser.add_argument("--convert-config", dest="convert_config", action="store_true",
            help="Convert config yaml format from Tensile to Ductile")
    

    addCommonArguments(argParser)
    args = argParser.parse_args(userArgs)
    configPaths = args.ConfigFile
    altFormat = args.AlternateFormat
    useCache = args.useCache
    outputPath = Path(ensurePath(os.path.abspath(args.OutputPath)))
    print1(f"#  OutputPath: {str(outputPath)}")

    setVerbosity(2 if (args.debug or args.verbose) else 1)

    if altFormat and len(configPaths) > 2:
        printExit("Only 1 or 2 config_files are accepted for the alternate config format: "
                  "the alternate config file and an optional size list")
    elif not altFormat and len(configPaths) != 1:
        printExit("Only 1 config_file is accepted for the default config format. "
                  "Did you mean to add '--alternate-format'?")

    if args.convert_config:
        if altFormat:
            printExit("Conversion to Ductile format is not supported for alternate config format.")
        yaml_path = configPaths[0]
        newConfigFile = configPaths[0].replace(".yaml", ".ductile.yaml")
        convert_config(configPaths[0], newConfigFile)
        configPaths[0] = newConfigFile
    
    # 2nd half of splash
    if len(configPaths) == 1:
        print1("#  Config: {}".format(configPaths[0]))
    else:
        print1("#  Configs: {} and {}".format(configPaths[0], configPaths[1]))
    print1("#  Date & Time: %s" % (datetime.now().strftime("%d/%m/%Y %H:%M:%S")))
    print1("#")
    print1(HR)
    print1("")

    print1("# Restoring default globalParameters")
    restoreDefaultGlobalParameters()

    if args.LogicFormat:
        globalParameters['LogicFormat'] = args.LogicFormat
    if args.LibraryFormat:
        globalParameters['LibraryFormat'] = args.LibraryFormat
    globalParameters['CodeObjectVersion'] = coVersionMap[args.CodeObjectVersion]
    print1(f"# Code Object Version: {globalParameters['CodeObjectVersion']}")

    # default config format
    if not altFormat:
        config = LibraryIO.read(configPaths[0])
    # convert alternate format into default format
    else:
        base = LibraryIO.read(configPaths[0])
        sizes = []
        if len(configPaths) == 2:
            sizes = LibraryIO.read(configPaths[1])

        config = {"GlobalParameters": base.get("GlobalParameters")}
        if "LibraryLogic" in base and len(sizes) > 0:
            config["LibraryLogic"] = base["LibraryLogic"]
        if "LibraryClient" in base and len(sizes) > 0:
            config["LibraryClient"] = None

        solParams = {
            "BenchmarkCommonParameters": base.get("BenchmarkCommonParameters"),
            "ForkParameters": base.get("ForkParameters"),
            "GroupForkParameters": base.get("GroupForkParameters"),
            "BenchmarkFinalParameters": [{
                "ProblemSizes": sizes
            }]
        }
        config["BenchmarkProblems"] = [[base["ProblemType"], solParams]]

    config["UseCache"] = useCache
    globalParameters["ConfigPath"] = configPaths

    asm_debug = config["GlobalParameters"].get("AsmDebug", False)
    device_id = config["GlobalParameters"].get("Device", int(args.device))
    UseEffLike = config["GlobalParameters"].get("UseEffLike", globalParameters["UseEffLike"])
    UseEffLike = False if isRhel8() else UseEffLike

    if 'LibraryLogic' in config and UseEffLike:
        max_frequency = get_gpu_max_frequency(device_id)

        if not max_frequency or max_frequency <= 0:
            max_frequency = get_gpu_max_frequency_smi(device_id) # Using rocm-smi just in case

        if not max_frequency or max_frequency <= 0:
            print(f"Could not detect valid GPU frequency for device {device_id}")
            max_frequency = get_user_max_frequency()

        print(f"Successfully retrieve Max frequency: {max_frequency} for device {device_id}")
        store_max_frequency(max_frequency)

    cxxCompiler, \
    cCompiler, \
    offloadBundler, \
    enumerator = validateToolchain(args.CxxCompiler,
                                   args.CCompiler,
                                   args.OffloadBundler,
                                   ToolchainDefaults.DEVICE_ENUMERATOR)
    asmToolchain = makeAssemblyToolchain(
        cxxCompiler,
        offloadBundler,
        args.CodeObjectVersion,
        debug=asm_debug,
    )
    srcToolchain = makeSourceToolchain(
        cxxCompiler,
        offloadBundler,
    )

    if "ISA" in config["GlobalParameters"]:
        isaList = [IsaVersion(isa[0], isa[1], isa[2]) for isa in config["GlobalParameters"]["ISA"]]
    else:
        isaList = [detectGlobalCurrentISA(device_id, enumerator)]

    if IsaVersion(9,5,0) in isaList:
        printWarning("HardwareMonitor currently disabled for gfx950")
        globalParameters["HardwareMonitor"] = False

    isaInfoMap = makeIsaInfoMap(isaList, cxxCompiler)
    assignGlobalParameters(config.get("GlobalParameters", {}), isaInfoMap)

    overrideParameters = argUpdatedGlobalParameters(args)

    debugConfig = makeDebugConfig(config["GlobalParameters"])

    for key, value in overrideParameters.items():
        print("Overriding {0}={1}".format(key, value))
        globalParameters[key] = value

    if "MaxFileName" in globalParameters or "MaxFileName" in config:
        printWarning("MaxFileName is no longer configurable, it will be automatically set to 64")

    executeStepsInConfig(config, outputPath, asmToolchain, srcToolchain, isaInfoMap, cCompiler, debugConfig, device_id)

# installed "Ductile" command
def main():
    Ductile(sys.argv[1:])
