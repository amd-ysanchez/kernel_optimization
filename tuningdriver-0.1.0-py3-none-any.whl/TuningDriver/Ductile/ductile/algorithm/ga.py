from ..core import Population, SearchSpace, Mating, Survival
from ..utils import Logger
from ..config import DEFAULTS
from typing import Callable

import numpy as np
import random
import logging
import time


# noinspection DuplicatedCode
class GeneticAlgorithm:
    name = "GA"

    def __init__(self,
                 space: SearchSpace,
                 mating: Mating,
                 evaluate: Callable,
                 survival: Survival = Survival.get("fitness"),
                 pop_size: int = 512,
                 n_gen: int = 20,
                 soo: bool = False,
                 period: int = 5,
                 tol: float = 8e-4,
                 div_thr: float = 0.5,
                 seed: int = None,
                 verbose: int = 1,
                 log_file: str = None):

        self.logger = Logger(self.name, log_file=log_file, verbose=verbose)

        if not isinstance(space, SearchSpace):
            raise ValueError("space must be of type SearchSpace.")
        self.space = space

        if not isinstance(mating, Mating):
            raise ValueError("mating must be of type Mating.")
        self.mating = mating

        if not isinstance(survival, Survival):
            raise ValueError("survival must be of type Survival.")
        self.survival = survival

        if not callable(evaluate):
            raise ValueError("'evaluate' must be a callable function.")
        self.evaluate = evaluate

        if not (isinstance(pop_size, int) and pop_size > 2):
            self.logger.error("pop_size must be an integer larger than 2, changing to default value.")
            pop_size = DEFAULTS["pop_size"]
        self.pop_size = pop_size

        if not (isinstance(n_gen, int) and n_gen > 0):
            self.logger.error("n_gen must be an integer larger than 0, changing to default value.")
            n_gen = DEFAULTS["n_gen"]
        self.n_gen = n_gen

        if not isinstance(soo, bool):
            self.logger.error("soo must be an boolean, changing to default value.")
            soo = DEFAULTS["soo"]
        self.soo = soo
        self.reduce_fn = np.mean if self.soo else np.max

        if period and not (isinstance(period, int) and period >= 0):
            self.logger.error("period must be an integer larger or equal to 0, changing to default value.")
            period = DEFAULTS["period"]
        self.period = period

        if not (isinstance(tol, float) and tol >= 0):
            self.logger.error("tol must be a float larger or equal to 0, changing to default value.")
            tol = DEFAULTS["tol"]
        self.tol = tol

        if self.space.n_perms < self.pop_size:
            raise ValueError("pop_size must be larger than the total amount of variable permutations.")

        self._pop_size = pop_size
        max_sp_sz = max(sz for sz in self.space.sizes.values())
        if max_sp_sz > pop_size:
            self.logger.warning(f"Some variables have a larger search space than pop_size. "
                                f"Increasing pop_size for the first generations.")
            self.decay = lambda sz: int(self._pop_size + (sz - self._pop_size) / 2)
            self.pop_size = int(max_sp_sz * 1.15)
        elif max_sp_sz < self.pop_size / 5:
            self.pop_size = int(self.pop_size / 2)
            self._pop_size = self.pop_size
        
        if not (isinstance(div_thr, float) and (div_thr >= 0 or div_thr <= 1)):
            self.logger.error("div_thr must be a float between 0 and 1, changing to default value.")
            div_thr = DEFAULTS["div_thr"]
        self.div_thr = div_thr
            
        self.stats = {}

        random.seed(seed)
        np.random.seed(seed)
        self.logger.info(f"Setup completed.")
        self.logger.log_lines(self.__repr__(), logging.INFO)
    
    def update(self, best, pop, old_pop, scores):
        scores[scores < 0] = -1.0
        
        pop.G = scores
        
        if best is None:
            best = pop[scores.argmax(1)].copy()
            best.F = scores.max(1)
        elif (scores.max(1) > best).any():
            mask = scores.max(1) > best
            best[mask] = pop[scores.argmax(1)][mask].copy()
            best[mask].F = scores.max(1)[mask]
        
        pop.F = self.reduce_fn(scores / best.F[..., None], axis=0)
        if old_pop.size:
            old_pop.F = self.reduce_fn(old_pop.G / best.F, axis=1)
        
        return best, best.F.mean()

    def termination(self, **kwargs):
        for k, v in kwargs.items():
            if k in self.stats:
                self.stats[k].append(v)
            else:
                self.stats[k] = [v]
                            
        if self.period and len(self.stats.get("f_avg", [])) > self.period:
            w = slice(-self.period - 1, -1)
            tol = self.stats["f_max"][-1] * self.tol
            ma_fa = np.mean(self.stats["f_avg"][w]) + tol
            ma_fm = np.mean(self.stats["f_max"][w]) + tol
            if ma_fa >= self.stats["f_avg"][-1] and ma_fm >= self.stats["f_max"][-1]: 
                raise StopIteration(f"f_avg and f_max did not increase for the last {self.period} generations.")

        if kwargs.get('diversity', 1.0) < self.div_thr:
            self.decay = lambda sz: int(self._pop_size / 2 + (sz - self._pop_size / 2) / 1.25)
        self.pop_size = self.decay(self.pop_size) if hasattr(self, "decay") else self.pop_size

    def optimize(self):
        self.logger.info(f"Starting optimization...")
        start = time.time()
        self.stats = {}
        best = None
        n_evals = 0
        old_pop, pop = Population(), self.space.sample(self.pop_size)
        try:
            for gen in range(1, self.n_gen + 1):
                scores = self.evaluate(self.space.transform(pop))
                if scores.ndim == 1:
                    scores = scores[None, ...]

                best, f_max = self.update(best, pop, old_pop, scores)

                n_evals += (scores > 0).max(0).sum()
                f_avg = scores[scores > 0].mean()  # Here we ignore non-valid solutions (F<=0)
                diversity = pop.diversity()
                self.logger.print_stats(n_gen=gen, n_evals=n_evals, diversity=diversity, f_avg=f_avg, f_max=f_max)
                
                self.termination(f_avg=f_avg, f_max=f_max, diversity=diversity)

                old_pop = self.survival(old_pop, pop, self.pop_size)
                pop = self.mating(old_pop, self.pop_size)
        except StopIteration as e:
            self.logger.info(f"Stop criterion reached: {e}")

        if self.soo and len(best) > 1:
            best = best[(best.G / best.F).mean(1).argmax()]
            best.F = best.G.mean()
            best = Population([best])
        
        X = self.space.transform(best)
        self.logger.info(f"Finished optimization in {(time.time() - start):.3f}s")
        self.logger.info(f"X: {X}")
        self.logger.info(f"F: {best.F.mean():.4f}")
        return X, best.F

    def __repr__(self):
        return f"GeneticAlgorithm(pop_size={self.pop_size}, n_gen={self.n_gen}, period={self.period}, " \
               f"tol={self.tol}, div_thr={self.div_thr}, soo={self.soo})\n{self.mating}\n{self.space}"
