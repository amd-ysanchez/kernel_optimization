import yaml
import argparse


dataSize = {'H': 2, 'B': 2, 'S': 4, 'D': 8, 'C': 8, 'Z': 16, 'I8': 1, 'X': 4, 'F8': 1, 'F8B8': 1}

calc_iters = lambda m, n, b, k: max(round(-(m + n + k) * 0.015 + 431), 5)

def calcGRVW(dataType, valid=(1, 2, 3, 4, 6, 8, 16)):
    dsz = dataSize[dataType]
 
    min_grvw = max(1, int(4 / dsz))
    max_grvw = min(max(valid), int(16 / dsz))
 
    grvw = [-1, -2] + list(valid[valid.index(min_grvw):valid.index(max_grvw)+1])
    return grvw

def convert_config(yaml_path, output_path, update_iters=True):
    
    data = yaml.full_load(open(yaml_path))
    
    if 'DeviceLDS' in data["GlobalParameters"]:
        del data["GlobalParameters"]["DeviceLDS"]
        
    if 'MaxLDS' in data["GlobalParameters"]:
        del data["GlobalParameters"]["MaxLDS"]

    data["GlobalParameters"]["SleepPercent"] = 50
    
    is_batched =  any((sz["Exact"][2] != 1 for sz in data["BenchmarkProblems"][0][1]["BenchmarkFinalParameters"][0]["ProblemSizes"]))
    if update_iters and not is_batched:
        iters = max(calc_iters(*sz["Exact"]) for sz in data["BenchmarkProblems"][0][1]["BenchmarkFinalParameters"][0]["ProblemSizes"])
        data["GlobalParameters"]["EnqueuesPerSync"] = max(iters, data["GlobalParameters"]["EnqueuesPerSync"])
        data["GlobalParameters"]["NumWarmups"] = max(iters, data["GlobalParameters"]["EnqueuesPerSync"])

    isMI350 = data['LibraryLogic']['ArchitectureName'] == 'gfx950'

    for bp in data["BenchmarkProblems"]:
        groups = [g for g in bp[1]["ForkParameters"] if "Groups" in g][0]
        MIs = [g for g in groups["Groups"] if "MatrixInstruction" in g[0]]
        
        fork_parameters = []
        fork_parameters.append([g for g in data["BenchmarkProblems"][0][1]["ForkParameters"] if "DepthU" in g][0]) #DEPTHU
        
        # NOTE: for input bpe=128, max GRVW is 1  (to fit dwordx4) (CF64),      min GRVW is 1 (dword)
        #                 bpe=64,  max GRVW is 2  (to fit dwordx4) (FP64/CF32), min GRVW is 1 (dword)
        #                 bpe=32,  max GRVW is 4  (to fit dwordx4) (FP32),      min GRVW is 1 (dword)
        #                 bpe=16,  max GRVW is 8  (to fit dwordx4) (FP16),      min GRVW is 2 (dword)
        #                 bpe=8,   max GRVW is 16 (to fit dwordx4) (INT8),      min GRVW is 4 (dword)
        grvw = calcGRVW(bp[0]['DataType'])

        fork_parameters.extend([
            {"1LDSBuffer": [0, 1]},
            {"GlobalReadVectorWidthA": list(grvw)}, 
            {"GlobalReadVectorWidthB": list(grvw)}, 
            {"WaveSeparateGlobalReadA": [0]},
            {"WaveSeparateGlobalReadB": [0]},
            {"NumElementsPerBatchStore": [0, 2, 4, 8, 10, 12, 14, 16]},
            {"NonTemporalA": [0, 1, 2, 3, 4, 5, 6, 7]}, #[0, 1, 4, 7]
            {"NonTemporalB": [0, 1, 2, 3, 4, 5, 6, 7]}, #[0, 4]
            {"NonTemporalC": [0, 1, 2, 3, 4, 5, 6, 7]}, #[0, 3, 4]
            {"NonTemporalD": [0, 1, 2, 3, 4, 5, 6, 7]}, #[0, 3, 4, 7]
            {"PrefetchGlobalRead": [1, 2]},
            {"PrefetchLocalRead": [1]},
            {"GroupLoadStore": [0]},
            {"SourceSwap": [0, 1]},
            {"StaggerU": [0, 8, 16]}, #TODO check for MI350
            {"StaggerUStride": [64, 128, 256, 512]}, #TODO check for MI350
            {"StorePriorityOpt": [0, 1]},
            {"StoreSyncOpt": [0, 1, 4]},
            {"WorkGroupMapping": [-48, -32, -24, -16, -8, -6, -4, -2, -1, 0, 1, 2, 4, 6, 8, 16, 24, 32, 48]},
            {"WorkGroupMappingXCC": [1, 2, 4, 8, 16] + ([32] if isMI350 else [])}, 
            {"MIArchVgpr": [0, 1]},
            {"TransposeLDS": [-1, 0, 1, 2]},
            {"DirectToLds": [0, 1]},
            {"GlobalSplitUAlgorithm": ["MultipleBuffer"]}
            
        ])
        
        if not isMI350 and not bp[0]['TransposeA']: #TODO #CUs
            fork_parameters.append({"DirectToVgprA": [0, 1]})
        
        streamK = [g for g in data["BenchmarkProblems"][0][1]["ForkParameters"] if "StreamK" in g]
        if len(streamK) == 1 and (streamK[0]['StreamK'][0] != 0 or len(streamK[0]['StreamK']) > 1):
            fork_parameters.extend([
                streamK[0], #TODO should we consider more StreamK options?
                {"StreamKXCCMapping": [0, 4, 5, 6, 7, 8]}, #TODO [0, 8]
                {"UseSgprForGRO": [-1, 0, 1]},
                # {"UseSgprForGRO": [-1]},
                # {"UseInstOffsetForGRO": [-1, 0, 1]} # TODO?
                ])
            [fp for fp in fork_parameters if 'WorkGroupMapping' in fp][0]['WorkGroupMapping'] = [0, 1, 2, 4, 6, 8, 16, 24, 32, 48] #TODO update when fixed
        
        groups = [{"Groups": MIs }]
        
        if not (bp[0]['TransposeA'] and not bp[0]['TransposeB']):
            groups[0]["Groups"] += [[{'ClusterLocalRead': 0, 'LDSTrInst': 1}, {'ClusterLocalRead': 1, 'LDSTrInst': 0}]]
        else:
            fork_parameters.append({"ClusterLocalRead": [0, 1]})

        bp[1]["ForkParameters"] = fork_parameters + groups
    
    #TODO fill necessary sections
    data['ductile'] = dict(log_file=output_path.replace('.yaml', '-optimization.log'))
    
    yaml.dump(data, 
              open(output_path, 'w'), 
              default_style=None, 
              default_flow_style=None, 
              sort_keys=False, 
              width=5000)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=f"Convert Tensile config yaml files to Ductile format.")
    parser.add_argument('input_path', help='Path to the input Tensile config yaml file', type=str)
    parser.add_argument('--output_path', help='Path to the output Ductile config yaml file', type=str, default=None) 
    parser.add_argument('--update_iters', help='Update iterations with custom logic', action='store_true')
    
    args = parser.parse_args()
    
    output_path = args.output_path
    if not output_path:
        output_path = args.input_path.replace(".yaml", ".ductile.yaml")
    
    convert_config(args.input_path, output_path, args.update_iters)    