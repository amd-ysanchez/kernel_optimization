import yaml
import argparse
import ast
from typing import List


def calculate_MT_from_mfma(*, MI, MIBlockM=None, waveFrontSize=64, **config):
    wave = MI[7], MI[8]
    MIBlockM = MIBlockM or MI[4]
    waveTileM, waveTileN = MI[5], MI[6]

    MatrixInstM = MI[0] * MIBlockM
    MT0 = MatrixInstM * waveTileM * wave[0]

    MatrixInstN = MI[1] / MIBlockM * MI[3]
    MT1 = int(MatrixInstN * waveTileN * wave[1])
    TT0 = waveTileM
    TT1 = waveTileN * MI[1]
    WG0 = MatrixInstM * wave[0]
    WG1 = int(wave[0] * wave[1] * waveFrontSize / WG0)

    return MT0, MT1, TT0, TT1, WG0, WG1, MIBlockM

def print_groups(groups, library_logic_path: str, tuning_config_path: str=None, solution_indices: List[int]=None):
    """
    Print groups in a yaml format
    """
    if len(groups) == 0:
        print("No groups in config appear in library logic!")

    for g in groups:
        MT0, MT1, TT0, TT1, WG0, WG1, MIBlockM = calculate_MT_from_mfma(MI=g["MatrixInstruction"], waveFrontSize=64)
        comment = " # MT {:7} - TT {:6} - WG {:6} - MIBlockM: {}".format("{}x{}".format(MT0, MT1),
                                                                         "{}x{}".format(TT0, TT1),
                                                                         "{}x{}".format(WG0, WG1), MIBlockM)
        # Parse MatrixInstruction
        line = "  MatrixInstruction: [" + ", ".join(map(str, g["MatrixInstruction"])) + "]" + comment
        g.pop("MatrixInstruction")

        # Parse everything else
        for k in sorted(g.keys()):
            v = g[k]
            if k == "SolutionIndex":
                line = f"  # {k}: {v} (Liblogic File: {library_logic_path}) \n" + line
            if k == "SolutionIndices":
                  line = f"  # {k}: {v} (Liblogic File: {library_logic_path}) \n" + line
            else:
                line = f"  {k}: {v}\n" + line

        # Prefix a hyphen and remove extra space for alignment
        line = "-" + line[1:]

        # Print result
        print(line)

def remove_duplicates_from_winner_groups(groups: list):
    group_set = dict() # dictionary of fields -> list of solution indices
    for g in groups:
        t = g.copy()
        solution_index = t['SolutionIndex']
        del t['SolutionIndex']
        k = frozenset(t.items())
        if k in group_set:
            group_set[k].append(solution_index)
        else:
            group_set[k] = [solution_index]

    list_of_groups = []
    for g,s in group_set.items():
        d = dict()
        for k,v in g:
            d[k]=v
        d['SolutionIndices'] = s
        list_of_groups.append(d)

    return list_of_groups


def dump_groups(*, library_logic_path: str, tuning_config_path: str=None, solution_indices: List[int]=None, ignore_one_value_parameters: bool=False):

    with open(library_logic_path, 'r') as library_logic_file:
        yaml_content = yaml.safe_load(library_logic_file)

        winners = []
        solutions = yaml_content[5]

        params = set()
        with open(tuning_config_path, 'r') as tuning_config_file:
            tuning_config_file_yaml_content = yaml.safe_load(tuning_config_file)
            forked_params = set()
            for f in tuning_config_file_yaml_content['BenchmarkProblems'][0][1]['ForkParameters']:


                for k,v in f.items():
                    # Don't add 1 value params
                    if ignore_one_value_parameters and len(v) == 1 and k != 'Groups':
                        print(f"# Ignoring params {k} since there is only one value")
                        continue
                    if k != 'Groups':
                        forked_params.add(k)
                    else:
                        for group in v:
                            for g in group:
                                for kk in g.keys():
                                    params.add(kk)

            for f in forked_params:
                params.add(f)

        print(f"# Included Params: {params}")
        groups = []
        for s in solutions:
            cond = solution_indices is None or (solution_indices is not None and s['SolutionIndex'] in solution_indices)
            if cond:

                params_dict = {p: s[p] for p in params if p != "MatrixInstruction"}
                params_dict["SolutionIndex"] = s["SolutionIndex"]
                params_dict["MatrixInstruction"] = tuple([*s["MIBlock"][:5], *s["MIWaveTile"], *s["MIWaveGroup"]])
                groups.append(params_dict)

        gs = remove_duplicates_from_winner_groups(groups)

        print_groups(gs, library_logic_path=library_logic_path, tuning_config_path=tuning_config_path,
                     solution_indices=solution_indices)

if __name__ == '__main__':

    # Parse command line args
    parser = argparse.ArgumentParser(description='Make (winning) groups from the library logic yaml with params from '
                                                 'the config yaml file')
    parser.add_argument('-t', '--tuning_config_path', required=True,
                        type=str, help='Path to tuning config yaml file',
                        default=None)
    parser.add_argument('-l','--library_logic_path', type=str,
                        help='Path to library logic yaml file',
                        required=True)
    parser.add_argument('-s','--solution_indices', type=str,
                        help='Only include solution these solution indices passed as a python list e.g.`[1,2,3]`',
                        default=None, required=False)

    parser.add_argument('-i', '--ignore_one_value_parameters', action='store_true', default=False,
                        help='Do not include parameters that has only one values (the idea is, these might be temporary and is to be tuned so easier to keep out of groups)',
                        required=False)

    args = parser.parse_args()

    solution_indices = None
    if args.solution_indices:
        solution_indices = ast.literal_eval(args.solution_indices) # this is bad, I know!

    dump_groups(library_logic_path=args.library_logic_path,
                tuning_config_path=args.tuning_config_path,
                solution_indices=solution_indices,
                ignore_one_value_parameters=args.ignore_one_value_parameters)