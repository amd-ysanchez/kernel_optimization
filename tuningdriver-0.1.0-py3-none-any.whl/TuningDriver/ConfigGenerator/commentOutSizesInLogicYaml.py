# -*- coding: utf-8 -*-

#  commentOutSizesInLogicYaml.py
#
#  This is comment out sizes in logic yaml
#  First input file is logic yaml. Second input is size information
#  Size information: either 4 param or 3 param
#     100,100,1,1000  -> M,N,B,K
#     100,100,100     -> M,N,K  (assuming B=1)
#
#  how to use
#   1 execute python program as follows
#     example (python3): python3 commentOutSizesInLogicYaml.py logic_yaml  size_info_file [not]
#
#   example1) comment out sizes in size_info
#     python3 commentOutSizesInLogicYaml.py aquavanjaram_Cijk_Alik_Bljk_HHS_BH_Bias_AS_SAV_UserArgs.yaml  size_info.txt
#   example2) comment out sizes NOT in size_info
#     python3 commentOutSizesInLogicYaml.py aquavanjaram_Cijk_Alik_Bljk_HHS_BH_Bias_AS_SAV_UserArgs.yaml  size_info.txt not
#
#  replace the following strings
# replaceListH = {\
# " function": 'function: matmul', \
# " compute_type": 'compute_type: c_f32_r',\
# " rotate": 'scale_type: f32_r, rotating: 512'\
# }
# replaceListR = {\
# " function": 'rocblas_function: rocblas_gemm_ex', \
# " compute_type": 'compute_type: f32_r',\
# " rotate": 'flush_memory_size: 536870912'\
# }

# KeyHIPBLASLT = "hipblaslt"
# KeyROCBLAS   = "rocblas"

# replaceList = {\
# KeyHIPBLASLT: replaceListH, \
# KeyROCBLAS  : replaceListR \
# }

# replaceKeyList = list(replaceListH.keys())
# BenchList = list(replaceList.keys())

import sys
import re
import os
import shutil
import datetime

DEBUG = False #True

def commentOutLine(line):
   if line.startswith("  - - ["):
       line = line.replace("  - - [", "#  - - [")
   elif line.startswith("- - - ["):
       line = line.replace("- - - [", "-\n#  - - [")

   return line

def getSizeFromLine(line):
    numList = []
    line = line.strip()
    # skip line if line starts from "#"
    if len(line) > 0 and line[0] != "#":
        itemList = re.split(r'\[|\]',line)
        for item in itemList:
            nums = re.split('[, \-\t]+', item)
            if (len(nums) == 3 or len(nums) == 4) and "" not in nums:
               # size info
              if DEBUG:
                 print(f'nums = {nums}')
              if len(nums) == 4:
                 M = int(nums[0])
                 N = int(nums[1])
                 B = int(nums[2])
                 K = int(nums[3])
              else:  #if len(nums) == 3:
                 M = int(nums[0])
                 N = int(nums[1])
                 B = 1
                 K = int(nums[2])
              numList.append([M,N,B,K])
              break

    return numList

# main process starts from here
argvs = sys.argv
argc = len(argvs)

# parameter check
if (argc < 3):
    print ('Usage: # python %s logic_yaml  size_info_file [not]' % argvs[0])
    sys.exit(1)

yamlFile = argvs[1]
sizeFile = argvs[2]

notFlag = False
if (argc >= 4 and argvs[3].lower() == "not"):
  print(f"param3: {argvs[3].lower()}")
  notFlag = True


# file name check
if (".yaml" not in yamlFile):
    print ('ERROR: not .yaml')
    sys.exit(1)

# read size_info_file
try:
    fin = open(sizeFile, 'r')
except:
    print ('Usage: %s is not found.' % sizeFile)
    quit()

lines = fin.readlines()
fin.close()
# create num list
numList = []
for line in lines:
    numList += getSizeFromLine(line)

# read logic yaml
try:
    fin = open(yamlFile, 'r')
except:
    print ('Usage: %s is not found.' % yamlFile)
    quit()

lines = fin.readlines()
fin.close()

outFile = yamlFile.replace(".yaml", "_out.yaml")

with open(outFile, 'w') as fw:
    print(f'output file: {outFile}')
    nextFlag = False
    for line in lines:
        # comment out next line
        if nextFlag:
            line = "#" + line
            nextFlag = False
        # yaml size info (startswith  "- - - [" or "  - - ["
        elif line.startswith("  - - [") or line.startswith("- - - ["):
            numListInYaml = getSizeFromLine(line)
            if len(numListInYaml) == 1 and len(numListInYaml[0]) == 4:
                if (notFlag == False and numListInYaml[0] in numList) or (notFlag and numListInYaml[0] not in numList):
                    if DEBUG:
                      print(f'numListInYaml = {numListInYaml}')
                    line = commentOutLine(line)
                    nextFlag = True # comment out next line
        fw.write(line)


