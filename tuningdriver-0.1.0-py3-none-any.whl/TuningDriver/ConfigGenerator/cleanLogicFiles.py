"""
This python script goes through all library logics in hipBlasLt and
removes all problemType fields for each solution kernel
and removes any benchmark parameters that are set to the default values
Example -
python3 ./cleanLogicFiles.py --hipblaslt-root ~/workspace/hipBLASLt
"""

import os
import sys
import yaml
import pickle

import argparse

parser = argparse.ArgumentParser()

parser.add_argument("--hipblaslt-root", action="store", type=str)
args = parser.parse_args()

hipblaslt_path = args.hipblaslt_root
lib_logic_root_path = "library/src/amd_detail/rocblaslt/src/Tensile/Logic/asm_full"
working_dir = os.path.join(hipblaslt_path, lib_logic_root_path)
sys.path.insert(0,os.path.join(hipblaslt_path,'tensilelite'))

from Tensile import Common

defaulParamDict = Common.defaultSolution

import time

def clean_file(filename, defaulParamDict):
    t0 = time.time()
    f = open(filename, 'r')
    ll_data = yaml.load(f, yaml.SafeLoader)
    if len(ll_data) < 6 or type(ll_data) != list:
        print("Format error in :", filename)
        return
    t1 = time.time()

    numKernels=len(ll_data[5])
    for kernel in ll_data[5]:
        for k in list(kernel.keys()):
            v = kernel[k]
            if k == 'ProblemType':
                del kernel['ProblemType']
            if k in defaulParamDict.keys():
                if v == defaulParamDict[k]:
                    del kernel[k]

    # Add dict containing default values for benchmark params into yaml
    if len(ll_data) > 12:
        ll_data[12] = Common.defaultSolution
    elif len(ll_data) > 11:
        ll_data.append(Common.defaultSolution)

    fw = open(filename, 'w')

    yaml.safe_dump(ll_data,fw,default_flow_style=None)
    t2 = time.time()

    print("Done cleaning", filename + ", has " + str(numKernels) + " kernels")
    print(" - time to load:", t1 - t0)
    print(" - time to add kv:", t2 - t1)
    return

iter = 0
list_of_args = []
yamls_to_skip = [
    'aquavanjaram_Cijk_Ailk_Bjlk_HHS_BH_Bias_HAS_SAV_UserArgs_dtree.yaml',
    'aquavanjaram_Cijk_Ailk_Bljk_HHS_BH_Bias_HAS_SAV_UserArgs_dtree.yaml',
    'aquavanjaram_Cijk_Alik_Bljk_HHS_BH_Bias_HAS_SAV_UserArgs_dtree.yaml',
]
# Iterate through all files recursively
for dirpath, dirnames, filenames in os.walk(working_dir):
    for filename in filenames:
        if filename not in yamls_to_skip:
            list_of_args.append(os.path.join(dirpath, filename))

import multiprocessing
from itertools import repeat

print("Start cleaning")

with multiprocessing.Pool(multiprocessing.cpu_count()) as p:
    p.starmap(clean_file, zip(list_of_args, repeat(defaulParamDict)))
