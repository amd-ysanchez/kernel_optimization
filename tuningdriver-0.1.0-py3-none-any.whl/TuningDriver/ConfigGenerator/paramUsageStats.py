"""
This python script goes through all library logics in hipBlasLt and
collects kernel parameter usage statistics
Example -

python3 ./paramUsageStats.py --hipblaslt-root ~/workspace/hipBLASLt --liblogic-out-dump liblogic_dump_all
 - Read all library logic files and serialize the container used for later use. Useful if planning to parse lots of lib logic files

python3 ./paramUsageStats.py --hipblaslt-root ~/workspace/hipBLASLt --liblogic-input-file <full path to lib logic yaml file> --param _DepthUA
 - Get usage statistics for _DepthUA for specific yaml file

python3 ./paramUsageStats.py --hipblaslt-root ~/workspace/hipBLASLt --liblogic-input-file <full path to lib logic yaml file> --list-benchmark-params
 - List all benchmark parameters, excluding ones set to default values

python3 ./paramUsageStats.py --hipblaslt-root ~/workspace/hipBLASLt --liblogic-input-file <full path to lib logic yaml file> --print-benchmark-param-stats
 - List all benchmark parameters, excluding ones set to default values, and show the usage count for each value for that parmater
"""

import os
import sys
import yaml
from yaml import CLoader as Loader, CDumper as Dumper
import time
import pickle
import argparse
import matplotlib.pyplot as plt

parser = argparse.ArgumentParser()

parser.add_argument("--hipblaslt-root", action="store", type=str)
# specific library logic file to parse
parser.add_argument("--liblogic-input-file", action="store", type=str)
# Serialize the containers used after reading the yaml files to be used later
parser.add_argument("--liblogic-out-dump", action="store", type=str)
# Point to previous serialized container, if not provided the yaml file is read
parser.add_argument("--liblogic-in-dump", action="store", type=str)

# print all parameter usage stats used by kernels in the library logic (excluding ones set to default value)
parser.add_argument("--print-all-param-stats", action="store_true")
# print all benchmark parameter usage stats used by kernels in the library logic (excluding ones set to default value)
parser.add_argument("--print-benchmark-param-stats", action="store_true")
parser.add_argument("--print-other-param-stats", action="store_true")
# list all parameters used by kernels in the library logic
parser.add_argument("--list-all-params", action="store_true")
parser.add_argument("--list-benchmark-params", action="store_true")
parser.add_argument("--list-other-params", action="store_true")
# Usage stat for a specific parameter
parser.add_argument("--param", action="store", type=str)

args = parser.parse_args()

hipblaslt_path = args.hipblaslt_root
lib_logic_root_path = "library/src/amd_detail/rocblaslt/src/Tensile/Logic/asm_full"
working_dir = os.path.join(hipblaslt_path, lib_logic_root_path)
sys.path.insert(0,os.path.join(hipblaslt_path,'tensilelite'))

from Tensile import Common

defaulParamDict = Common.defaultSolution

# ignore these yaml files, the library logic structure seems to be different
yamls_to_skip = [
    'aquavanjaram_Cijk_Ailk_Bjlk_HHS_BH_Bias_HAS_SAV_UserArgs_dtree.yaml',
    'aquavanjaram_Cijk_Ailk_Bljk_HHS_BH_Bias_HAS_SAV_UserArgs_dtree.yaml',
    'aquavanjaram_Cijk_Alik_Bljk_HHS_BH_Bias_HAS_SAV_UserArgs_dtree.yaml',
]

# GlobalSplitU, LocalSplitU (third parameter in WorkGroup),  WorkGroupMapping, WorkGroupMappingXCCGroup
params_to_ignore = [
    'ProblemType',
    'GlobalSplitU',
    'LocalSplitU',
    'WorkGroupMapping',
    'WorkGroupMappingXCCGroup',
    'CustomKernelName',
    'KernelNameMin',
    'ProblemType',
    'SolutionNameMin',
    'SolutionIndex',
]

skipTrack = [
    'CustomKernelName',
    'KernelNameMin',
    'ProblemType',
    'SolutionNameMin',
    'SolutionIndex',
]

class allLibLogic:
    def __init__(self, commonParams, defaultParamVals):
        # Parameters stored in Common.py
        self.commonParams = commonParams
        # Parameters stored in defaultBenchmarkCommonParameters in Common.py
        self.defaultParamsDict = defaultParamVals

        # Dict to count number of times each value for a specific parameter is used
        self.commonParamsValCount = {}
        for k in commonParams.keys():
            self.commonParamsValCount[k] = {}

        # Other parameters used, but not in Common.py
        self.otherParamsValCount = {}

        # Store each library logic
        self.libLogic = {}
        self.total_kernel = 0
        self.total_kernel_filt = 0

    def add_kv(self, k, v):
        if k in skipTrack: return
        # convert lists to str (make hashable)
        if type(v) == list: v = str(v)
        elif type(v) == dict: v = str(v.items())

        if k in self.commonParams.keys():
            keyDict = self.commonParamsValCount[k]
            if v in keyDict: keyDict[v] += 1
            else: keyDict[v] = 1
        else:
            # Add (key,value) pair to list of params not in Common.py
            if k in self.otherParamsValCount:
                keyDict = self.otherParamsValCount[k]
                if v in keyDict: keyDict[v] += 1
                else: keyDict[v] = 1
            else:
                self.otherParamsValCount[k] = {}
                self.otherParamsValCount[k][v] = 1

    def add_lib(self, filename, ll_data):
        ll = LibLogic(ll_data, self.commonParams, self.defaultParamsDict)
        self.libLogic[filename] = ll

        probtypeset = set()
        for ker in ll.kernels:
            kernel = pickle.loads(ker)
            for k,v in kernel.items():
                self.add_kv(k,v)
                if k == 'ProblemType':
                    probtypeset.add(k)

    def print_stats(self):
        for k in self.commonParamsValCount.keys():
            print("Key:", k)
            if k in self.defaultParamsDict.keys():
                print(" default:", self.defaultParamsDict[k])
            for v in self.commonParamsValCount[k].keys():
                print(" values:", v, ", count:", self.commonParamsValCount[k][v])
            print("================================================================")

        print("/////////////////////////////////////////////////////////////////////")

        skipPrint = []
        for k in self.otherParamsValCount.keys():
            print("Key (Others):", k)
            for v in self.otherParamsValCount[k].keys():
                print(" values:", v, ", count:", self.otherParamsValCount[k][v])
            print("================================================================")

class LibLogic:

    def __init__(self, ll_data, commonParams, defaultParamsDict):
        self.commonParamsValCount = {}
        for k in commonParams.keys():
            self.commonParamsValCount[k] = {}
        self.otherParamsValCount = {}
        self.commonParams = commonParams

        # if default value dict is in yaml, use that instead
        if len(ll_data) > 12:
            self.defaultParamsDict = ll_data[12]
        else:
            self.defaultParamsDict = defaultParamsDict

        def add_kv(k, v):
            if k in skipTrack: return
            # convert lists to str (make hashable)
            if type(v) == list: v = str(v)
            elif type(v) == dict: v = str(v.items())

            if k in commonParams.keys():
                keyDict = self.commonParamsValCount[k]
                if v in keyDict: keyDict[v] += 1
                else: keyDict[v] = 1
            else:
                # Add (key,value) pair to list of params not in Common.py
                if k in self.otherParamsValCount:
                    keyDict = self.otherParamsValCount[k]
                    if v in keyDict: keyDict[v] += 1
                    else: keyDict[v] = 1
                else:
                    self.otherParamsValCount[k] = {}
                    self.otherParamsValCount[k][v] = 1

        self.kernels = set()
        # Filter out kernels with generate same asm kernels
        for kernel in ll_data[5]:
            for p in params_to_ignore:
                if p in kernel.keys():
                    del kernel[p]
            for p in defaultParamsDict.keys():
                if p in kernel.keys() and kernel[p] == defaultParamsDict[p]:
                    del kernel[p]
            self.kernels.add(pickle.dumps(kernel))
            for k,v in kernel.items():
                if k != 'ProblemType': add_kv(k,v)

    def print_stats_benchmark(self):
        for k in self.commonParamsValCount.keys():
            if len(self.commonParamsValCount[k]) == 0: continue
            print("Key:", k)
            if k in self.defaultParamsDict.keys():
                print(" default:", self.defaultParamsDict[k])
            for v in self.commonParamsValCount[k].keys():
                print(" values:", v, ", count:", self.commonParamsValCount[k][v])
            print("================================================================")

    def print_stats_other(self):
        skipPrint = []
        for k in self.otherParamsValCount.keys():
            print("Key (Others):", k)
            for v in self.otherParamsValCount[k].keys():
                print(" values:", v, ", count:", self.otherParamsValCount[k][v])
            print("================================================================")

parameterDict = Common.validParameters
defaulParameterVal = Common.defaultSolution

libLogics = allLibLogic(parameterDict, defaulParameterVal)

def parse_file(filename, libLogics):
    t0 = time.time()
    f = open(filename, 'r')
    ll_data = yaml.load(f, Loader=Loader)
    t1 = time.time()

    libLogics.add_lib(filename, ll_data)

    t2 = time.time()

    numKernels = len(ll_data[5])
    print("Parsing", filename, " num kernels:", numKernels)
    print(" - time to load:", t1 - t0)
    print(" - time to add kv:", t2 - t1)
    return



files_to_check = []

if args.liblogic_input_file != None:
    files_to_check.append(args.liblogic_input_file)
else:
    # Iterate through all files recursively
    for dirpath, dirnames, filenames in os.walk(working_dir):
        for filename in filenames:
            if filename not in yamls_to_skip:
                files_to_check.append(os.path.join(dirpath, filename))

if args.liblogic_in_dump == None:
    for f in files_to_check:
        parse_file(f, libLogics)
else:
    libLogics = pickle.load(open(args.liblogic_in_dump, "rb"))

# store libs classes to skip parsing yaml later
if args.liblogic_out_dump != None:
    pickle.dump(libLogics, open(args.liblogic_out_dump, "wb"))

if args.liblogic_input_file != None:

    if args.print_all_param_stats == True:
        libLogics.libLogic[args.liblogic_input_file].print_stats_benchmark()
        libLogics.libLogic[args.liblogic_input_file].print_stats_other()
        exit(0)

    if args.print_benchmark_param_stats == True:
        libLogics.libLogic[args.liblogic_input_file].print_stats_benchmark()
        exit(0)

    if args.print_other_param_stats == True:
        libLogics.libLogic[args.liblogic_input_file].print_stats_other()
        exit(0)

    if args.list_all_params == True:
        for k in libLogics.libLogic[args.liblogic_input_file].commonParamsValCount.keys():
            if len(libLogics.libLogic[args.liblogic_input_file].commonParamsValCount[k]) > 0:
                print(k)
        for k in libLogics.libLogic[args.liblogic_input_file].otherParamsValCount.keys():
            print(k)
        exit(0)

    if args.list_benchmark_params == True:
        for k in libLogics.libLogic[args.liblogic_input_file].commonParamsValCount.keys():
            if len(libLogics.libLogic[args.liblogic_input_file].commonParamsValCount[k]) > 0:
                print(k)
        exit(0)

    if args.list_other_params == True:
        for k in libLogics.libLogic[args.liblogic_input_file].otherParamsValCount.keys():
            print(k)
        exit(0)


    if args.param != None:
        key = args.param
        vals = []
        count = []
        total = 0

        keyValCount = None
        if key in libLogics.libLogic[args.liblogic_input_file].otherParamsValCount.keys():
            keyValCount = libLogics.libLogic[args.liblogic_input_file].otherParamsValCount[key]
        elif key in libLogics.libLogic[args.liblogic_input_file].commonParamsValCount.keys():
            keyValCount = libLogics.libLogic[args.liblogic_input_file].commonParamsValCount[key]
        else:
            exit(1)

        for k, v in keyValCount.items():
            vals.append(str(k))
            count.append(v)

            print("Key value:", k, " usage count:", v)
            total += v

    # Save plot figure to file
    #figure = plt.gcf()
    #figure.set_size_inches(80, 40)
    #plt.bar(vals, count, color='r')
    #plt.savefig('test.png', dpi=100)
