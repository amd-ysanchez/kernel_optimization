"""
This python script takes the PMLog csv file and corresponding 
text file to compute the efficiency.
Example - 
python3 ../../scripts/autoPerf.py pmlog_518_ri.csv pmlog_518_ri.txt 228 2048
"""

import csv
import os
import os.path as osp
import argparse
import numpy as np

VERBOSE = True # to print VERBOSE print statements

PMLOG_KEYS = ["CPU0 XCD XCD0 Pre Deep Sleep Freq",
            "CPU0 XCD XCD1 Pre Deep Sleep Freq",
            "CPU0 XCD XCD2 Pre Deep Sleep Freq",
            "CPU0 XCD XCD3 Pre Deep Sleep Freq",
            "CPU0 XCD XCD4 Pre Deep Sleep Freq",
            "CPU0 XCD XCD5 Pre Deep Sleep Freq",
            "CPU0 XCD XCD0 Post Deep Sleep Freq",
            "CPU0 XCD XCD1 Post Deep Sleep Freq",
            "CPU0 XCD XCD2 Post Deep Sleep Freq",
            "CPU0 XCD XCD3 Post Deep Sleep Freq",
            "CPU0 XCD XCD4 Post Deep Sleep Freq",
            "CPU0 XCD XCD5 Post Deep Sleep Freq",
            "CPU0 XCD XCD0 Busy"]

TOPLOT = True
if TOPLOT:
    try:
        from matplotlib import pyplot as plt
    except ImportError as e:
        import subprocess
        import sys
        subprocess.check_call([sys.executable, "-m", "pip", "install", "matplotlib"])

    from matplotlib import pyplot as plt

def parseArgs():
    argParser = argparse.ArgumentParser()

    h = {"pmlog"   : "Path to the pm log csv file",
         "log"     : "Path to the log file with performance data",
         "numCUs"  : "Number of CUs for efficiency calculation",
         "ALURate" : "ALU rate for efficiency calculation"
    }

    argParser.add_argument("pmlog", type=str, help=h["pmlog"])
    argParser.add_argument("log", type=str, help=h["log"])
    argParser.add_argument("numCUs", type=int, help=h["numCUs"])
    argParser.add_argument("ALURate", type=int, help=h["ALURate"])

    return argParser.parse_args()

def has_numbers(inputString):
    return any(char.isdigit() for char in inputString)

def parseTextLogData(args):
    """
    This file parses log text data 
    and returns the perf data.
    """
    tFile = open(args.log, 'r')
    tData = tFile.readlines()
    DATA = []
    for line in tData:
        fields = line.split(',')
        if len(fields) != 14 : continue
        fields[-1] = fields[-1][:-1] # remove the newline char
        for k in range(14):
            if not has_numbers(fields[k]): continue
            fields[k] = float(fields[k])
        DATA.append(fields)
    
    HEADER = DATA[0]
    DATA = [DATA[i] for i in range(1,16,2)]
    
    if VERBOSE: 
        print("Perf data from log file")
        for d in DATA: print(d)
        print("####################################################################################################")

    return HEADER, DATA

def parseCSVLogData(args):
    """
    This function reads the csv data 
    and returns a dict with the data.
    """
    # Reference - https://stackoverflow.com/questions/30685363/python-csv-to-dictionary-columnwise
    columns = []
    reader = csv.reader(open(args.pmlog,'r'))
    for row in reader:
        if columns:
            for i, value in enumerate(row):
                columns[i].append(value)
        else:
            # first row
            columns = [[value] for value in row]
    # you now have a column-major 2D array of your file.
    pmDict = {c[0] : c[1:] for c in columns}
    PMDICT = {}
    for k in pmDict.keys():
        if k not in PMLOG_KEYS: continue
        PMDICT[k] = [float(x) for x in pmDict[k]]
    # if VERBOSE: 
    #     for k in PMDICT.keys():print(k)
    return PMDICT

def min_(a : list):
    m = a[0]
    for i in range(1, len(a)): m = min(m, a[i])
    return m

def computeFreq(args):
    f = [csvDataDict[PMLOG_KEYS[k]] for k in range(6)]
    
    if TOPLOT:
        print("PLOTTING ....")
        for freq in f: plt.plot(range(len(freq)),freq) 
        plt.savefig(osp.join(FILENAME, 'freq_plot.png'), dpi=1200, format='png', bbox_inches='tight')
        print("PLOT SAVED!")
        print("")

    b = csvDataDict[PMLOG_KEYS[-1]]

    freq = []
    sum = []
    i = 0
    sIndex = eIndex = -1

    while True:
        while i < len(b) and b[i] != 100.00: i+=1 
        if i >= len(b): break
        sIndex = i
        while i < len(b) and b[i] == 100.00: i+=1
        eIndex = i
        avg_f = [0, 0, 0, 0, 0, 0]
        for idx in range(sIndex, eIndex):
            for xcd in range(6): avg_f[xcd] += f[xcd][idx]
        for xcd in range(6): avg_f[xcd] /= (eIndex-sIndex)
        freq.append(min_(avg_f))
    
    # if VERBOSE: print(freq)

    return freq


def autoPerf(args):
    # Resultant graphs and eff numbers (CSV) are dumped in
    # a folder with same name as the pmlog csv file. 
    # In case folder exists a _<Verison> will be appended
    pathName, fileName = os.path.split(args.pmlog)
    FILENAME = fileName.split('.')[0]
    version = 1
    while osp.exists(FILENAME): 
        FILENAME += "_" + str(version)
        version+=1
    os.makedirs(FILENAME)

    # Read text data
    header, perfData = parseTextLogData(args)

    # Read data from csv data
    csvDataDict = parseCSVLogData(args)

    # Compute freq for each size
    freq = computeFreq(args)

    # Hyper-params to compute eff. 
    numCUs = args.numCUs
    ALURate = args.ALURate

    # check number of sizes are same
    assert len(freq) == len(perfData), "Did not get same number of sizes from csv and text log file"

    for i in range(len(freq)):
        GFLOPS = perfData[i][-2]
        peakPerf = numCUs * ALURate * freq[i] / 1000
        eff = GFLOPS * 100 / peakPerf
        perfData[i].append(eff)

    header.append("Eff")
    print("Efficiency Data - ")
    print(header)

    # Write eff data as csv file
    writer = csv.DictWriter(open(osp.join(FILENAME, "EFF.csv"), 'w'), fieldnames = header)
        
    # writing data row-wise into the csv file
    writer.writeheader()
    for p in perfData:
        print(p)
        rowDict = {}
        for i in range(len(header)): rowDict[header[i]] = p[i]
        writer.writerow(rowDict)

if __name__ == "__main__":
    args = parseArgs()
    print(args)
    print("")
    autoPerf(args)