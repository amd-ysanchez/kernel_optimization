
# Usage:
# python3 MIGenerator.py -d H --mt0min 4  --mt1min 4  --mt0max 256  --mt1max 256 

import argparse
import os
import sys
# sys.path.insert(0,os.path.dirname(sys.path[0]))

sys.path.append(os.path.join(os.path.dirname(sys.path[0]),'..','Tensile'))
sys.path.append(os.path.join(os.path.dirname(sys.path[0]),'..'))
#from DataType import DataType

# print(os.path.dirname(sys.path[0]))
# print(os.path.dirname(sys.path[1]))
# print(os.path.join(os.path.dirname(sys.path[0]),'..','Tensile'))

# from ..Tensile.Common import validMFMA
#from Common import validMFMA
# from ... import Common
# import Common

# from ..Tensile.Common import validMFMA

import math


validMFMA = {}
validMFMA["H"] = [[32,32,4,2], [32,32,8,1], [16,16,4,4], [16,16,16,1], [4,4,4,16]]
validMFMA["S"] = [[32,32,1,2], [32,32,2,1], [16,16,1,4], [16,16,4,1], [4,4,1,16]]
validMFMA["B"] = [[32,32,2,2], [32,32,4,1], [16,16,2,4], [16,16,8,1], [4,4,2,16]]
validMFMA["D"] = [[16,16,4,1], [4,4,4,4]]
validMFMA["B1k"] = validMFMA["H"]
validMFMA["C"] = validMFMA["S"]
validMFMA["Z"] = validMFMA["D"]
validMFMA["X"] = [[32,32,4,1], [16,16,8,1]]
validMFMA["F8"] = [[32,32,16,1], [16,16,32,1]]
validMFMA["B8"] = validMFMA["F8"]
validMFMA["F8B8"] = validMFMA["F8"]
validMFMA["B8F8"] = validMFMA["F8"]
validMFMA["I8_908"] = [[32,32,4,2], [32,32,8,1], [16,16,4,4], [16,16,16,1], [4,4,4,16]]
validMFMA["I8_940"] = [[32,32,4,2], [32,32,16,1], [16,16,4,4], [16,16,32,1], [4,4,4,16]]
validMFMA["I8"] = validMFMA["H"] + validMFMA["F8"]

computeDataTypeSize = {}
computeDataTypeSize["H"] = 4
computeDataTypeSize["B"] = 4
computeDataTypeSize["S"] = 4
computeDataTypeSize["D"] = 8
computeDataTypeSize["C"] = 8
computeDataTypeSize["Z"] = 16
computeDataTypeSize["I8"] = 4
computeDataTypeSize["X"] = 4
computeDataTypeSize["F8"] = 4

def parseArgs():
    argParser = argparse.ArgumentParser()

    h = {"datatype" : "Input datatype. Valid items are: H, S, B, D, C, Z, X, I8, and F8 (for all functions). Default: S.",
         "outdir"   : "Output directory for MI yaml files. Default: ./.",
         "filename" : "Output filename for MI yaml files. Default: MI_\{dataype\}.yaml.",
         "MT0_MIN"  : "Minimum allowable MT0. Default: 64.",
         "MT0_MAX"  : "Maximum allowable MT0. Default: 512.",
         "MT1_MIN"  : "Minimum allowable MT1. Default: 64.",
         "MT1_MAX"  : "Maximum allowable MT1. Default: 512.",
         "lsuSize"  : "Specify LSU size. Default: 65536.",
         "display"  : "Print the results on screen."
    }


    argParser.add_argument("--datatype", "-d", action="store", type=str, default = 'S', help=h["datatype"])
    # argParser.add_argument("--datatype", "-d", action="store", type=str, help=h["datatype"])
    argParser.add_argument("--outdir", "-o",   action="store", type=str, default = '.', help=h["outdir"])
    argParser.add_argument("--file", "-f",     action="store", type=str, default = '',  help=h["filename"])
    argParser.add_argument("--mt0min",         action="store", type=int, default = 64,  help=h["MT0_MIN"])
    argParser.add_argument("--mt0max",         action="store", type=int, default = 512, help=h["MT0_MAX"])
    argParser.add_argument("--mt1min",         action="store", type=int, default = 64,  help=h["MT1_MIN"])
    argParser.add_argument("--mt1max",         action="store", type=int, default = 512, help=h["MT1_MAX"])
    argParser.add_argument("--lsuSize",        action="store", type=int, default = 65536, help=h["lsuSize"])
    argParser.add_argument("--show", "-s",     action="store_true",                     help=h["display"])

    return argParser.parse_args()

def gen_MIBlockM(MI):
    for bm in range(int(math.log(MI[3], 2)) + 1):
        yield 2**bm

def main():

    args = parseArgs()

    outdir = args.outdir

    if not (args.datatype in ['H', 'S', 'B', 'D', 'C', 'Z', 'X', "F8", "I8"]):
        raise RuntimeError(f"{args.datatype} is not a valid data type. Choose from H, S, B, D, C, Z, X, I8, and F8 (for all functions).")
    datatype = args.datatype
    filename="MI_"+datatype+".yaml" if args.file=='' else args.file+".yaml"
    MT0_MIN = args.mt0min
    MT1_MIN = args.mt1min

    MT0_MAX = args.mt0max
    MT1_MAX = args.mt1max

    waves=[[1,1],[1,2],[2,1],[2,2],[4,1],[1,4]]

    out = open(os.path.join(outdir, filename),'w')
    txt = f" printing Matrix Instructions for {datatype} - MT {MT0_MIN}~{MT0_MAX}x{MT1_MIN}~{MT0_MAX}"
    if args.show:
        print(txt)

    out.write("# "+txt+"\n")
    TXT = {}

    for MI in reversed(validMFMA[datatype]):
        if args.show:
            print()
        for MIBlockM in gen_MIBlockM(MI):
            for wave in waves:
                waveTileM = 0
                waveTileN = 0
                MT0list = []
                while True:
                    waveTileM+=1
                    MatrixInstM = MI[0] * MIBlockM
                    MT0 = MatrixInstM * waveTileM * wave[0]
                    if MT0>MT0_MAX:
                        break
                    MT0list.insert(0, [waveTileM, MT0]) # add to the top (larger one comes first)

                for waveTileM, MT0 in MT0list:
                    waveTileN=0
                    if MT0<MT0_MIN:
                        continue
                    if args.show:
                        print()
                    while True:
                        waveTileN+=1
                        MatrixInstN = MI[1] / MIBlockM * MI[3]
                        MT1 = int(MatrixInstN * waveTileN * wave[1])
                        TT0 = waveTileM
                        TT1 = waveTileN * MI[1]
                        WG0 = MatrixInstM * wave[0]
                        WG1 = int(wave[0] * wave[1] * 64 / WG0)

                        if MT1<MT1_MIN:
                            continue
                        if MT1>MT1_MAX:
                            break
                        # LDS size check for lsu
                        LSU = max(1, 4//wave[0]//wave[1])
                        if LSU > 1 and MT0*MT1*computeDataTypeSize[datatype]*LSU > args.lsuSize:
                          continue

                        txt ="- ["
                        tmp =  ", ".join("{:>2}".format(str(x)) for x in MI)

                        txt+=tmp+', {:>2}, '.format(MIBlockM)
                        txt+="{:3}, {:3}, {:2},  {:2}]  # MT {:7} - TT {:6} - WG {:6} - MIBlockM {}".format(waveTileM, waveTileN, wave[0], wave[1], "{}x{}".format(MT0, MT1), "{}x{}".format(TT0, TT1), "{}x{}".format(WG0, WG1), MIBlockM)
                        if args.show:
                            print(txt)
                        k = "{}x{}".format(MT0, MT1)
                        if k not in TXT.keys(): TXT[k] = []
                        TXT[k].append(txt)
    
    for k in TXT.keys(): 
        out.write("#" + k + '\n')
        for v in TXT[k]:
            out.write(v+'\n')
    out.close()

if __name__=="__main__":
    main()