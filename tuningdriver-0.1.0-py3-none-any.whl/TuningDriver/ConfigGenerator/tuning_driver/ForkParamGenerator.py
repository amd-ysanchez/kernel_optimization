from Constants import *
from Parameter import *
from MIDesigner import MIDesign
import os
from Helper import get_num_kernels


class ForkParamGenerator:

    def get_MIFinder_LogName(self):

        GEMM_type = self.config['DataType'] + self.config['DestDataType'] + \
            self.config['ComputeDataType']+'_' + self.config['TRANSA'] + self.config['TRANSB']
        M_dim, N_dim, B_dim, K_dim = self.config["Sizes"][0]
        catName = f'_M{M_dim}'+f'_N{N_dim}'+f'_B{B_dim}'+f'_K{K_dim}'
        # TODO: math the name with the lib name convension
        mi_finder_log_name = os.path.join(self.outputPath, "MI_finder_log", 'build_'+GEMM_type+catName)

        return mi_finder_log_name

    def generate_MI_Groups(self):
        miFinderPath = self.get_MIFinder_LogName()

        # TODO bbk, use this: MAX_NUM_KERNELS_PER_CONFIG
        mi_design_obj = MIDesign(miFinderPath, self.config)
        param_class_factory = self.param_factory.param_class_factory

        mfmas = []
        MI_Groups = mi_design_obj.MI_Groups
        comments = mi_design_obj.comments
        usePGR1 = False
        useWGM1 = False
        # Use large DepthU val of 1024 for mem bound sizes with large K
        useLargeDepthU = False
        for idx, MI_Group in enumerate(MI_Groups):
            mfma = {}
            mfma.update(param_class_factory["MatrixInstruction"](MI_Group["MatrixInstruction"], comments[idx]))
            if "WorkGroup" in MI_Group.keys():
                mfma.update(param_class_factory["WorkGroup"](MI_Group["WorkGroup"]))

            if ("GlobalSplitU" in MI_Group.keys() and not self.config['StreamK']):  # bbk
                mfma.update(param_class_factory["GlobalSplitU"](MI_Group["GlobalSplitU"]))
            MT0, MT1, _, _, _, _, _ = mi_design_obj.calculate_mfma_parameters(MI_Group["MatrixInstruction"])
            if MT0 * MT1 >= self.config['LIST_OF_MT_MAX_SIZE'][self.config["DataType"]] // 3:
                mfma.update(param_class_factory["MIArchVgpr"](0))
            usePGR1 = usePGR1 or (MT0 < 64 and MT1 < 64)
            # Use large DepthU val of 1024 for mem bound sizes with large K
            # if (MT0*MT1 >= 128*256): mfma.update(param_class_factory["1LDSBuffer"](1))
            # else: mfma.update(param_class_factory["1LDSBuffer"](0))

            useLargeDepthU = useLargeDepthU or (self.size[-1] > 1024 and MT0*MT1 < 64*64)
            useWGM1 = useWGM1 or (MT0 <= 32 and MT1 <= 32)
            mfmas.append(mfma)

        return mfmas, mi_design_obj.MIsPerSize, usePGR1, useLargeDepthU, useWGM1

    def generate_CLR_LDSTrI(self):
        CLR_LDSTrI_Groups = []
        param_class_factory = self.param_factory.param_class_factory

        CLR_LDSTrI = get_CLR_LDSTrI(dataSize[self.config["DataType"]], self.config["TRANSA"], self.config["TRANSB"])

        for c_l in CLR_LDSTrI:
            CLR_LDSTrI_Group = {}
            CLR_LDSTrI_Group.update(param_class_factory["ClusterLocalRead"](c_l[0]))
            CLR_LDSTrI_Group.update(param_class_factory["LDSTrInst"](c_l[1]))
            # if len(c_l) == 3:
            #   CLR_LDSTrI_Group.update(param_class_factory["1LDSBuffer"](c_l[2]))
            CLR_LDSTrI_Groups.append(CLR_LDSTrI_Group)
        return CLR_LDSTrI_Groups

    def generate_NTCD_Groups(self):
        """
        Generate NTCD Groups.
        """
        M_dim, N_dim, _, _ = self.size

        NTCDs = get_NTCD_values(M_dim, N_dim)
        param_class_factory = self.param_factory.param_class_factory

        NTCD_Groups = []
        for ntcd in NTCDs:
            NTCD_Group = {}
            NTCD_Group.update(param_class_factory["NonTemporalC"](ntcd))
            NTCD_Group.update(param_class_factory["NonTemporalD"](ntcd))
            NTCD_Groups.append(NTCD_Group)

        return NTCD_Groups

    def generate_BenchmarkProblems_Groups(self):
        # adjust CUs with B_dim (roundUp CUs/B_dim)
        M_dim, N_dim, B_dim, K_dim = self.size

        result = []

        # Group for NonTemporal C/D
        NTCD_Groups = self.generate_NTCD_Groups()
        result.append(NTCD_Groups)

        # Group for CLR and LDSInst
        CLR_LDSTrI_Groups = self.generate_CLR_LDSTrI()

        sizes_temp = self.config['Sizes']  # PK - temp code to find MI for 1 size at a time.
        self.config['Sizes'] = [[M_dim, N_dim, B_dim, K_dim]]
        MI_Groups, MIsPerSize, usePGR1, useLargeDepthU, useWGM1 = self.generate_MI_Groups()
        self.config['Sizes'] = sizes_temp
        result.append(MI_Groups)
        result.append(CLR_LDSTrI_Groups)

        return result, MIsPerSize, usePGR1, useLargeDepthU, useWGM1

    def __call__(self):  # tuningConfigFile
        config = self.config
        M_dim, N_dim, B_dim, K_dim = self.size

        result = {}  # dict mapping param name to param obj.

        param_class_factory = self.param_factory.param_class_factory
        params_default_impl = self.param_factory.params_default_impl

        for param in params_default_impl:
            cls = param_class_factory[param]
            result.update(cls())

        result.update(param_class_factory["PrefetchLocalRead"]())
        result.update(param_class_factory["DirectToVgprA"](config["TRANSA"],
                      config["TRANSB"], config["DataType"], "A", M_dim, N_dim, config["CUs"]))
        result.update(param_class_factory["DirectToVgprB"](config["TRANSA"],
                      config["TRANSB"], config["DataType"], "B", M_dim, N_dim, config["CUs"]))
        result.update(param_class_factory["GlobalReadVectorWidthA"](config["GRID"],
                      config["TRANSA"], config["DataType"], "A", M_dim, N_dim, config["CUs"]))
        result.update(param_class_factory["GlobalReadVectorWidthB"](config["GRID"],
                      config["TRANSB"], config["DataType"], "B", M_dim, N_dim, config["CUs"]))
        result.update(param_class_factory["WaveSeparateGlobalReadA"](
            config["DataType"], config["TRANSA"], "A", M_dim, K_dim, config["CUs"]))
        result.update(param_class_factory["WaveSeparateGlobalReadB"](
            config["DataType"], config["TRANSB"], "B", M_dim, K_dim, config["CUs"]))
        result.update(param_class_factory["NumElementsPerBatchStore"](config["DataType"]))
        if N_dim > M_dim:
            result.update(param_class_factory["NonTemporalB"](M_dim, N_dim, K_dim, config["CUs"]))
        else:
            result.update(param_class_factory["NonTemporalA"](M_dim, N_dim, K_dim, config["CUs"]))
        result.update(param_class_factory["StaggerU"](config["TRANSA"],
                      config["TRANSB"], config["DataType"], M_dim, N_dim))
        result.update(param_class_factory["WorkGroupMappingXCC"]())
        result.update(param_class_factory["StorePriorityOpt"](M_dim, N_dim))
        result.update(param_class_factory["StoreSyncOpt"](M_dim, N_dim))
        result.update(param_class_factory["1LDSBuffer"](M_dim, N_dim, config["CUs"]))
        result.update(param_class_factory["StreamK"](config["StreamK"]))
        result.update(param_class_factory["StreamKXCCMapping"](config["StreamK"]))
        result.update(param_class_factory["UseSgprForGRO"](config["StreamK"], config["TRANSA"], config["TRANSB"]))
        result.update(param_class_factory["ClusterLocalRead"](config["DataType"], config["TRANSA"], config["TRANSB"]))
        result.update(param_class_factory["LocalReadVectorWidth"](
            config["DataType"], config["TRANSA"], config["TRANSB"]))
        result.update(param_class_factory["SourceSwap"]())
        result.update(param_class_factory["VectorWidthA"](config["DataType"], config["CUs"]))
        result.update(param_class_factory["VectorWidthB"](config["DataType"],
                      config["TRANSB"], config["DataType"], config["CUs"]))
        result.update(param_class_factory["GlobalSplitUAlgorithm"]())
        result.update(param_class_factory["ScheduleIterAlg"]())
        result.update(param_class_factory["MIArchVgpr"](1))
        result.update(param_class_factory["LDSTrInst"]())
        # result.update(param_class_factory["DirectToLDS"]())
        # TODO - rocblas logic, removed it.
        # result.update(VFLRP(config))
        # result.update(FL(config, M_dim, N_dim))
        # result.update(ASLT(config, M_dim, N_dim))
        # result.update(ASGT(config, B_dim))

        params_to_delete = []
        for param_name, param_obj in result.items():
            param_val = param_obj.get_val()
            if param_val == []:
                params_to_delete.append(param_name)
        for k in params_to_delete:
            result.pop(k)

        GRP, MIsPerSize, usePGR1, useLargeDepthU, useWGM1 = self.generate_BenchmarkProblems_Groups()

        usePGR1 = usePGR1 if config["CUs"] == 256 else False
        result.update(param_class_factory["PrefetchGlobalRead"](usePGR1, K_dim, config["TRANSA"], config["TRANSB"]))
        result.update(param_class_factory["DepthU"](M_dim, N_dim, config["CUs"], config["DataType"], useLargeDepthU))
        result.update(param_class_factory["WorkGroupMapping"](config["WGMUnit"],
                      config["DataType"], config["CUs"], M_dim, N_dim, useWGM1))

        result.update(param_class_factory["Groups"](GRP))
        nkernels = get_num_kernels(result)

        return result, MIsPerSize, nkernels

    def __init__(self, param_factory, config, M_dim, N_dim, B_dim, K_dim, outputPath):
        self.config = config
        self.outputPath = outputPath
        self.size = [M_dim, N_dim, B_dim, K_dim]
        self.param_factory = param_factory
