import subprocess
import reprlib

from Tensile.Common.GlobalParameters import defaultBenchmarkCommonParameters
from Tensile.Common.ValidParameters import validParameters

from Parameter import *


class ParameterFactory:
    @staticmethod
    def create_parameter_class(name, default_value=None, valid_values=None):
        """This static method creates classes for all parameters in tensilelite
           Uses custim implementations if available."""
        class_name = f"Param_{name}"
        if class_name in ParameterMeta.registry:
            param_class = ParameterMeta.registry[class_name]
            param_class._isCommented = False
        else:
            param_class = type(class_name, (DefaultParameter,), {})
        param_class._default_value = default_value
        param_class._valid_values = valid_values
        param_class._name = name
        return param_class

    def __init__(self):
        params1 = validParameters.keys()
        defaultParameters = {}
        for dp in defaultBenchmarkCommonParameters:
            defaultParameters.update(dp)
        params2 = defaultParameters.keys()
        params = set(params1).intersection(set(params2))

        param_class_factory = {}
        params_default_impl = []  # Parameters that do not have custom logic

        params_to_ignore = []  # Populate this list to skip a parameter.

        # Function to get the custom string representation of the range
        def get_custom_range_string(rng, start_elements=2, end_elements=2):
            if type(rng) is not list:
                return f'rng'
            if len(rng) < start_elements + end_elements:
                return f'{rng}'
            start_part = ', '.join(map(str, list(rng)[:start_elements]))
            end_part = ', '.join(map(str, list(rng)[-end_elements:]))
            return f'[{start_part[:]}, ... ,{end_part[:]}]'

        for param in params:
            if param in params_to_ignore:
                continue
            param_class_factory[param] = self.create_parameter_class(
                param, defaultParameters[param], get_custom_range_string(validParameters[param]))

        for class_name, cls in ParameterMeta.registry.items():
            param = class_name.split('_')[1]
            if param in param_class_factory:
                continue
            param_class_factory[param] = cls

        for param in param_class_factory:
            if f"Param_{param}" in ParameterMeta.registry.keys():
                continue
            params_default_impl.append(param)
        self.params_default_impl = params_default_impl
        self.param_class_factory = param_class_factory


if __name__ == "__main__":
    param_factory_obj = ParameterFactory()
    param_class_factory, params_default_impl = param_factory_obj.param_class_factory, param_factory_obj.params_default_impl
    for param, cls in param_class_factory.items():
        print(param, cls())
