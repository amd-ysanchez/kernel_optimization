import argparse
import yaml
import math
import sys
import os
from collections import defaultdict
from Constants import *


def parseArgs():
    argParser = argparse.ArgumentParser()

    h = {"configfile": "path to the input config file",
         "outputFile": "Output file/directory. It can take absolute/relative path.",
         }

    argParser.add_argument("config",             action="store",       type=str,
                           default='./config.yaml', help=h["configfile"])  # positional mandatory file
    argParser.add_argument("--outputfile", "-o", action="store", type=str,
                           default='./MatInst',     help=h["outputFile"])

    return argParser.parse_args()


class MIDesign:

    @staticmethod
    def calculate_granularities(MT0, MT1, M, N, batch_count, CUs, LSU,  GSU, wave):

        NumTile0 = M / float(MT0)
        NumTile1 = N / float(MT1)
        Tile0Granularity = NumTile0/math.ceil(NumTile0)
        Tile1Granularity = NumTile1/math.ceil(NumTile1)

        TotalTiles = math.ceil(NumTile0) * math.ceil(NumTile1) * batch_count * GSU * LSU

        TilesPerCU = TotalTiles / CUs
        CUGranularity = TilesPerCU / math.ceil(TilesPerCU)
        SIMDPerCU = 4

        waveGranularity = min(1.0, math.floor(TilesPerCU+1.0) * wave[0]*wave[1]*LSU / SIMDPerCU)
        totalGranularity = Tile0Granularity * Tile1Granularity * CUGranularity * waveGranularity

        return NumTile0, NumTile1, Tile0Granularity, Tile1Granularity, TotalTiles, TilesPerCU, CUGranularity, waveGranularity, totalGranularity

    @staticmethod
    def calculate_mfma_parameters(MI, waveFrontSize=64):
        wave = MI[7], MI[8]
        MIBlockM = MI[4]
        waveTileM, waveTileN = MI[5], MI[6]

        MatrixInstM = MI[0] * MIBlockM
        MT0 = MatrixInstM * waveTileM * wave[0]

        MatrixInstN = MI[1] / MIBlockM * MI[3]
        MT1 = int(MatrixInstN * waveTileN * wave[1])
        TT0 = waveTileM
        TT1 = waveTileN * MI[1]
        WG0 = MatrixInstM * wave[0]
        WG1 = int(wave[0] * wave[1] * waveFrontSize / WG0)

        return MT0, MT1, TT0, TT1, WG0, WG1, MIBlockM

    def generate_all_mfmas(self):
        valid_mfmas = []

        bm_max = 0
        # Based on our experiance MIBlockM>1 is not a winner. To test MIBlocM>1, uncomment the following line.
        # bm_max = int(math.log(MI[3], 2))

        smallest_M_in_MFMA = 512
        smallest_N_in_MFMA = 512
        for mfma in self.config['ONLY_INCLUDE_MIs'][self.config['DataType']]:
            # print(mfma[0], mfma[1])
            if mfma[0] < smallest_M_in_MFMA:
                smallest_M_in_MFMA = mfma[0]

            if mfma[1] < smallest_N_in_MFMA:
                smallest_N_in_MFMA = mfma[1]

        for MI in reversed(validMFMA[self.config['DataType']]):
            if self.config['ONLY_INCLUDE_MIs'] is not None and tuple(MI) not in self.config['ONLY_INCLUDE_MIs'][self.config['DataType']]:
                continue

            for bm in range(bm_max + 1):
                MIBlockM = 2 ** bm

                for wave in self.config['LIST_OF_WAVEs_TO_INCLUDE']:
                    waveTileM = 0
                    waveTileN = 0

                    while True:
                        waveTileM += 1
                        waveTileN = 0
                        MatrixInstM = MI[0] * MIBlockM
                        MT0 = MatrixInstM * waveTileM * wave[0]
                        if MT0 < self.config['MIN_MT0']:
                            continue
                        if MT0 > self.config['MAX_MT0']:
                            break

                        while True:
                            waveTileN += 1
                            MatrixInstN = MI[1] / MIBlockM * MI[3]
                            MT1 = int(MatrixInstN * waveTileN * wave[1])

                            if MT1 < self.config['MIN_MT1']:
                                continue
                            if MT1 > self.config['MAX_MT1']:
                                break

                            # LDS size check for lsu
                            LSU = max(1, 4//wave[0]//wave[1])
                            if LSU > 1 and MT0*MT1*computeDataTypeSize[self.config['DataType']]*LSU > self.config['LSUTHRESHOLD']:
                                continue

                            if self.config['LIST_OF_MT_MAX_SIZE'] is not None:
                                if MT0*MT1 > self.config['LIST_OF_MT_MAX_SIZE'][self.config['DataType']]:
                                    continue

                            valid_mfmas.append([MI[0], MI[1], MI[2], MI[3], MIBlockM,
                                               waveTileM, waveTileN, wave[0], wave[1]])
        print(" Total number of MatrixInstructions: ", len(valid_mfmas))
        return valid_mfmas, smallest_M_in_MFMA, smallest_N_in_MFMA

    def find_MI_for_sizes(self, valid_mfmas, smallest_M_in_MFMA, smallest_N_in_MFMA):

        size_mfmas_dict = defaultdict(list)

        min_TilesPerCU = [sys.float_info.max] * len(self.config['Sizes'])
        max_TilesPerCU = [0] * len(self.config['Sizes'])
        min_TotalTile_PerSize = [sys.float_info.max] * len(self.config['Sizes'])
        max_TotalGranularity = [-1] * len(self.config['Sizes'])
        count_size = -1

        for size in self.config['Sizes']:

            print(f"working on {size}. First round of refining.")
            count_size += 1

            for mfma in valid_mfmas:
                MT0, MT1, TT0, TT1, WG0, WG1, MIBlockM = self.calculate_mfma_parameters(MI=mfma)

                # remove MI4x4 for larger MN
                if (mfma[0] == 4 and (size[0] >= 16 and size[1] >= 16)):
                    continue

                max_possible_LSU = int(4 / (mfma[-1] * mfma[-2]))

                if 'MaxGSU' not in self.config:
                    self.config['MaxGSU'] = max(math.floor(size[3]/self.config['MinKGSU']), 1)

                for LSU in range(1, max_possible_LSU+1):
                    if LSU == 3:
                        continue

                    for GSU in range(1, self.config['MaxGSU']+1):
                        if self.config['StreamK']:

                            # Skip [1, 2], [2, 1], and [1, 1] waves for larger sizes
                            if ((size[0] * size[1] > 65536) and (size[0] >= 64 and size[1] >= 64) and (mfma[-2] * mfma[-1] != 4)):
                                continue

                            if GSU > 1:  # TODO: do we still need this?
                                if (size[3] / GSU) < self.config['MinKGSU']:
                                    continue

                            NumTile0, NumTile1, Tile0Granularity, Tile1Granularity, TotalTiles, TilesPerCU, CUGranularity, waveGranularity, totalGranularity = self.calculate_granularities(
                                MT0, MT1, size[0], size[1], size[2], self.config['CUs'], LSU,  GSU, [mfma[7], mfma[8]])

                            # In case of SK, we go a bit higher in MTs. Two reasons for that:
                            # 1. SK tends to pick higher MTs
                            # 2. As we are limited by the Wave options, we wouldn't generate any MI for smaller sizes.
                            # for M= 16< we still want to test MI16x16, rather than just MI4x4
                            if (MT0 > 16 and MT0//2 > size[0] and size[0] >= smallest_M_in_MFMA):
                                break

                            if (MT1 > 16 and MT1//2 > size[1] and size[1] >= smallest_N_in_MFMA):
                                break

                            # To remove large edge MFMAs
                            if (size[0] < smallest_M_in_MFMA and MT0 > smallest_M_in_MFMA):
                                break

                            if (size[1] < smallest_N_in_MFMA and MT1 > smallest_N_in_MFMA):
                                break
                            min_TotalTile_PerSize[count_size] = min(min_TotalTile_PerSize[count_size], TotalTiles)
                            max_TotalGranularity[count_size] = max(max_TotalGranularity[count_size], totalGranularity)
                            size_mfmas_dict[tuple(size)].append((totalGranularity, TilesPerCU, tuple(mfma), NumTile0, NumTile1, Tile0Granularity,
                                                                 Tile1Granularity, TotalTiles, CUGranularity, waveGranularity, GSU, LSU, MT0, MT1, TT0, TT1, WG0, WG1, MIBlockM))
                        else:
                            if GSU > 1:  # TODO: do we still need this?
                                if (size[3] / GSU) < self.config['MinKGSU']:
                                    continue

                            WorkspaceSizePerElemC = computeDataTypeSize[self.config['ComputeDataType']]
                            gsuMultiplier = GSU if GSU > 1 else 0

                            if size[0] * size[1] * size[2] * WorkspaceSizePerElemC * gsuMultiplier > MAX_GSU_WORKSPACE_SIZE:
                                break

                            # TODO: BBK Koji, please check this condition.
                            if (LSU > 1 and ((MT0*MT1*LSU*computeDataTypeSize[self.config['DataType']] > 64*1024) or (MT0*MT1*LSU*computeDataTypeSize[self.config['DataType']] >= 64*1024 and self.config['TRANSA'] == "N" and self.config['TRANSB'] == "T"))):
                                break

                            NumTile0, NumTile1, Tile0Granularity, Tile1Granularity, TotalTiles, TilesPerCU, CUGranularity, waveGranularity, totalGranularity = self.calculate_granularities(
                                MT0, MT1, size[0], size[1], size[2], self.config['CUs'], LSU,  GSU, [mfma[7], mfma[8]])

                            # To remove all MIs that are all edges
                            # if ((MT0>size[0] or MT1>size[1]) and (size[0]>=16 and size[1]>=16)):
                            # continue

                            # to remove all MIs that one dimension is edge
                            # for M= 16< we still want to test MI16x16, rather than just MI4x4
                            if (MT0 > 16 and MT0 > size[0] and size[0] >= smallest_M_in_MFMA):
                                break

                            if (MT1 > 16 and MT1 > size[1] and size[1] >= smallest_N_in_MFMA):
                                break

                            # To remove large edge MFMAs
                            if (size[0] < smallest_M_in_MFMA and MT0 > smallest_M_in_MFMA):
                                break

                            if (size[1] < smallest_N_in_MFMA and MT1 > smallest_N_in_MFMA):
                                break

                            # TODO: to remove unnessary large GSUs - DOES NOT WORK - refer to the next condition at the end of the loop
                            # if (TotalTiles/GSU > 4*CUs):
                            #     continue
                            # print(" testing 5")

                            # To remove MI with waves<4 for larger MT / MN
                            if (TilesPerCU >= 2.0 and (mfma[-1] * mfma[-2]) < 4):
                                continue

                            # remove MI with low number
                            if (mfma[7] * mfma[8] * LSU < 4 and (mfma[5] > 1 or mfma[6] > 1)):
                                continue

                            min_TilesPerCU[count_size] = min(min_TilesPerCU[count_size], TilesPerCU)
                            max_TilesPerCU[count_size] = max(max_TilesPerCU[count_size], TilesPerCU)
                            min_TotalTile_PerSize[count_size] = min(min_TotalTile_PerSize[count_size], TotalTiles)
                            max_TotalGranularity[count_size] = max(max_TotalGranularity[count_size], totalGranularity)

                            size_mfmas_dict[tuple(size)].append((totalGranularity, TilesPerCU, tuple(mfma), NumTile0, NumTile1, Tile0Granularity,
                                                                 Tile1Granularity, TotalTiles, CUGranularity, waveGranularity, GSU, LSU, MT0, MT1, TT0, TT1, WG0, WG1, MIBlockM))

                            # TODO: to remove unnecessary large GSUs - if with a smaller GSU, we can reach totalGranularity=1, checking larger GSUs, just increases TilesPerCU, even though we may get totalGranularity=1 with larger GSU again. So skip.
                            if totalGranularity == 1:
                                break

            print(" # Total valid MFMA after level one-round1 refining: ", len(size_mfmas_dict[tuple(size)]))

        # TODO: we still need to revise this.
        for idx, size in enumerate(size_mfmas_dict.keys()):
            min_TotalTile = min_TotalTile_PerSize[idx]
            min_rounds = math.ceil(min_TotalTile/self.config["CUs"])
            max_totalGranularity = max_TotalGranularity[idx]

            mfma_indices_to_remove = []

            for j in range(len(size_mfmas_dict[size])):
                mfma = size_mfmas_dict[size][j]

                MT0, MT1 = mfma[-7], mfma[-6]
                cur_totalGranularity = mfma[0]
                num_rounds = math.ceil(mfma[1])  # math.ceil(TilesPerCU)

                if (MT0*MT1 > 128*128):
                    if cur_totalGranularity < self.config["GRANTHRESHOLD"] and self.config["GRANTHRESHOLD"] < max_totalGranularity:
                        mfma_indices_to_remove.append(j)  # comp-bound
                elif (MT0*MT1 >= 64*32):
                    if cur_totalGranularity < 0.7 * max_totalGranularity:
                        #   if cur_totalGranularity < 0.3 * max_totalGranularity:
                        mfma_indices_to_remove.append(j)  # comp-bound
                else:
                    #   if cur_totalGranularity < 0.2 * max_totalGranularity:
                    if cur_totalGranularity < 0.5 * max_totalGranularity:
                        mfma_indices_to_remove.append(j)  # mem-bound

                if (min_TotalTile >= self.config["CUs"]*0.15 and num_rounds > 5 + min_rounds):  # comp-bound (1 round only)
                    mfma_indices_to_remove.append(j)
                elif (min_TotalTile < self.config["CUs"]*0.09 and num_rounds > 5 + min_rounds):  # mem-bound (top 3 rounds)
                    mfma_indices_to_remove.append(j)
                elif (min_TotalTile < self.config["CUs"]*0.15 and num_rounds > 3 + min_rounds):  # mem-bound (top 3 rounds)
                    mfma_indices_to_remove.append(j)

            mfmas_filtered = []
            mfma_indices_to_remove = set(mfma_indices_to_remove)

            for j in range(len(size_mfmas_dict[size])):
                if j in mfma_indices_to_remove:
                    continue
                mfmas_filtered.append(size_mfmas_dict[size][j])

            size_mfmas_dict[size] = mfmas_filtered
            print(" # Total valid MFMA after level one-round2 refining: ", len(size_mfmas_dict[tuple(size)]))

        # sort by granularity (largest to smallest)
        # count_size =-1
        for size in size_mfmas_dict.keys():
            """
            Prefer MFMAs with lower rounds.
            If rounds same, order by decreasing order of totalGranularity 
            if total granularity same, order by increasing order of tilesPerCU
            """
            size_mfmas_dict[size].sort(key=lambda tup: (math.ceil(tup[1]), 1-tup[1], 1-tup[0]))
        return size_mfmas_dict, max_TilesPerCU

    def filter_MIs(self, size_mfmas_dict, max_TilesPerCU):
        count_size = -1
        Final_MFMA = {}
        MIsPerSize = {}
        sizeOutput = "\n###################\n"
        for size in self.config['Sizes']:

            print("working on size <<<<  second round of refining: ", size)
            count_size += 1
            size = tuple(size)

            sizeOutput += f'>>>>> Size: {size}\n'

            if size not in size_mfmas_dict:  # TODO: bbk this can be deleted
                sizeOutput += f'  -> No good MFMA found for size: {size} in the first round of refining\n'
            else:
                sizeOutput += f' --- Total {len(size_mfmas_dict[size])} MFMA configs found\n'

                selected_MI_for_this_size = 0
                for (totalGranularity, TilesPerCU, mfma, NumTile0, NumTile1, Tile0Granularity, Tile1Granularity, TotalTiles, CUGranularity, waveGranularity, GSU, LSU, MT0, MT1, TT0, TT1, WG0, WG1, MIBlockM) in size_mfmas_dict[size]:

                    if (max_TilesPerCU[count_size] > 1.0 and TilesPerCU < self.config['TILETHRESHOLD']):
                        continue

                    selected_MI_for_this_size += 1
                    #   if 'MAX_NUM_MI_PER_SIZE' in self.config and self.config['MAX_NUM_MI_PER_SIZE'] < selected_MI_for_this_size:
                    #   selected_MI_for_this_size -= 1
                    #   break

                    # comment = "size [{}] MT {:7} - TT {:6} - WG {:6} - MIBlockM: {:2} - GSU: {:3} - LSU: {:2} -totalGranularity: {:8.5f} TilesPerCU: {:8.5f}, TotalTiles: {:8}".format("{}, {}, {}, {}".format(size[0],size[1],size[2],size[3]),  "{}x{}".format(MT0, MT1), "{}x{}".format(TT0, TT1), "{}x{}".format(WG0, WG1), MIBlockM, GSU, LSU, totalGranularity, TilesPerCU, TotalTiles)
                    comment = "MT {:7} - TT {:6} - WG {:6} - MIBlockM: {:2} - GSU: {:3} - LSU: {:2} -totalGranularity: {:8.5f} TilesPerCU: {:8.5f}, TotalTiles: {:8}".format(
                        "{}x{}".format(MT0, MT1), "{}x{}".format(TT0, TT1), "{}x{}".format(WG0, WG1), MIBlockM, GSU, LSU, totalGranularity, TilesPerCU, TotalTiles)
                    # totalGranularity: {:8.5f} TilesPerCU: {:8.5f} GSU:{:4} LSU: {:1} -- NumTile0: {:5}, NumTile1: {:5}, Tile0Granularity: {:4.2f}, Tile1Granularity: {:4.2f}, TotalTiles: {:8}, CUGranularity: {:4.2f}, waveGranularity: {:4.2f}\n".format(mfma, comment, totalGranularity, TilesPerCU, GSU, LSU, NumTile0, NumTile1, Tile0Granularity, Tile1Granularity, TotalTiles, CUGranularity, waveGranularity)
                    sizeOutput += "# - MatrixInstruction: {} # {}\n".format(list(mfma), comment)

                    if LSU > 1:
                        sizeOutput += f"#   WorkGroup: [{WG0},{WG1},{LSU}]\n"
                    if GSU > 1:
                        sizeOutput += f"#   GlobalSplitU: {GSU}\n"

                        #   if ( self.config['StreamK']==False and not (GSU == 64 or GSU == 128 or GSU == 256)): continue # for DP, we only keep these GSUs
                    if self.config['StreamK']:
                        GSU = 1
                    key = (mfma[0], mfma[1], mfma[2], mfma[3], mfma[4], mfma[5], mfma[6], mfma[7], mfma[8], LSU, GSU)

                    if key not in Final_MFMA.keys():
                        Final_MFMA[key] = [size]
                    elif size not in Final_MFMA[key]:
                        Final_MFMA[key].append(size)

                sizeOutput += f' Final number of valid MFMA after second refining: {selected_MI_for_this_size}\n\n'
                MIsPerSize[size] = selected_MI_for_this_size
                print(
                    f' Final number of valid MFMA after second refining: {selected_MI_for_this_size} + Length so far {len(Final_MFMA)}')
            # print(" # MI refine level one: ", len(size_mfmas_dict[tuple(size)]))

        print("length of final mfma list: ", len(Final_MFMA))

        # TODO: drop the output in the output folder
        out = open(os.path.join(self.outputfile+".log"), 'w')
        out.write(sizeOutput)

        self.Final_MFMA = Final_MFMA
        self.MIsPerSize = MIsPerSize

    def dump_MFMA_data_to_YAML(self):
        MI_Groups = []
        comments = []
        for mfma, sizesForMFMA in self.Final_MFMA.items():

            MT0, MT1, TT0, TT1, WG0, WG1, MIBlockM = self.calculate_mfma_parameters(
                [mfma[0], mfma[1], mfma[2], mfma[3], mfma[4], mfma[5], mfma[6], mfma[7], mfma[8]])
            # GSU, LSU, totalGranularity, TilesPerCU, TotalTiles
            # sizes [{}]".format("{}x{}".format(MT0, MT1), "{}x{}".format(TT0, TT1), "{}x{}".format(WG0, WG1), MIBlockM, sizesForMFMA)
            # print(sizesForMFMA, sizesForMFMA[0])
            LSU = mfma[9]
            GSU = mfma[10]
            NumTile0, NumTile1, Tile0Granularity, Tile1Granularity, TotalTiles, TilesPerCU, CUGranularity, waveGranularity, totalGranularity = self.calculate_granularities(
                MT0, MT1, sizesForMFMA[0][0], sizesForMFMA[0][1], sizesForMFMA[0][2], self.config['CUs'], LSU,  GSU, [mfma[7], mfma[8]])

            comment = "MT {:7} - TT {:6} - WG {:6} - MIBlockM {:2} - GSU {:3} - LSU {:2} - totalGranularity {:8.5f} - TilesPerCU: {:8.5f} - TotalTiles: {:8} -- sizes [{}]".format(
                "{}x{}".format(MT0, MT1), "{}x{}".format(TT0, TT1), "{}x{}".format(WG0, WG1), MIBlockM, GSU, LSU, totalGranularity, TilesPerCU, TotalTiles, sizesForMFMA)
            mfma_dict = {"MatrixInstruction": [mfma[0], mfma[1], mfma[2],
                                               mfma[3], mfma[4], mfma[5], mfma[6], mfma[7], mfma[8]]}
            if mfma[9] > 1:  # LSU
                mfma_dict["WorkGroup"] = [WG0, WG1, mfma[9]]
            if mfma[10] > 1:  # GSU
                mfma_dict["GlobalSplitU"] = mfma[10]
            comments.append(comment)
            MI_Groups.append(mfma_dict)

        self.MI_Groups = MI_Groups
        self.comments = comments

        with open(os.path.join(self.outputfile+"_MFMA.yaml"), 'w') as f:
            for idx, mfma_dict in enumerate(MI_Groups):
                for k, v in mfma_dict.items():
                    v_string = f"{v}"
                    if k == "MatrixInstruction":
                        v_string += f" #{comments[idx]}"
                    # default_style=None, default_flow_style=False, sort_keys=False, width=5000)
                    yaml.dump({k: v_string}, f, default_style=None, default_flow_style=False, width=5000)

        return

    def __init__(self, outputfile, config):
        self.config = config
        self.outputfile = outputfile

        valid_mfmas, smallest_M_in_MFMA, smallest_N_in_MFMA = self.generate_all_mfmas()
        size_mfmas_dict, max_TilesPerCU = self.find_MI_for_sizes(valid_mfmas, smallest_M_in_MFMA, smallest_N_in_MFMA)
        self.filter_MIs(size_mfmas_dict, max_TilesPerCU)

        self.dump_MFMA_data_to_YAML()


def main():
    args = parseArgs()

    with open(args.config) as stream:
        try:
            config = yaml.full_load(stream)
        except yaml.YAMLError as exc:
            raise (exc)

    MIDesign(args.outputfile, config)


if __name__ == "__main__":
    main()
