from Helper import get_num_kernels
import copy

# This section has functions to get all parameters from clustered sizes.
# This is independent of the clustering algorithm


def reorder_forkParams(forkParams):
    # This method can be used to reorder the fork parameter dict.
    """
    NOTE - Use this method to do all re-ordering. For example, if we want to have sections in
    fork parameters based on what part of the kernel is affected then that information should
    be part of the parameter class. Use the param class obj as the key to sort. 
    """
    forkParams = {k: v for k, v in sorted(forkParams.items(), key=lambda item: (item[1]._isCommented, item[0]))}
    forkParams["Groups"] = forkParams.pop('Groups')  # push the groups section to end.
    return forkParams


def mergeSizes(cluster_sizes, param_list, size_list, MIsPerSize_list, MAX_NUM_KERNELS_PER_CONFIG):
    """
    This funtion incrementally tries to merge params corresponding to the sizes in a particular
    cluster. Clustering pauses moment the number of kernels is going to exceed MAX_NUM. 
    """
    # init list of sub-clusters, can be 1 if cluster doesn't exceed max kernels
    s_lists = []
    p_lists = []
    n_lists = []
    m_list = []

    # initialize a subcluster
    cur_param_obj = param_list[cluster_sizes[0]]
    cur_MIsPerSize = MIsPerSize_list[cluster_sizes[0]]
    cur_sizes = [size_list[cluster_sizes[0]]]
    cur_numKernel = get_num_kernels(cur_param_obj)
    for i in range(1, len(cluster_sizes)):
        # cache previous state in case new size leads to excess kernels.
        cur_param_obj_temp = copy.deepcopy(cur_param_obj)

        # Try adding current point to the current  subcluster
        for k, _ in param_list[cluster_sizes[i]].items():
            if k not in cur_param_obj.keys():
                cur_param_obj[k] = param_list[cluster_sizes[i]][k]
            else:
                cur_param_obj[k].args += param_list[cluster_sizes[i]][k].args
                # cur_param_obj[k].args.append(param_list[cluster_sizes[i]][k].args[0])
            cur_param_obj[k]._value = None

        new_cur_numKernel = get_num_kernels(cur_param_obj)
        if new_cur_numKernel <= MAX_NUM_KERNELS_PER_CONFIG:
            # New point didn't lead the max kernel threshold.
            cur_numKernel = new_cur_numKernel
            cur_sizes.append(size_list[cluster_sizes[i]])
            cur_MIsPerSize.update(MIsPerSize_list[cluster_sizes[i]])
        else:
            # Current size leads to number of kernels to exceed
            # Save current sub-cluster
            print("cluster needs to be split here")
            s_lists.append(cur_sizes)
            p_lists.append(reorder_forkParams(cur_param_obj_temp))
            n_lists.append(cur_numKernel)
            m_list.append(cur_MIsPerSize)

            # init
            cur_param_obj = param_list[cluster_sizes[i]]
            cur_MIsPerSize = MIsPerSize_list[cluster_sizes[i]]
            cur_sizes = [size_list[cluster_sizes[i]]]
            cur_numKernel = get_num_kernels(cur_param_obj)

    # Save current (last) sub-cluster
    s_lists.append(cur_sizes)
    p_lists.append(reorder_forkParams(cur_param_obj))
    n_lists.append(cur_numKernel)
    m_list.append(cur_MIsPerSize)

    return s_lists, p_lists, n_lists, m_list


def mergeSizeAll(clusters, param_list, size_list, nkernels_list, MIsPerSize_list, MAX_NUM_KERNELS_PER_CONFIG):
    """
    Apply clustering info on the parameter lists.
    size_list[x] = list of sizes in cluster x
    param_list[x] = all params corresponding to all sizes in cluster x  
    """
    size_list_c = []
    param_list_c = []
    nkernels_list_c = []
    MIsPerSize_list_c = []
    for _, cluster_sizes in clusters.items():
        size_lists, param_lists, nkernerl_count, MIsPerSizes = mergeSizes(
            cluster_sizes, param_list, size_list, MIsPerSize_list, MAX_NUM_KERNELS_PER_CONFIG)
        for i in range(len(size_lists)):
            size_list_c.append(size_lists[i])
            param_list_c.append(param_lists[i])
            nkernels_list_c.append(nkernerl_count[i])
            MIsPerSize_list_c.append(MIsPerSizes[i])

    return param_list_c, size_list_c, nkernels_list_c, MIsPerSize_list_c
