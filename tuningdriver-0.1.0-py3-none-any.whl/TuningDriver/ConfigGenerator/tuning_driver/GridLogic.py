from Constants import *
import bisect
import sys
from functools import lru_cache


def factorize(X):
    # Function generates all (a,b) ordered pairs for X
    # skips 1xX case
    pairs = []
    min_f = 2
    for a in range(min_f, X+1):
        if X % a:
            continue
        if int(X/a) < min_f:
            continue
        pairs.append((a, X/a))
    return pairs


def generate_boundary(num_CUs, round_x, round_y, MT0, MT1):
    # Function to generate boundary curve
    MN_factor = factorize(num_CUs)
    boundary_points = []

    m_min, m_max = sys.maxsize, 0
    n_min, n_max = sys.maxsize, 0

    for (m_factor, n_factor) in MN_factor:
        m = m_factor * MT0 * round_x
        n = n_factor * MT1 * round_y
        boundary_points.append((m, n))
        m_min = min(m_min, m)
        m_max = max(m_max, m)
        n_min = min(n_min, n)
        n_max = max(n_max, n)

    boundary_points.append((m_max, n_min))
    boundary_points.append((m_min, n_max))
    boundary_points = sorted(boundary_points, key=lambda x: (x[1], x[0]))
    return boundary_points


def generate_points(boundary, density=1):
    # Generates a simple square grid of points
    # boundary is sorted in increasing order of n and then m
    m_max = boundary[0][0]
    n_max = boundary[-1][1]
    m_max = n_max = int(max(m_max, n_max))  # ideally both should be same

    # m_dim = [1] + list(range(16,256+1,16*density)) + list(range(256,512+1,32*density))  + list(range(512, 1024+1, 64*density)) \
    # + list(range(1024, 2048+1, 256*density)) + list(range(2048, 4096+1, 512*density)) + list(range(4096, m_max+1, 1024*density))

    # m_dim = list(range(16,256,min(48,16*density))) + list(range(256,512,32*density))  + list(range(512, 1024, 64*density)) \
    m_dim = [16, 32, 64, 96] + list(range(128, 256, 16*density)) + list(range(256, 512, 32*density)) + list(range(512, 1024, 64*density)) \
        + list(range(1024, 2048, 256*density)) + list(range(2048, 4096, 512*density)) + \
        list(range(4096, 16384, 1024*density)) + list(range(16384, m_max+1, 2048*density))

    n_dim = m_dim = set(m_dim)

    points = []
    for m in m_dim:
        for n in n_dim:
            points.append((m, n))

    return points


@lru_cache(maxsize=None)
def find_first_point_above(m, M):
    index = bisect.bisect_right(M, m)
    if index < len(M):
        return index
    else:
        return -1


def is_left(m, n, boundary):
    """
    this function determines if a point is to the left of the boundary.
    boundary points are ordered in decreasing 
    """
    idx = find_first_point_above(n, tuple([b[1] for b in boundary]))
    if idx == -1:
        return False
    m_top = boundary[idx][0]
    m_bottom = boundary[idx-1][0]
    n_top = boundary[idx][1]
    n_bottom = boundary[idx-1][1]
    if m_top != m_bottom:
        M = (n_top-n_bottom)/(m_top-m_bottom)
        C = n_top - M*m_top
        return (m*M+C >= n)
    else:
        return m < m_top


def remove_points_outside_boundary(points, boundary):
    valid_points = []
    for idx in range(len(points)):
        m, n = points[idx]
        if not is_left(m, n, boundary):
            continue
        valid_points.append((m, n))
    return valid_points


def generate_sizes_from_points(points, K_dim_list):
    totalgird = 0
    sizes = []
    for k in K_dim_list:
        size_k = []
        for point in points:
            if k > 4096 and point[0] > 1024 and point[1] > 1024:
                continue
            size_k.append([point[0], point[1], 1, k])
            totalgird += 1
        sizes.append(size_k)
    return totalgird, sizes


def generate_grid_sizes(config):
    """
    This method filters out points in a square grid 
    based on a boundary determined by sizes corresponding 
    to MT=256x256, rounds=2x2 for various axb=CU combinations
    """
    CUs = config["CUs"]
    MT0, MT1 = config["GRID_BOUNDARY_MT"]
    round_x, round_y = 2, 2
    density = config["GRID_DENSITY"]
    assert density >= 1 and density <= 5, "Grid density range 1-5"

    boundary = generate_boundary(CUs, round_x, round_y, MT0, MT1)
    points = generate_points(boundary, density)
    points = remove_points_outside_boundary(points, boundary)
    points = sorted(points)
    print(f" Total number of sizes in the grid: {len(points)}")
    totalgrid, sizes = generate_sizes_from_points(points, config["GRID_BOUNDARY_K_LEVELS"])
    print(f" Total number of sizes in the grid: {totalgrid}")

    return [sizes]
