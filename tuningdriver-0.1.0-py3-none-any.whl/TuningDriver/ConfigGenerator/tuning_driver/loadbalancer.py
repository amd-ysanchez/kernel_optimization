
# Usage:
# copy the output of TD in hipblaslt/tensilelite.
# hipBLASLt/tensilelite$ python3 loadbalancer.py <hipblaslt/tensilelite/path to TD output file> -tensilePath| tee LoadBalancer.log
# hipBLASLt/tensilelite$ python3 loadbalancer.py OOB_F8BS_TN | tee LoadBalancer.log

import subprocess
import time
from threading import Thread, Lock
from queue import Queue
import argparse
import os
import yaml
import re


def parseArgs():
    argParser = argparse.ArgumentParser()
    argHelp = {
        "dir": "Path to config file, output of TD (Driver.py)",
        "outdir": "Output path, default: ./",
        "devices": "Comma-separated list of device IDs to use. Ex: 0,3,4,5",
    }

    argParser.add_argument("dir", action="store", type=str, default='./', help=argHelp["dir"])
    argParser.add_argument("--outputPath", "-o", action="store", type=str, default='./', help=argHelp["outdir"])
    argParser.add_argument("--devices", "-d", action="store", type=str,
                           default="0,1,2,3,4,5,6,7", help=argHelp["devices"])

    return argParser.parse_args()

# Define a custom sorting key function, to order configs.
# The configs run consecutively then.


def sort_key(filename):
    config_name, _ = os.path.splitext(filename)
    parts = config_name.split('_')
    return (int(parts[-1]),)


def read_configs(directory):

    configs = []

    for filename in os.listdir(directory):
        if filename.endswith('.sh'):
            config_name, _ = os.path.splitext(filename)
            if config_name.split('_')[-1] == "all":
                continue
            build_dir = os.path.join(directory, f'build_{config_name}', '3_LibraryLogic')
            if os.path.isdir(build_dir) and len(os.listdir(build_dir)) > 0:
                print(f'Skipping already optimized config ==> {config_name}')
                continue
            file_path = os.path.join(directory, filename)
            configs.append(file_path)

    configs = sorted(configs, key=sort_key)

    print("Total number of configs: ", len(configs))

    return configs


def run_executable(executable):
    command = f"{executable};"
    print(" here is the command: ", command)
    subprocess.run(command, shell=True)


def worker(queue, deviceID):

    # create a separate working dir for this device
    report_file = open(f"report_{deviceID}.log", 'w')
    while True:
        with Lock():  # Lock access to the queue
            if len(queue) == 0:
                break
            executable = queue.pop(0)

        # shell script and configs should have the same name
        conf_fl = executable.replace('sh', 'yaml')

        print(f' Thread {deviceID} is working on config: {conf_fl}')

        open_yaml = open(conf_fl, 'r')
        s = open_yaml.read()
        open_yaml.close()

        before = r"Device: .?"
        after = f"Device: {deviceID}"

        s_modified = re.sub(before, after, s)

        report_file.write(f"Thread {deviceID} starting: {executable}\n")

        open_yaml = open(conf_fl, 'w')
        open_yaml.write(s_modified)
        open_yaml.close()

        # update the working directory in the bash
        with open(executable) as f:
            s = f.read()

        with open(executable, 'w') as f:
            report_file.write('Replacing wdevice to "{deviceID}" in {executable}\n'.format(**locals()))
            s = re.sub("WDirDevice_(id|[0-9])", f"WDirDevice_{deviceID}", s)
            f.write(s)

        report_file.write("Running...\n")
        report_file.flush()

        run_executable(executable)

        build_dir = os.path.join(os.path.dirname(executable),
                                 f'build_{os.path.basename(executable.rstrip(".sh"))}', '3_LibraryLogic')
        if os.path.isdir(build_dir) and len(os.listdir(build_dir)) > 0:
            report_file.write("Done!\n")
        else:
            report_file.write(f"{executable} failed!\n")
        report_file.flush()

    report_file.close()


def print_configs(configs):
    for config in configs:
        print("config: ", config)


def loadBalancer(args):
    print("<<< Load balancer >>>")

    configs = read_configs(args.dir)

    # Parse device IDs from comma-separated string
    device_ids = [int(x.strip()) for x in args.devices.split(',')]
    if len(configs) < len(device_ids):
        device_ids = device_ids[:len(configs)]

    # TODO: Instead of using the fixed number (e.g., 8) to validate the device number available, we need to find another way (e.g., using Tensile API ? ). The number of devices for DPX is 16.

    print(f"Using devices: {device_ids}")

    # initiate a thread for each device
    threads = []

    for device_id in device_ids:
        print(" device id in the thread: ", device_id)
        thread = Thread(target=worker, args=(configs, device_id,))
        thread.start()
        threads.append(thread)

    # Wait for all threads to finish
    for thread in threads:
        thread.join()

    print("<<< done >>>.")


if __name__ == "__main__":
    args = parseArgs()
    loadBalancer(args)
