from GridLogic import generate_grid_sizes
from ClusterSizes import cluster_sizes
import argparse
import yaml
import numpy as np


class CustomLoader(yaml.SafeLoader):
    def construct_python_tuple(self, node):
        return tuple(self.construct_sequence(node))


CustomLoader.add_constructor(
    'tag:yaml.org,2002:python/tuple',
    CustomLoader.construct_python_tuple
)


def read_yaml(file_path):
    with open(file_path, 'r') as file:
        config = yaml.load(file, Loader=CustomLoader)
    return config


def main():
    parser = argparse.ArgumentParser(description='Read a YAML file and store its data in a variable.')
    parser.add_argument('yaml_file', type=str, help='Path to the YAML file')
    args = parser.parse_args()

    config = read_yaml(args.yaml_file)
    AllSizes = generate_grid_sizes(config)

    CUs = 304
    size_list = []
    for Sizes in AllSizes[0]:
        for Size in Sizes:
            size_list.append([Size])
    dataType = 'H'

    clusters = cluster_sizes(size_list, CUs, dataType, 0.7)
    # for cluster, sizes in clusters.items():
    #   print(f"==============\n{cluster}\n==============\n")
    #   for size_idx in sizes:
    #     print(size_list[size_idx])
    print(
        f"Num_sizes - {len(size_list)}, num_groups_before_clusering - {len(AllSizes[0])}, num_groups_after_clusering - {len(clusters)}")

    # for x in np.arange(0.1,0.9,0.025):
    #   clusters = cluster_sizes(size_list, CUs, dataType, x)
    #   print(f"DataType - {dataType}: {x}, {len(size_list)}, {len(AllSizes[0])}, {len(clusters)}")


if __name__ == '__main__':
    main()
