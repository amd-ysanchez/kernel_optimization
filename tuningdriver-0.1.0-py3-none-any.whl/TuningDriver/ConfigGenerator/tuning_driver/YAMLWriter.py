import yaml
import os
from pathlib import Path

UNIQUE_PATTERN = "%$*"


def convert_fork_param_toString(params):
    # params - list of dict, each dict maps key to param obj
    # return - list of dict, each dict maps key to val in string to dump to yaml
    param_toString = []
    for param_name, param in params.items():
        if param._isCommented:
            param_name = f"{param_name}{UNIQUE_PATTERN}"
        param_toString.append({param_name: param.to_string()})

    return param_toString


# TODO: replace outputPath with tuningConfigFile
def dumpYaml(hipblaslt_path, header, cur_wd, outputPath, GEMM_type, GEMM_typeCat, content, nKernels, MIsPerSize, isGA=False, progress=None, client_path=None):

    hipblaslt_path = os.path.abspath(hipblaslt_path)
    name = GEMM_typeCat+".yaml"
    configPath = os.path.join(cur_wd, name)
    print(f"output path: {configPath}, configYaml: {configPath}")

    with open(configPath, "w") as f:
        f.write(header)
        yaml.dump_all(content, f, default_style=None, default_flow_style=False, sort_keys=False, width=5000)
        f.write(f"# End of {name} \n")

    # TODO: bbk I cannot force yaml dump not to put '' for some strings. I use replace.
    with open(configPath, 'r') as f:
        content = f.read()

    with open(configPath, 'w') as f:
        content = content.replace("'", "")
        f.write(content)

    with open(configPath, 'r') as f:
        content = f.readlines()
        for idx, line in enumerate(content):
            if UNIQUE_PATTERN not in line:
                continue
            line = line.replace(UNIQUE_PATTERN, "")
            line = f"# {line}"
            content[idx] = line

    with open(configPath, 'w') as f:
        f.writelines(content)

    client_path_str = ''
    if client_path:
        client_path_str = f'--prebuilt-client {os.path.abspath(client_path)}'
    # create run bash file for each config
    runCommad = "#!/bin/bash\n\n"
    # runCommad += 'NOW=$(date +"D%m_%d_%Y_H%H_%M_%S")\n'
    runCommad += f'NAME="{GEMM_typeCat}"\n'
    runCommad += 'YAML="$NAME.yaml"\n'
    runCommad += 'OUT="$NAME-tensilelite.log"\n\n'
    runCommad += 'WORK_DIR="WDirDevice_id"\n\n'  # keep the space
    runCommad += 'echo "running $NAME ..."\n'
    if isGA:
        root = os.path.dirname(__file__).split('TuningDriver')[0]
        runCommad += f'PYTHONPATH={hipblaslt_path}/tensilelite/ {root}/TuningDriver/Ductile/bin/Ductile $YAML $WORK_DIR {client_path_str} 2>&1 | tee $OUT\n'
    else:
        runCommad += f'{hipblaslt_path}/tensilelite/Tensile/bin/Tensile $YAML $WORK_DIR {client_path_str} 2>&1 | tee $OUT\n'
    runCommad += f'mkdir {os.path.basename(outputPath)}\n'
    runCommad += f'cp  $YAML {os.path.basename(outputPath)}\n'
    runCommad += f'mv $WORK_DIR/2\_BenchmarkData $WORK_DIR/3\_LibraryLogic $OUT {os.path.basename(outputPath)}\n'
    runCommad += 'rm -rf $WORK_DIR/1\_BenchmarkProblems \n'
    runCommad += 'echo " ---- $NAME Done!"\n'

    runConfigFile = GEMM_typeCat+".sh"
    runconfigPath = os.path.join(cur_wd, runConfigFile)

    with open(runconfigPath, "w") as f:
        f.write(runCommad)
    os.chmod(runconfigPath, 0o755)

    # create run bash file for each device_id
    runDeviceConfigs = f'run_{GEMM_type}_all.sh'
    configPath = os.path.join(cur_wd, runDeviceConfigs)

    if (runconfigPath[0] != '/' or runconfigPath[0] != '\\'):
        runconfigPath = os.path.join(".", runconfigPath)

    with open(configPath, "a") as f:
        f.write(os.path.join('.', GEMM_typeCat+'.sh\n'))
        f.write(f'echo "PROGRESS - {progress}"\n')

    os.chmod(configPath, 0o755)

    # log file for the entire config generator
    configLogPath = os.path.join(os.path.dirname(cur_wd), f'Config_{GEMM_type}.log')

    # configLogPath = os.path.join(os.path.dirname(outputPath), ConfigsLog)
    with open(configLogPath, "a") as f:
        f.write(f' ==== {GEMM_typeCat}\n')
        f.write(f' #kernels {nKernels}\n')
        for size in MIsPerSize.keys():
            f.write(f' # MIs for {size}: {MIsPerSize[size]}\n')
