

def get_num_kernels(result):
    """
    This function is used to compute number of kernels in a config file. 
    It does a basic product of num of param val for each param. 
    Extra logic in case of group. 
    This function works on result dict with & without GROUPS section
    """
    num_kernels = 1
    for param_name, param_obj in result.items():
        if param_name == "Groups":
            groups = param_obj.get_val()
            for group in groups[0]:
                num_kernels *= len(group)
        else:
            param_val = param_obj.get_val()
            if isinstance(param_val, list) and not result[param_name]._isCommented:
                num_kernels *= len(param_val)

    return num_kernels
