"""
This file has the classes corresponding to various optimization parameters. 
"""

from Constants import *
import math
import copy

# Class for implementing default behaviour of a fork parameter
# All parameter classes inherit this class.


class DefaultParameter():
    _name = "DefaultParameter"
    _default_value = []
    _valid_values = []
    _isCommented = True

    def __new__(cls, *args, **kwargs):
        instance = super().__new__(cls)
        instance.__init__(*args, **kwargs)
        return instance()

    def __deepcopy__(self, memo):
        cls = self.__class__
        new_instance_kv = cls.__new__(cls)
        new_instance = next(iter(new_instance_kv.values()))
        memo[id(self)] = new_instance
        new_instance.__dict__ = copy.deepcopy(self.__dict__, memo)
        new_instance._name = copy.deepcopy(self._name, memo)
        new_instance._default_value = copy.deepcopy(self._default_value, memo)
        new_instance._valid_values = copy.deepcopy(self._valid_values, memo)
        new_instance._isCommented = copy.deepcopy(self._isCommented, memo)
        return new_instance

    def __init__(self, *args):
        self.args = [args]
        self._value = None

    def __call__(self):
        kv_pair = {}
        kv_pair[self.get_name()] = self
        return kv_pair

    """
    external function that returns name of the parameter, same 
    as that to be added in the final config YAML file
    """

    def get_name(self):
        return self._name

    """
    external function that returns the parameter value.
    """

    def get_val(self):
        if self._value is None:
            self._value = self.compute_value_int()
        return self._value

    """
    this method has logic to enable clustering.
    """

    def compute_value_int(self):
        param_val = []
        for arg_idx, args in enumerate(self.args):
            pv = self.compute_value_ext(arg_idx)
            for v in pv:
                if v in param_val:
                    continue
                param_val.append(v)

        return param_val

    """
    to_string returns the string represnetation of the parameter
    value with any comments + default values all enclosed in a string 
    ex - "[1,2,3,4] # comment [5,6]
    this method calls the get_comment method that by
    default return 
    """

    def to_string(self):
        param_val = self.get_val()
        comment = self._get_comment(self.args)
        str_rep = f"{param_val} #{comment} Default Value: {self._default_value} # Range: {self._valid_values}"
        if "[[" in str_rep:
            str_rep = str_rep.replace("[[", "[")
            str_rep = str_rep.replace("]]", "]")
        return str_rep

    """
    Overwrite this method to implement custom logic to compute
    parameter values.
    We pass the set of arguments as it was used to instantiate
    the class object.
    """

    def compute_value_ext(self, arg_idx):
        return self._default_value

    """
    Overwrite this method to add comments in addition to 
    default and range added.
    """
    @staticmethod
    def _get_comment(args):
        return ""

# Meta class to keep track of custom class implementations.


class ParameterMeta(type):
    registry = {}

    def __new__(cls, name, bases, class_dict):
        new_class = super().__new__(cls, name, bases, class_dict)
        cls.registry[name] = new_class
        return new_class


"""
Pointers to add custom logic for a parameter - 

0. Mandatory steps
1. Inherit from DefaultParameter Class to follow pattern and avoid duplication
2. Inherit from ParameterMeta to register custom class implementation

1. Parameter exists, like DepthU
A. Create class with name Param_<Param_Name> like Param_DepthU
B. Define compute_value_ext(self, arg_idx) method that computes the parameter value(s). Use arg_idx to index in the array of 
   args available in self.args

2. Parameter doesn't exist, like Group
A. Same as 1.
B. _name field must be set explicitly in the class definition.

3. Handling Parameters of the type XYZ_A & XYZ_B
A. Typically have same logic for both A&B. Create a base class XYZ that inherits from DefaultParameter
B. Define separate classes XYZ_A and XYZ_B that inherit from this class. Here have it registered via ParameterMeta

4. Miscellaneous
A. Some parameter might require custom logic to handle get_val(). Override it in child class like Param_Groups.
"""


class Param_DepthU(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        M_dim, N_dim, CU_count, DataType, useLargeDepthU = self.args[arg_idx]
        if CU_count == 256:
            # MI350 logic
            if DataType in ["H", "B"]:
                du = [32, 64, 128, 256]
            elif DataType in ["F8"]:
                du = [64, 128, 256, 512]
            else:
                du = [64, 128, 256, 512]
            if useLargeDepthU:
                du.append(2*du[-1])
                du.pop(0)
            if DataType == "S":
                du = [x//4 for x in du]
            return du
        else:
            # large DepthU for small arrays only
            idx = 0
            if (M_dim * N_dim) > 256 * 128 * CU_count:
                idx = 3
            elif (M_dim * N_dim) > 128 * 128 * CU_count:
                idx = 2
            elif (M_dim * N_dim) > 32 * 32 * CU_count:
                idx = 1
            du = depthURange[DataType][idx]
            return du


class Param_PrefetchLocalRead(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        # du  = self.args
        # du = du["DepthU"].get_val()
        plr = [1]
        # maxDU = du[-1]
        # if config["ROCBLAS"]:
        #     step = 2
        #     while step <= maxDU:
        #         plr.append(step + 1)
        #         step *= 2
        return plr


class Param_DirectToVgpr(DefaultParameter):
    def compute_value_ext(self, arg_idx):
        transA, transB, dataType, AorB, M_dim, N_dim, CUs = self.args[arg_idx]

        if CUs == 256:
            # Mi250
            return [0]

        # if not config["ROCBLAS"]:
        #   return [] #not supported in tensilelite
        size = dataSize[dataType]

        if transA == "N" and transB == "T" and size < 4:
            # NT + size < 4 case, use only DTVA or B to avoid using too many combinations
            if AorB == "B" and M_dim >= N_dim and N_dim < 512:
                # small N, not enabling DTVB
                return [0]
            elif AorB == "A" and M_dim < N_dim and M_dim < 512:
                # small M, not enabling DTVA
                return [0]
            else:
                return [0, 1]
        elif AorB == "A" and transA == "N" or AorB == "B" and transB == "T":
            # TLU
            # try 0,1
            return [0, 1]
        return [0]


class Param_DirectToVgprA(Param_DirectToVgpr, metaclass=ParameterMeta):
    pass


class Param_DirectToVgprB(Param_DirectToVgpr, metaclass=ParameterMeta):
    pass


class Param_GlobalReadVectorWidth(DefaultParameter):
    def compute_value_ext(self, arg_idx):
        isGrid, trans, dataType, AorB, M_dim, N_dim, CUs = self.args[arg_idx]

        if CUs == 256:
            # mi350 logic
            if dataSize[dataType] == 1:
                return [4, 16]
            elif dataSize[dataType] == 2:
                return [2, 8]
            elif dataSize[dataType] == 4:
                return [1, 4]
            elif dataSize[dataType] == 8:
                return [1, 2]
            elif dataSize[dataType] == 16:
                return [1]
            else:
                assert False, "GRVW logic missing for given dataType"
        else:
            # dtv = []
            # if config["ROCBLAS"]: dtv = result[f"DirectToVgpr{AorB}"].get_val()

            min_dim = LIST_OF_MIN_DIM[dataType]
            minGLVW = 1
            size = dataSize[dataType]
            maxGLVW = 16//size
            TLU = AorB == "A" and trans == "N" or AorB == "B" and trans == "T"
            MN_dim = M_dim if AorB == "A" else N_dim

            if TLU:
                # TLU
                if MN_dim <= min_dim:
                    # min_dim case, use minGLVW
                    if not isGrid:
                        # singleSize case, use nearest and smaller power of 2
                        while True:
                            if MN_dim > minGLVW:
                                minGLVW //= 2
                                break
                            elif MN_dim == minGLVW:
                                break
                            minGLVW *= 2
                    return [minGLVW]
                else:  # GRID tuning
                    # if config["ROCBLAS"] and size < 4 and len(dtv) > 1:
                    #   # Tensile + TLU + size < 4 + DTV case, try maxGLVW//4,maxGLVW//2 for DTV (because Tensile does not support maxGLVW for DTV+TLU+size<4)
                    #   return [maxGLVW//4, maxGLVW//2, maxGLVW]
                    return [maxGLVW]
            # TLU False
            if size <= 4:
                # use 32bit and 128bit load
                return [4//size, 16//size]
            elif size <= 8:
                # use 64bit and 128bit load
                return [1, 2]
            return [1]


class Param_GlobalReadVectorWidthA(Param_GlobalReadVectorWidth, metaclass=ParameterMeta):
    pass


class Param_GlobalReadVectorWidthB(Param_GlobalReadVectorWidth, metaclass=ParameterMeta):
    pass


class Param_WaveSeparateGlobalRead(DefaultParameter):
    def compute_value_ext(self, arg_idx):
        dataType, trans, AorB, MorN_dim, K_dim, CUs = self.args[arg_idx]

        if CUs == 256:
            if K_dim > 100000:
                return [0, 2]
            return [0]  # for mi350 only

        size = dataSize[dataType]
        th = 65536//size  # TODO: Remove the hardcoded numbers

        # if config["ROCBLAS"]:
        #   if AorB == "A" and trans == "N" or AorB == "B" and trans == "T":
        #     # TLU
        #       # try WSGR=0,1
        #       #return [0,1]
        #       return [0]
        # else:
        if AorB == "A" and trans == "N" or AorB == "B" and trans == "T":
            # TLU
            if MorN_dim >= th:
                # try WSGR=2
                return [0, 2]
        else:
            # non TLU
            if K_dim >= th:
                # try WSGR=2
                return [0, 2]

        return [0]


class Param_WaveSeparateGlobalReadA(Param_WaveSeparateGlobalRead, metaclass=ParameterMeta):
    pass


class Param_WaveSeparateGlobalReadB(Param_WaveSeparateGlobalRead, metaclass=ParameterMeta):
    pass


class Param_NumElementsPerBatchStore(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        dataType = self.args[arg_idx][0]
        size = dataSize[dataType]
        if size <= 2:
            return [16]
        else:
            return [32//size]


class Param_NonTemporal(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        M_dim, N_dim, K_dim, CUs = self.args[arg_idx]

        if CUs == 256:
            # mi350 logic
            larger_dim = max(M_dim, N_dim)
            smaller_dim = min(M_dim, N_dim)
            if larger_dim > 1024 and smaller_dim < 32 and K_dim > 4096:
                return [4]
            return [0]
        else:
            small = min(N_dim, M_dim)
            large = max(N_dim, M_dim)
            if small <= 256 and large >= 4000:
                return [0, 4]
            else:
                return [0]


class Param_NonTemporalA(Param_NonTemporal, metaclass=ParameterMeta):
    pass


class Param_NonTemporalB(Param_NonTemporal, metaclass=ParameterMeta):
    pass


class Param_StaggerU(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        transA, transB, dataType, M_dim, N_dim = self.args[arg_idx]
        size = dataSize[dataType]
        if M_dim * N_dim < 2000 * 2000:
            # use 0 for small sizes
            return [0]
        if transA == "N" and transB == "T" and size <= 4:
            # NT case and size <=4 case, use 32
            return [32]
        elif transA == "N" and transB == "T" and size >= 8:
            # NT case and size >=4 case, use 0,32
            return [0, 32]
        elif transA == "T" and transB == "T" and size >= 8:
            # TT and size >= 8, use [0, 8]
            return [0, 8]
        # other cases, use 8
        return [8]


class Param_WorkGroupMapping(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        WGMUnit, dataType, CUs, M_dim, N_dim, useWGM1 = self.args[arg_idx]

        if CUs == 256:
            # logic for mi350
            wgm = [6, 8, 16]
            if useWGM1:
                wgm[-1] = 1
            return wgm

        size = dataSize[dataType]
        # use negative WGM for M>N
        wgmunit = WGMUnit if M_dim <= N_dim else -WGMUnit
        min_dim = min(M_dim, N_dim)
        max_dim = max(M_dim, N_dim)
        maxunit = int(math.sqrt(CUs/WGMUnit))
        MT = 256 if size <= 4 else 128
        if min_dim > 256 and max_dim >= MT * WGMUnit*2*maxunit:
            return [wgmunit*maxunit]
        elif min_dim > 256 and max_dim >= MT * WGMUnit*maxunit and maxunit > 4:
            return [wgmunit*maxunit]
        elif min_dim > 256 and max_dim >= MT * WGMUnit*4:
            return [wgmunit*2, wgmunit*4]
        elif min_dim > 256 and max_dim >= MT * WGMUnit*2:
            return [1, wgmunit*2]
        # return [1] , [1, config["WGMUnit"]] # WGM, WGMXCC. Use WGMXCC if WGM is 1 only
        return [1]  # looks like WGMXCC is not effective yet. Use 1 only for now


class Param_WorkGroupMappingXCC(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        # config = self.args[0]
        # if config["ROCBLAS"]: return [] #tensile
        return [1]  # tensileite

# use SPO + SSO for large arrays


class Param_StorePriorityOpt(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        M_dim, N_dim = self.args[arg_idx]
        if M_dim * N_dim >= 2000 * 2000:
            return [1]
        return [0]


class Param_StoreSyncOpt(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        M_dim, N_dim = self.args[arg_idx]
        if M_dim * N_dim >= 2000 * 2000:
            return [4]
        return [0]


class Param_1LDSBuffer(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        info = self.args[arg_idx]
        # if len(info) == 1: return info

        M_dim, N_dim, CUs = self.args[arg_idx]
        # if CUs == 256: return [0]
        if M_dim*N_dim < 256*128*16*16:
            return [0, 1]  # try 1LDSB=0 for small arrays
        return [1]


class Param_StreamK(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        isStreamK = self.args[arg_idx]
        if isStreamK[0]:
            return [3]
        else:
            return [0]


class Param_StreamKXCCMapping(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        isStreamK = self.args[arg_idx]
        if isStreamK[0]:
            return [0, 8]
        else:
            return [0]


class Param_UseSgprForGRO(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        isStreamK, transA, transB = self.args[arg_idx]
        if isStreamK and transA == "T" and transB == "N":
            return [0, 1]
        else:
            return [-1]

# NOTE ask bbk - Enablig in hipBLASLt


class Param_ClusterLocalRead(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        if len(self.args[0]) == 1:  # mi350 logic
            return self.args[0]

        dataType, transA, transB = self.args[arg_idx]
        # if not config["ROCBLAS"]: return [] # tensilelite
        size = dataSize[dataType]
        if size < 4 and (not (transA == "T" and transB == "N")):
            return [1]
        return [0]

# NOTE ask bbk - Enablig in hipBLASLt


class Param_LocalReadVectorWidth(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        return [-1]
        # dataType, transA, transB = self.args[arg_idx]
        # size = dataSize[config['DataType']]
        # if not config['ROCBLAS'] or size == 16:
        #   return [-1]
        # if config['TRANSA'] == "N" and config['TRANSB'] == "T":
        #   # NT case:
        #   if config['DataType'] == "D":
        #     # DGEMM NT special, use 1 and 2
        #     return [1,2]
        #   else:
        #     return [-1]

        # # Tensile + NN/TN/TT case, use -1 + widest LRVW
        # size = dataSize[config['DataType']]
        # widest = 16 // size
        # return [-1,widest]


class Param_PrefetchGlobalRead(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        """
        for mi350 - we have PGR tied to mfma groups, earlier it was always
        set to 2. 
        bbk
        """
        useGPR1, K_dim, transA, transB = self.args[arg_idx]
        pgr = [2]
        if useGPR1 or (transA == "T" and transB == "N" and K_dim in [8192, 16384]):
            pgr = [1, 2]
        return pgr


class Param_SourceSwap(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        return [1]


class Param_VectorWidth(DefaultParameter):
    def compute_VW(self, size, CUs):
        if CUs == 256:
            # mi350 logic
            if size == 1:
                return [-1, 8]
            elif size == 2:
                return [-1, 8]
            return [-1]
        else:
            vw = [1]
            if size == 8:
                vw = [1, 2]
            elif size <= 4:
                vw = [1, 2, 4]
        return vw

# NOTE ask bbk - Enablig in hipBLASLt


class Param_VectorWidthA(Param_VectorWidth, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        dataType, CUs = self.args[arg_idx]
        # if not config["ROCBLAS"]: return [] # TODO - Not supported yet in tuningDriver
        size = dataSize[dataType]  # TODO: change the size to dataSize.
        vwa = self.compute_VW(size, CUs)
        return vwa

# NOTE ask bbk - Enablig in hipBLASLt


class Param_VectorWidthB(Param_VectorWidth, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        dataType, transB, dataType, CUs = self.args[arg_idx]
        # if not config["ROCBLAS"]: return [] # TODO - Not supported yet in tuningDriver
        size = dataSize[dataType]
        vw = self.compute_VW(size, CUs)
        if CUs == 256:
            return vw  # mi 350 logic
        vwb = []
        if transB == "T":
            vwb = vw
            # config["DataType"]=="C" case, use vwb=[1]
            if dataType == "C":
                vwb = [1]
        return vwb


class Param_GlobalSplitUAlgorithm(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        return ["\"MultipleBuffer\""]


class Param_ScheduleIterAlg(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        # config = self.args[0]
        # if config["ROCBLAS"]: return [3]
        return []

# MFMA Group


class Param_MatrixInstruction(DefaultParameter, metaclass=ParameterMeta):

    def compute_value_ext(self, arg_idx):
        return self.args[arg_idx][0]

    @staticmethod
    def _get_comment(args):
        return args[0][1]

    # Overwriting this as MI are represented as list
    # clashing with generic logic for other single value type params
    def compute_value_int(self):
        return self.compute_value_ext(0)

    def to_string(self):
        param_val = self.get_val()
        comment = self._get_comment(self.args)
        return f"{param_val} #{comment}"


class Param_MIArchVgpr(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        return [self.args[arg_idx][0]]


class Param_WorkGroup(DefaultParameter, metaclass=ParameterMeta):

    def compute_value_ext(self, arg_idx):
        return self.args[arg_idx][0]

    # Overwriting this as WG are represented as list
    # clashing with generic logic for other single value type params
    def compute_value_int(self):
        return self.compute_value_ext(0)


class Param_GlobalSplitU(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        return [self.args[arg_idx][0]]


class Param_Groups(DefaultParameter, metaclass=ParameterMeta):
    _name = "Groups"
    _isCommented = False
    _default_value = []

    def compute_value_ext(self, arg_idx):
        return self.args[arg_idx]

    def to_string(self):
        """
        Groups are a list of list of dicts!
        """

        groups = self._value[0] if self._value is not None else self.args[0][0]
        groups_string = []
        for group in groups:
            group_string = []
            for entry in group:
                entry_string = {}
                for k, v in entry.items():
                    str_val = v.to_string()
                    val = v.get_val()
                    if isinstance(val, list) and len(val) == 1:
                        str_val = str_val.replace("]", "", 1)
                        str_val = str_val.replace("[", "", 1)
                    entry_string[k] = str_val
                group_string.append(entry_string)
            groups_string.append(group_string)
        return groups_string

    @staticmethod
    def convert_dict_to_token(d):
        """
        This is a helper method used for converting a dict with
        multiple k-v pairs into 1 list corresponding to all val
        d.a = 1
        d.b = 2
        d.c = 3
        convert_dict_to_token(d) = [1,2,3]
        Used while clustering to identify unique entries in the lists of dict.
        """
        token = []
        for k, v in d.items():
            v = v.get_val()
            if type(v) == list:
                token += v
            else:
                token.append(v)
        return token

    """
  get_val is different for GROUPs. Hence the custom 
  implementation to override the default behavious
  args here is a list.
  self.args[0] - group info corresponding to size_0
  self.args[0][0][0] - NTCD dict
  self.args[0][1][i] - MI+WG+GSU+MIAV dict.
  this function needs to uniquely assemble them.
  """

    def compute_value_int(self):
        # if self._value is not None:
        #   return self._value

        if len(self.args) > 1:
            # This case corresponds to clustereing.
            # Each entry in the list in self.args
            # corresponds to a size

            num_groups = max([len(args[0]) for args in self.args])
            c_group = [[] for _ in range(num_groups)]
            identifier = [[] for _ in range(num_groups)]

            for size_idx, args in enumerate(self.args):
                for group_idx, group in enumerate(args[0]):
                    for x in group:
                        token = self.convert_dict_to_token(x)
                        if token in identifier[group_idx]:
                            continue
                        identifier[group_idx].append(token)
                        c_group[group_idx].append(x)
            self.args = [(c_group,)]

        self._value = self.compute_value_ext(0)
        return self._value


class Param_NonTemporal(DefaultParameter):
    def compute_value_ext(self, arg_idx):
        return [self.args[arg_idx][0]]


class Param_NonTemporalC(Param_NonTemporal, metaclass=ParameterMeta):
    pass


class Param_NonTemporalD(Param_NonTemporal, metaclass=ParameterMeta):
    pass


class Param_LDSTrInst(DefaultParameter, metaclass=ParameterMeta):
    def compute_value_ext(self, arg_idx):
        return self.args[arg_idx]

# class Param_DirectToLDS(DefaultParameter, metaclass=ParameterMeta):
#   def compute_value_ext(self, arg_idx):
#     return [0,1]


# --------------------------------------------------------------------------------
"""
Logic for generating NTCD values. 
NOTE - NonTemporalC/D is part of groups. In groups, each parameter can be only 1 value. 
This means we can't have NonTemporalC - [0, 1].So we use the following function to get 
all the values and wrap each of them in the class defined above.
"""


def get_NTCD_values(M_dim, N_dim):
    NTCDs = [0]
    if N_dim * M_dim >= 2000 * 2000:
        NTCDs = [4]  # use NTC=NTD=4
    elif N_dim * M_dim >= 1000 * 1000 or max(N_dim, M_dim) >= 10000:
        NTCDs = [0, 3]  # try NTC=NTD=0,3
    return NTCDs


def get_CLR_LDSTrI(dataSize, transA, transB):
    if transA == 'T' and transB == 'N':
        return [[0, 0]]
    if dataSize == 2:
        return [[0, 1], [1, 0]]
    elif dataSize == 4 or dataSize == 1:
        return [[1, 0]]
    assert False, "Logic not defined for dataSize != 2 or 4/1"
    return []


# --------------------------------------------------------------------------------
"""
ROCBLAS LOGIC - Keeping this as backup here.

VectorWidth - VectorWidthA in tensilelite
LocalReadVectorWidthA/B instead of GlobalReadVectorWidthA/B

# # ROCBLAS Assertions
# class ASLT(DefaultParameter, metaclass=ParameterMeta):
#   def get_name(self):
#     return "AssertSizeLessThan"

#   def compute_value_ext(self, arg_idx):
#     config, M_dim, N_dim = self.args
#     if not config["ROCBLAS"]: return []
#     # AssertSizeLessThan for small M, N
#     if M_dim <= 256 and N_dim <= 256:
#       return [{ 0: M_dim+1, 1: N_dim+1 } ]
#     elif M_dim <= 256:
#       return [{0: M_dim+1 }]
#     elif N_dim <= 256:
#       return [{1: N_dim+1 }]
#     else:
#       return []

# class ASGT(DefaultParameter, metaclass=ParameterMeta):
#   def get_name(self):
#     return "AssertSizeGreaterThan"

#   def compute_value_ext(self, arg_idx):
#     config, B_dim = self.args
#     if not config["ROCBLAS"]: return []
#     # AssertSizeGreaterThan for B > 1
#     if B_dim > 1:
#       # set ASGT = B_dim//2 (minimum 1)
#       asgt = B_dim//2
#       # no need to exceed CUs//2
#       asgt = min(asgt, config["CUs"]//2)
#       # minimum 1
#       asgt = max(asgt, 1)
#       return [{{2: {asgt} }}]
#     else:
#       return []

# class Param_VgprForLocalReadPacking(DefaultParameter, metaclass=ParameterMeta):
#   def compute_value_ext(self, arg_idx):
#     config = self.args[0]
#     if not config["ROCBLAS"]: return [] #tensileite
#     size = dataSize[config["DataType"]]
#     if size < 4 and (not (config["TRANSA"] == "T" and config["TRANSB"] == "N")):
#       return [1]
#     return [0]

class Param_FractionalLoad(DefaultParameter, metaclass=ParameterMeta):
  def compute_value_ext(self, arg_idx):
    config, M_dim, N_dim = self.args
    if not config["ROCBLAS"]: return []
    if M_dim < 512 or N_dim< 512:
      # use FractionalLoad for small M,N
      return [2]
    return [0]

ask bbk - no logic for hipblaslt
class Param_TransposeLDS(DefaultParameter, metaclass=ParameterMeta):
  def compute_value_ext(self, arg_idx):
    config = self.args
    if config["ROCBLAS"] and not (config["TRANSA"] == "N" and config["TRANSB"] == "T"):
      return [1]
    else:
      return []
"""
