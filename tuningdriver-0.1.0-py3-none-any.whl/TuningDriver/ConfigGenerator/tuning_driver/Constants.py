VERSION = "2.01"

# EnqueuesPerSync values (use same value for NumWarmups) - [step, value]
# apply value with N_dim <=step
stepValue_EnqueuesPerSync = [[64*64*8192,200], [256*256*8192,30], [1024*1024*8192,20], [1000000000000000,10]]

dataSize = {'H': 2, 'B': 2, 'S': 4, 'D': 8, 'C': 8, 'Z': 16, 'I8': 1, 'X': 4, 'F8': 1, 'F8B8': 1, 'B8F8': 1}

LIST_OF_MIN_DIM={'H': 7, 'B': 7, 'S': 3, 'D': 1, 'C': 1, 'Z': 1, 'I8': 7, 'X': 3, 'F8': 7, 'F8B8': 7, 'B8F8': 7}

depthURange = {}  # [for small/mid MT], [for large  MT]
depthURange['H'] = [[64,128,256,512], [32,64,128,256], [32,64,128], [32,64]]
depthURange['B'] = depthURange['H']
depthURange['S'] = [[16,32,64,128,256], [8,16,32,64,128], [8,16,32,64], [8,16,32]]
depthURange['D'] = [[16,32,64,128], [8,16,32,64], [8,16,32], [8,16]]
depthURange['C'] = depthURange['S']
depthURange['Z'] = depthURange['D']
depthURange['X'] = [[32,64,128,256], [16,32,64,128], [16,32,64], [16,32]]
depthURange['I8'] = [[128,256,512,1024], [64,128,256,512], [64,128,256], [64,128]]
depthURange['F8'] = depthURange['I8']
depthURange['F8B8'] = depthURange['F8']
depthURange['B8F8'] = depthURange['F8']

computeDataTypeSize = {'H': 4, 'B': 4, 'S': 4, 'D': 8, 'C': 8, 'Z': 16, 'I8': 4, 'X': 4, 'F8': 4, 'F8B8': 4, 'B8F8': 4}


# TODO - this should be imported from tensilelite commons
validMFMA = {}
validMFMA["H"] = [[32,32,4,2], [32,32,8,1], [16,16,4,4], [16,16,16,1], [4,4,4,16], [32,32,16,1], [16,16,32,1]]
validMFMA["S"] = [[32,32,1,2], [32,32,2,1], [16,16,1,4], [16,16,4,1], [4,4,1,16]]
validMFMA["B"] = [[32,32,4,2], [32,32,8,1], [16,16,4,4], [16,16,16,1], [4,4,4,16], [32,32,16,1], [16,16,32,1]]
validMFMA["D"] = [[16,16,4,1], [4,4,4,4]]
validMFMA["B1k"] = validMFMA["H"]
validMFMA["C"] = validMFMA["S"]
validMFMA["Z"] = validMFMA["D"]
validMFMA["X"] = [[32,32,4,1], [16,16,8,1]]
validMFMA["F8"] = [[32,32,16,1], [16,16,32,1], [32,32,64,1], [16,16,128,1]]
validMFMA["B8"] = validMFMA["F8"]
validMFMA["F8B8"] = validMFMA["F8"]
validMFMA["B8F8"] = validMFMA["F8"]
validMFMA["I8_908"] = [[32,32,4,2], [32,32,8,1], [16,16,4,4], [16,16,16,1], [4,4,4,16]]
validMFMA["I8_940"] = [[32,32,4,2], [32,32,16,1], [16,16,4,4], [16,16,32,1], [4,4,4,16]]
validMFMA["I8"] = validMFMA["H"] + validMFMA["F8"]


MAX_GSU_WORKSPACE_SIZE = 128 * 1024 * 1024