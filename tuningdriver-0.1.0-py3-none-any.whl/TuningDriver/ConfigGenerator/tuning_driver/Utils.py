import os
import pathlib

import pkg_resources
import subprocess
import shutil
import sys

from datetime import date


def get_git_revision_hash(path) -> str:
    try:
        git_dir = pathlib.Path(path) / '.git'
        with (git_dir / 'HEAD').open('r') as head:
            ref = head.readline().split(' ')[-1].strip()

        with (git_dir / ref).open('r') as git_hash:
            return git_hash.readline().strip()
    except FileNotFoundError:
        print('GIT repo not found!')

    return str(date.today())


def build_tensile_client(hipblaslt_path, build_dir=None):
    tensilelite_path = os.path.join(hipblaslt_path, 'tensilelite')
    default_build_dir = os.path.join(tensilelite_path, 'build_tmp')

    current_hash = get_git_revision_hash(hipblaslt_path.replace('/projects/hipblaslt', ''))

    if build_dir is None:
        build_dir = default_build_dir

    build_dir = os.path.abspath(build_dir)
    client_path = os.path.join(build_dir, 'tensilelite/client/tensilelite-client')
    hash_file_path = os.path.join(build_dir, 'hash.txt')

    build = True
    if os.path.isfile(client_path) and os.path.isfile(hash_file_path) and open(hash_file_path).read().strip() == current_hash:
        build = False

    if build:
        shutil.rmtree(build_dir, ignore_errors=True)
        if 'invoke' not in {pkg.key for pkg in pkg_resources.working_set}:
            subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'invoke'],
                                  stdout=subprocess.DEVNULL)
        print('Building tensilelite client...')
        subprocess.call(['invoke', 'build-client', '--build-dir', build_dir],
                        cwd=tensilelite_path)
        open(os.path.join(build_dir, 'hash.txt'), 'w').write(current_hash)

    return client_path if build_dir != default_build_dir else None
