
# Usage:                                                                                                                               │
# $ python3 Driver.py config.yaml -o ./ | tee configGen.log

# to do list
# automate MI based on GPU, rather than reading from the config


import argparse
import yaml
from GridLogic import generate_grid_sizes
from ForkParamGenerator import ForkParamGenerator
from ConfigSectionsGenerator import ConfigSectionGenerator
from Constants import *
import os
from collections import defaultdict
from pathlib import Path
import sys

from YAMLWriter import dumpYaml, convert_fork_param_toString
from pathlib import Path
from ClusterSizes import doCluster  # cluster_sizes
from ConfigMerger import mergeSizeAll
from Utils import build_tensile_client


def parseArgs():
    argParser = argparse.ArgumentParser()

    argHelp = {
        "config": "path to input file. default: ./config.yaml",
        "hipblaslt_path": "path to local hipblaslt repo",
        "outdir": "output path, default: ./",
        "cluster": "specify to cluster sizes. 1 - Parth Algo, 2 - Babak Algo"
    }

    argParser.add_argument("config", action="store", type=str, default='./config.yaml', help=argHelp["config"])
    argParser.add_argument("hipblaslt_path", action="store", type=str, default='.', help=argHelp["hipblaslt_path"])
    argParser.add_argument("--cluster", "-c", action="store", type=int, default=2, help=argHelp["cluster"])
    argParser.add_argument("--outputPath", "-o", action="store", type=str, default='./', help=argHelp["outdir"])

    return argParser.parse_args()


class Driver:
    def _setup(self, outdir):
        with open(args.config) as stream:
            try:
                config = yaml.full_load(stream)
            except yaml.YAMLError as exc:
                raise (exc)

        config['WGMUnit'] = config['XCC']  # WGMUnit = number of XCC

        if 'MACROTILE_OPT' not in config:
            config['MACROTILE_OPT'] = False

        if 'GA' not in config:
            config['GA'] = True

        if config['GRID']:
            if config['MACROTILE_OPT'] and config['GA']:
                raise NotImplementedError(f'GA MacroTile Optimization is not implemented in Grid mode.')
            print(" Generating Grid-based library sizes ...")
            AllSizes = generate_grid_sizes(config)  # TODO, instead of allSizes, add this to config['Sizes']
        else:
            print(" Reading sizes ...")
            AllSizes = [[config["Sizes"]]]

        if config['GA']:
            args.cluster = 0
            config['MAX_NUM_KERNELS_PER_CONFIG'] = sys.maxsize if config['MACROTILE_OPT'] else 1

        self.config = config

        # set up MI_Finder_log path
        mi_finder_log_path = os.path.join(outdir, "MI_finder_log")
        Path(mi_finder_log_path).mkdir(parents=True, exist_ok=True)

        return AllSizes

    def __init__(self, outdir):
        AllSizes = self._setup(outdir)
        print(" Total number of size categories/configs: ", len(AllSizes[0]))
        # for i in range(len(AllSizes[0])):
        #     print(f"==========\n{i}\n==========\n")
        #     for size in AllSizes[0][i]:
        #         print(size)

        param_list = []
        size_list = []
        MIsPerSize_list = []
        nkernels_list = []
        clusters = {}
        size_idx = 0
        param_factory = ParameterFactory()  # Factory of all param classes.
        self.outputPath = args.outputPath
        for i in range(len(AllSizes[0])):
            cluster = []
            sizes = []
            for size in AllSizes[0][i]:
                M_dim, N_dim, B_dim, K_dim = size

                # skip min_dim for TLU=false
                min_dim = LIST_OF_MIN_DIM[self.config['DataType']]
                if (M_dim == min_dim and self.config['TRANSA'] == "T") or (N_dim == min_dim and self.config['TRANSB'] == "N"):
                    continue

                # skip min_dim for ZGEMM
                if (M_dim == min_dim or N_dim == min_dim) and self.config['DataType'] == 'Z':
                    continue

                self.config['Sizes'] = size
                # , MIsPerSize, nkernels
                forkParam, MIsPerSize, nkernels = ForkParamGenerator(
                    param_factory, self.config, M_dim, N_dim, B_dim, K_dim, self.outputPath)()

                if nkernels == 0:
                    raise ValueError(f'No kernels found for {size}')

                sizes.append(size)
                param_list.append(forkParam)
                nkernels_list.append(nkernels)
                MIsPerSize_list.append(MIsPerSize)
                cluster.append(size_idx)
                size_idx += 1

            size_list.append(sizes)
            clusters[i] = cluster

        size_list = [sz for size_catgory in size_list for sz in size_catgory]

        num_cluster_before = len(size_list)

        # Cluster similar sizes.
        if args.cluster:
            clusters = doCluster(param_list, size_list, self.config["CUs"], args.cluster)  # PK To add

        param_list, size_list, nkernels_list, MIsPerSize_list = mergeSizeAll(clusters,
                                                                             param_list,
                                                                             size_list,
                                                                             nkernels_list,
                                                                             MIsPerSize_list,
                                                                             self.config['MAX_NUM_KERNELS_PER_CONFIG'])

        if self.config['GA'] and not self.config.get("USE_HEURISTICS", False):
            common = (self.config['DataType'],
                      self.config["CUs"],
                      self.config["TRANSA"] == "T",
                      self.config["TRANSB"] == "T")
            param_list = [updateGAForkParameters(p, *common) for p in param_list]

        if args.cluster:
            num_cluster_after = len(size_list)
            print(f"Number of configs reduced from {num_cluster_before} to {num_cluster_after}.")

        """
        Idea here is to update param_list, size_list. W/O clustering it will be a 1 to 1 mapping, 
        where param_list[k] will correspond to 1 size i.e. size_list[k][0]

        after clustering param_list[k] will correspond to size_list[k][0 -> n]
        """

        # Convert the v in k-v pair to strings to help in yaml formating.
        param_list = [convert_fork_param_toString(params) for params in param_list]

        client_path = build_tensile_client(args.hipblaslt_path, self.config.get('BUILD_DIR', None))

        # Match the GEMM type with the lib name
        GEMM_type = self.config['DataType'] + self.config['DestDataType'] + \
            self.config['ComputeDataType'] + '_' + self.config['TRANSA'] + self.config['TRANSB']
        for idx, param in enumerate(param_list):
            sizes = size_list[idx]
            csg = ConfigSectionGenerator(self.config, sizes)

            params = {}
            params["GlobalParameters"] = csg.generate_GlobalParameters()
            params['BenchmarkProblems'] = [
                [csg.generate_BenchmarkProblems_ProblemType(), csg.generate_BenchmarkProblems_Common(param)]]
            params['LibraryLogic'] = csg.generate_LibraryLogic()
            params['#LibraryClient'] = ""

            curWorkingDir = os.path.join(self.outputPath)
            catName = f"_{idx}"

            if self.config['GA']:
                updateGASections(params, curWorkingDir, GEMM_type + catName, sizes, self.config['MACROTILE_OPT'])

            header = csg.generate_comment(nkernels_list[idx])

            # TODO: math the name with the lib name convension
            tuningConfigFile = os.path.join(curWorkingDir, 'build_' + GEMM_type + catName)
            dumpYaml(args.hipblaslt_path,
                     header,
                     curWorkingDir,
                     tuningConfigFile,
                     GEMM_type,
                     GEMM_type + catName,
                     [params],
                     nkernels_list[idx],
                     MIsPerSize_list[idx],
                     isGA=self.config['GA'],
                     progress=f"{idx}/{len(param_list)-1}",
                     client_path=client_path)


if __name__ == "__main__":
    args = parseArgs()
    # Add tensilelte path for importing.
    sys.path.append(os.path.join(args.hipblaslt_path, "tensilelite"))

    from ParameterFactory import ParameterFactory
    from GAParameters import updateGAForkParameters, updateGASections
    Driver(args.outputPath)

# NOTE - pk, remove comments for debugging clustering.
