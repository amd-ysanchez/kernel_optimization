########################################################################################################################
#
# Copyright (C) 2025 Advanced Micro Devices, Inc. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
########################################################################################################################
#
# Description
# Decoder/Encoder of GEMMs' naming convention

# Idea
# The most general naming convention for a GEMM is:
#                      <type_inputA><type_inputB>_<type_A><type_B><type_C><type_D><type_compute>.
# However, it can get reduced to <type_A/B><type_C/D><type_compute>. This often introduces a slight pain when we start
# developing scripts for various applications in which we need to know GEMMs' datatypes. It usually makes the develpers
# to introduce a lot of if-else statements. And, this exact if-else statement is often repeated in different scripts.
# Hence, by introducing a new GEMM over time, all these scripts need to be updated. Herein, the ultimate goal is to
# provide such functionality that can be used in different scripts.
# The overall rule of thumb to decode a GEMM is as follows; The last component is always <type_compute>. The one before
# that is <type_C/D>. The one before is <type_B>, and if there is another component before <type_B>, it should be
# <type_A>. Otherwise, <type_A> = <type_B>. If there is an underscore "_", it means A/B inputs should be casted before
# performing the MFMA instructions. We implement this "decoder" as explained above.



########################################################################################################################
# Usage:
# Just import this script in your codes and invoke the function(s) you like to use




########################################################################################################################
# Dictionary to map types to their names
type2name = {
    'f64_c': 'Z',
    'f32_c': 'C',
    'f64_r': 'D',
    'f32_r': 'S',
    'xf32_r': 'S_MX',
    'f16_r': 'H',
    'bf16_r': 'B',
    'i32_r': 'I',
    'i8_r': 'I8',
    'f8_r': 'F8',
    'bf8_r': 'B8',
    '': ''
}

# Dictionary to map names to their types
name2type = {}
for key, value in type2name.items():
    name2type[value] = key




########################################################################################################################
def decodeGEMMName(gemmName: str):
    # ------------------------------------------------------------------------------------------------------------------
    """
    Decodes GEMM names to datatypes

    Args:
        gemmName (str): The name of the gemm

    Returns:
        tuple: (<type_A>, <type_B>, <type_C>,<type_D>, <type_compute>)
        tuple: (<type_A>, <type_B>, <type_C>,<type_D>, <type_compute>, <type_inputA>, <type_inputB> )
                if the <type_inputA><type_inputB> is in the gemmName

    Examples:
        decodeGEMMName('F8B8F8S') = ('f8_r', 'bf8_r', 'f8_r', 'f8_r', 'c_f32_r')
    """
    # ------------------------------------------------------------------------------------------------------------------
    # helper function to slice a string to pieces starting with an alphabet.
    def sliceToAlphabet( s ):
        slices = []
        current_slice = ""
        for char in s:
            # Check if the character is an alphabet
            if char.isalpha():
                # Save the current slice if it exists
                if current_slice:
                    slices.append(current_slice)
                # Start a new slice with the alphabet
                current_slice = char
            # Otherwise, add the character to the current slice
            else:
                current_slice += char

        # Add the final slice if it exists
        if current_slice:
            slices.append(current_slice)

        return slices

    # ------------------------------------------------------------------------------------------------------------------
    # non-HPA
    if 'GEMM' in gemmName:
        gemmName = gemmName.replace('GEMM','')
        # all types are the same
        type_A = type_B = type_C = type_D = type_compute = name2type[gemmName]
        return type_A, type_B, type_C, type_D, 'c_' + type_compute
    # Special case
    if gemmName == 'S_MX':
        type_A = type_B = type_C = type_D = name2type['S']
        type_compute = name2type[gemmName]
        return type_A, type_B, type_C, type_D, 'c_' + type_compute

    # HPA
    # Check if there is underscore in gemmName, then breaks it into two slices
    inputName = ''
    if '_' in gemmName:
        inputName, gemmName = gemmName.split("_", 1)
    # Special case: "_SR"
    if '_' in gemmName or gemmName == 'SR':
        raise NotImplementedError( 'SR GEMMs are not implemented yet.' )

    # Slice
    gemmSlices = sliceToAlphabet(gemmName)
    inputSlices = sliceToAlphabet(inputName)

    # MFMA datatypes
    if len(gemmSlices) == 3:
        type_A = type_B = name2type[gemmSlices[0]]
        type_C = type_D = name2type[gemmSlices[1]]
        type_compute = 'c_' + name2type[gemmSlices[2]]
    elif len(gemmSlices) == 4:
        type_A = name2type[gemmSlices[0]]
        type_B = name2type[gemmSlices[1]]
        type_C = type_D = name2type[gemmSlices[2]]
        type_compute = 'c_' + name2type[gemmSlices[3]]

    # input datatypes
    if len(inputSlices) == 0:
        return type_A, type_B, type_C, type_D, type_compute
    if len(inputSlices) == 2:
        type_inputA = name2type[inputSlices[0]]
        type_inputB = name2type[inputSlices[1]]
        return type_A, type_B, type_C, type_D, type_compute, type_inputA, type_inputB




########################################################################################################################
def encodeGEMMName(type_A: str, type_B: str, type_C: str, type_D: str, type_compute: str,
                   type_inputA: str = '', type_inputB: str = ''):
    # ------------------------------------------------------------------------------------------------------------------
    """
    Encodes the datatypes into a GEMM name

    Args:
        type_A (str)
        type_B (str)
        type_C (str)
        type_D (str)
        type_compute (str)
        type_inputA (str)
        type_inputB (str)

    Returns:
        str: GEMM name

    Examples:
        encodeGEMMName('f8_r', 'bf8_r', 'f8_r', 'f8_r', 'c_f32_r') = 'F8B8F8S'
    """
    # ------------------------------------------------------------------------------------------------------------------
    gemmName = ''
    # Special case: S_MX
    if type_A == type_B == type_C == type_D == name2type['S'] and type_compute == 'c_' + name2type['S_MX']:
        return 'S_MX'

    # non-HPA
    if type_A == type_B == type_C == type_D == type_compute.replace('c_', ''):
        gemmName += type2name[type_A]
        gemmName += 'GEMM'
        return gemmName

    # HPA
    if type_A == type_B:
        type_B = ''
    if type_C == type_D:
        type_D = ''

    # inputs are the same as MFMA
    if type_inputA != '' and type_inputB != '':
        gemmName += type2name[type_inputA]
        gemmName += type2name[type_inputB]
        gemmName += '_'

    for type in (type_A, type_B, type_C, type_D, type_compute.replace('c_', '')):
        gemmName += type2name[type]

    return gemmName




########################################################################################################################
# if __name__ == '__main__':
#     print(decodeGEMMName('S_MX'))
#     print(decodeGEMMName('F8B8F8S'))
#     print(decodeGEMMName('F8H_F8SS'))
#     print(decodeGEMMName('HH_B8F8HS'))
#
#     print(encodeGEMMName('f32_r', 'f32_r', 'f32_r', 'f32_r', 'c_xf32_r'))
#     print(encodeGEMMName('f32_c', 'f32_c', 'f32_c', 'f32_c', 'c_f32_c'))
#     print(encodeGEMMName('f32_r', 'f32_r', 'f32_r', 'f32_r', 'c_f32_r'))
#     print(encodeGEMMName('f16_r', 'f16_r', 'f16_r', 'f16_r', 'c_f16_r'))
#     print(encodeGEMMName('f8_r', 'bf8_r', 'f8_r', 'f8_r', 'c_f32_r'))
#     print(encodeGEMMName('bf8_r', 'f8_r', 'f16_r', 'f16_r', 'f32_r', 'f16_r', 'f16_r'))






