################################################################################
#
# Copyright (C) 2024 Advanced Micro Devices, Inc. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
################################################################################

# Generates four hipblaslt-bench input files from the library logic files: beta 0/1 + rotating buffer 0/1. The cold and hot iteration counts are based on the performance in the library logic. 

# Usage:
# $ python3 hipblaslt-benchInputCreator.py [-v] [-i <init>] <lib logic dir> <output dir>

# creates the benchmark yamls and verification files with default iterations and initialization:
# $ python3 hipblaslt-benchInputCreator.py -v ../libLogics ./

# creates the benchmark yamls for 3s of benchamrking with default initialization:
# $ python3 hipblaslt-benchInputCreator.py -v -d 3.0 ../libLogics ./

# creates the benchmark yamls and verification files with hpl initialization:
# $ python3 hipblaslt-benchInputCreator.py -v -i hpl ../libLogics ./

# creates the benchmark yamls using the default initialization (trig or int)
# $ python3 hipblaslt-benchInputCreator.py ../libLogics ./

import argparse
import os
import yaml
import math

#typeIndexToName = {0: "f32_r", 1: "f64_r", 2: "f32_c", 3: "f64_c", 4: "f16_r", 5: "i8_r", 6: "i32_r", 7: "bf16_r", 8: "i8_r", 10: "f8_r", 11: "bf8_r", 12: "f8b8", 13: "b8f8"}
# for hipblaslt, 8bit types are shifted
typeIndexToName = {0: "f32_r", 1: "f64_r", 2: "f32_c", 3: "f64_c", 4: "f16_r", 5: "i8_r", 6: "i32_r", 7: "bf16_r", 8: "i8_r", 9: "i64_r", 10: "xf32", 11: "f8_r", 12: "bf8_r", 13: "f8b8", 14: "b8f8", 15: "f8_r", 16: "bf8_r", 17: "f8b8", 18: "b8f8"}

def parseArgs():
    argParser = argparse.ArgumentParser()

    h = {"libLogic" : "Input library logic file",
         "outDir"   : "Output directory for hipblaslt-bench yaml files",
         "verify"   : "Also output verify version of yaml files",
         "initial"  : "Matrix initialization: hpl, trig, int. The default is trig for non Int8 datatype, and int for Int8.",
         "duration" : "total benchmark duration in seconds. Default is 0 (10/2 iterations)"
    }

    argParser.add_argument("libLogic", metavar="logic-file", type=str, help=h["libLogic"])
    argParser.add_argument("outDir", metavar="output-dir", type=str, help=h["outDir"])
    argParser.add_argument("--verify", "-v", action="store_true", help=h["verify"])
    argParser.add_argument("--initialization", "-i", action="store", type=str, default = 'trig',  help=h["initial"])
    argParser.add_argument("--duration", "-d", action="store", type=float, default = 0.0,  help=h["duration"])

    return argParser.parse_args()

def getProblemType(problem):
    # transA/B, a/b/c/d/compute_type
    problemDict = {}

    if problem["ComplexConjugateA"]:
        problemDict["transA"] = "C"
    elif problem["TransposeA"]:
        problemDict["transA"] = "T"
    else:
        problemDict["transA"] = "N"

    if problem["ComplexConjugateB"]:
        problemDict["transB"] = "C"
    elif problem["TransposeB"]:
        problemDict["transB"] = "T"
    else:
        problemDict["transB"] = "N"

    problemDict["a_type"] = typeIndexToName[problem["DataType"]]
    problemDict["b_type"] = typeIndexToName[problem["DataType"]]
    problemDict["c_type"] = typeIndexToName[problem["DestDataType"]]
    problemDict["d_type"] = typeIndexToName[problem["DestDataType"]]

    f8gemm = True if (problem["DataType"]>=10) else False # is it f8

    if "ComputeDataType" in problem:
        compType = typeIndexToName[problem["ComputeDataType"]]
        problemDict["scale_type"] = compType

        if "F32XdlMathOp" in problem and problem["F32XdlMathOp"]==10: # XF32
            compType = "x"+compType

        #if f8gemm: # f8 gemm
        #  if (typeIndexToName[problem["DataType"]] =="f8b8" and typeIndexToName[problem["DestDataType"]]=="f16_r"): # for F8B8HS
        #    problemDict["a_type"] = "f16_r"
        #    problemDict["b_type"] = "f16_r"
        #    problemDict["composite_compute_type"] = "f8_bf8_f32"
        #  elif (typeIndexToName[problem["DataType"]] =="b8f8" and typeIndexToName[problem["DestDataType"]]=="f16_r"): # for B8F8HS
        #    problemDict["a_type"] = "f16_r"
        #    problemDict["b_type"] = "f16_r"
        #    problemDict["composite_compute_type"] = "bf8_f8_f32"
        #  elif (typeIndexToName[problem["DataType"]] =="f8_r" and typeIndexToName[problem["DestDataType"]]=="f16_r"): # for F8HS
        #    problemDict["a_type"] = "f16_r"
        #    problemDict["b_type"] = "f16_r"
        #    problemDict["composite_compute_type"] = "f8_f8_f32"
        #  elif (typeIndexToName[problem["DataType"]] =="bf8_r" and typeIndexToName[problem["DestDataType"]]=="f16_r"): # for B8HS
        #    problemDict["a_type"] = "f16_r"
        #    problemDict["b_type"] = "f16_r"
        #    problemDict["composite_compute_type"] = "bf8_bf8_f32"
        #  elif (typeIndexToName[problem["DataType"]] =="f8b8" and typeIndexToName[problem["DestDataType"]]=="f32_r"): # for B8SS
        #    problemDict["a_type"] = "f8_r"
        #    problemDict["b_type"] = "bf8_r"
        #    problemDict["composite_compute_type"] = "f32"
        #  elif (typeIndexToName[problem["DataType"]] =="b8f8" and typeIndexToName[problem["DestDataType"]]=="f32_r"): # for B8SS
        #    problemDict["a_type"] = "bf8_r"
        #    problemDict["b_type"] = "f8_r"
        #    problemDict["composite_compute_type"] = "f32"
        #  elif (typeIndexToName[problem["DataType"]] =="b8f8" and typeIndexToName[problem["DestDataType"]]=="bf8_r"): # for B8F8B8S
        #    problemDict["a_type"] = "bf8_r"
        #    problemDict["b_type"] = "f8_r"
        #    problemDict["composite_compute_type"] = "f32"
        #  elif (typeIndexToName[problem["DataType"]] =="f8b8" and typeIndexToName[problem["DestDataType"]]=="bf8_r"): # for F8B8B8S
        #    problemDict["a_type"] = "f8_r"
        #    problemDict["b_type"] = "bf8_r"
        #    problemDict["composite_compute_type"] = "f32"
        #  else:
        #    problemDict["composite_compute_type"] = "f32"
        #else:
        #  problemDict["compute_type"] = "c_" + compType
        problemDict["compute_type"] = "c_" + compType
    else:
        if problemDict["a_type"] == "f16_r" and problem["HighPrecisionAccumulate"]:
            problemDict["compute_type"] = "c_f32_r"
        elif problem["DataType"] == 5:
            problemDict["compute_type"] = "i32_r"
        else:
            problemDict["compute_type"] = problemDict["a_type"]

    if "F32XdlMathOp" in problem and problem["F32XdlMathOp"]==9: # XF32
        problemDict["math_mode"] = 1

    return problemDict

def getSizeParams(size, transA, transB):
    # M/N/K, batch_count, lda/b/c/d
    sizeDict = {}
    sizeDict["M"] = size[0]
    sizeDict["N"] = size[1]
    sizeDict["K"] = size[3]

    if size[2] != 1:
        sizeDict["batch_count"] = size[2]
        # hipblaslt-bench will handle setting default strides

    if len(size)==8: # ld defined in the library logic
        sizeDict["ldc"] = size[4]
        sizeDict["ldd"] = size[5]
        sizeDict["lda"] = size[6]
        sizeDict["ldb"] = size[7]
    else: # no ld defined in the library logic
        sizeDict["ldc"] = size[0]
        sizeDict["ldd"] = size[0]
        if not transA and not transB: # NN
            sizeDict["lda"] = size[0]
            sizeDict["ldb"] = size[3]
        elif transA and not transB:   # TN
            sizeDict["lda"] = size[3]
            sizeDict["ldb"] = size[3]
        elif not transA and transB:   # NT
            sizeDict["lda"] = size[0]
            sizeDict["ldb"] = size[1]
        else:                         # TT
            sizeDict["lda"] = size[3]
            sizeDict["ldb"] = size[1]

    return sizeDict


def dumpYaml(outDir, outputfile,postfix, content):
    name = outputfile+postfix
    benchPath = os.path.join(outDir, name)
    with open(benchPath, "w") as f:
        yaml.safe_dump(content, f, default_flow_style=None, sort_keys=False, width=5000)
        f.write(f"# End of {name} \n")

def createYaml(initialization, isGeneralBatched, duration, outDir, outputfile, problem, sizeMappings, verify, variant = 0):
    """
    variant - variant to dump
    0 - all
    1 - no beta and rotating 
    2 - beta0 
    3 - rotating
    4 - beta0 and rotating 
    5 - beta1 and rotating

    """
    bench = []
    benchStrided = []
    benchGeneralBatched = []

    bench_rotating = []
    benchStrided_rotating = []
    benchGeneralBatched_rotating = []

    bench_beta0 = []
    benchStrided_beta0 = []
    benchGeneralBatched_beta0 = []

    bench_beta0_rotating = []
    bench_beta1_rotating = []
    benchStrided_beta0_rotating = []
    benchStrided_beta1_rotating = []
    benchGeneralBatched_beta0_rotating = []
    benchGeneralBatched_beta1_rotating = []

    bench_verify = []
    benchStrided_verify = []
    benchGeneralBatched_verify = []

    # get GEMM function and matrix orientation - Fixed for each library
    problemParams = getProblemType(problem)
    transA = problem["TransposeA"]
    transB = problem["TransposeB"]

    if verify:
        otherParams_verify = {"alpha": 1, "beta": 1, "iters": 1, "cold_iters": 0, "use_gpu_timer": 1, "print_kernel_info": 1, "scale_type":  problemParams["scale_type"], "norm_check": 1, "norm_check_assert": 0}

    #initialization
    if (initialization=='hpl' and problemParams["a_type"]!="i8_r"):
        init = {"initialization": "hpl"}
    elif (initialization=='trig' and problemParams["a_type"]!="i8_r"):
        init = {"initialization": "trig_float"}
    elif initialization== 'int':
        init = {"initialization": "rand_int"}
    else:
      print(f"Initialization {initialization} is not allowed for int8 datatype. Initialization changed to rand_int.")
      init = {"initialization": "rand_int"}

    # create hipblaslt-bench call for each size in logic file
    for (size, perf) in sizeMappings: # size[0] = M, size[1] = N, size[2] = batch_count, size[3] = K, size[4] = ldc, size[5] = ldd, size[6] = lda, size[7] = ldb

        params = {}
        
        params["function"] = "matmul"
        # if (not isGeneralBatched and size[2] == 1):  # non-f8, non-batched gemm (serves both HPA and non-HPA)
        #     params["function"] = "matmul"
        # else:
        #     raise RuntimeError(" not supporting Strided/General Batched.")

        sizeParams = getSizeParams(size, transA, transB)

        if  duration>0.0:
            latency = 2*sizeParams['M']*sizeParams['N']*sizeParams['K']/perf[1]/1000 # us
            latency *= sizeParams["batch_count"] if "batch_count" in sizeParams else 1
            cold_iters = math.ceil( duration* 1e6 / latency)
            iters = cold_iters
            coe = 1.15
        else:
            cold_iters = 2
            iters = 10
            coe = 1
        
        otherParams = {"alpha": 1, "beta": 1, "iters": iters, "cold_iters": cold_iters, "use_gpu_timer": 1, "print_kernel_info": 1,  "scale_type":  problemParams["scale_type"], "flush": True}
        otherParams_rotating = {**otherParams, "rotating": 512}

        otherParams_beta0 = {"alpha": 1, "beta": 0, "iters": math.ceil( coe * iters), "cold_iters": math.ceil( coe * cold_iters), "use_gpu_timer": 1, "print_kernel_info": 1, "scale_type":  problemParams["scale_type"], "flush": True }
        otherParams_beta0_rotating = {**otherParams_beta0, "rotating": 512}

        otherParams_beta1 = {"alpha": 1, "beta": 1, "iters": math.ceil( coe * iters), "cold_iters": math.ceil( coe * cold_iters), "use_gpu_timer": 1, "print_kernel_info": 1, "scale_type":  problemParams["scale_type"], "flush": True }
        otherParams_beta1_rotating = {**otherParams_beta1, "rotating": 512}

        params.update(problemParams)
        params.update(sizeParams)
        params.update(init)

        if (size[2] == 1 and not isGeneralBatched):
            bench.append({**params, **otherParams})
            bench_rotating.append({**params, **otherParams_rotating})
            bench_beta0.append({**params, **otherParams_beta0})
            bench_beta0_rotating.append({**params, **otherParams_beta0_rotating})
            bench_beta1_rotating.append({**params, **otherParams_beta1_rotating})
            if verify:
                bench_verify.append({**params, **otherParams_verify})

        elif (isGeneralBatched):
            benchGeneralBatched.append({**params, **otherParams})
            benchGeneralBatched_rotating.append({**params, **otherParams_rotating})
            benchGeneralBatched_beta0.append({**params, **otherParams_beta0})
            benchGeneralBatched_beta0_rotating.append({**params, **otherParams_beta0_rotating})
            benchGeneralBatched_beta1_rotating.append({**params, **otherParams_beta1_rotating})
            if verify:
                benchGeneralBatched_verify.append({**params, **otherParams_verify})            
        else:
            benchStrided.append({**params, **otherParams})
            benchStrided_rotating.append({**params, **otherParams_rotating})
            benchStrided_beta0.append({**params, **otherParams_beta0})
            benchStrided_beta0_rotating.append({**params, **otherParams_beta0_rotating})
            benchStrided_beta1_rotating.append({**params, **otherParams_beta1_rotating})
            if verify:
                benchStrided_verify.append({**params, **otherParams_verify})

    # write output
    if len(bench) > 0:
        if(variant == 0 or variant == 1): dumpYaml(outDir, outputfile,"_bench.yaml", bench)
        if(variant == 0 or variant == 2): dumpYaml(outDir, outputfile,"_bench_beta0.yaml", bench_beta0)
        if(variant == 0 or variant == 3): dumpYaml(outDir, outputfile, "_bench_rotating.yaml", bench_rotating)
        if(variant == 0 or variant == 4): dumpYaml(outDir, outputfile, "_bench_beta0_rotating.yaml", bench_beta0_rotating)
        if(variant == 0 or variant == 5): dumpYaml(outDir, outputfile, "_bench_beta1_rotating.yaml", bench_beta1_rotating)
        if verify:
            dumpYaml(outDir, outputfile, "_verify.yaml", bench_verify)

    if len(benchStrided) > 0:
        if(variant == 0 or variant == 1): dumpYaml(outDir, outputfile, "_bench-strided.yaml", benchStrided)
        if(variant == 0 or variant == 2): dumpYaml(outDir, outputfile, "_bench-strided_beta0.yaml", benchStrided_beta0)
        if(variant == 0 or variant == 3): dumpYaml(outDir, outputfile, "_bench-strided_rotating.yaml", benchStrided_rotating)
        if(variant == 0 or variant == 4): dumpYaml(outDir, outputfile, "_bench-strided_beta0_rotating.yaml", benchStrided_beta0_rotating)
        if(variant == 0 or variant == 5): dumpYaml(outDir, outputfile, "_bench-strided_beta1_rotating.yaml", benchStrided_beta1_rotating)
        if verify:
            dumpYaml(outDir, outputfile, "_verify-strided.yaml", benchStrided_verify)

    if len(benchGeneralBatched) > 0:
        if(variant == 0 or variant == 1): dumpYaml(outDir, outputfile, "_bench-general-batched.yaml", benchGeneralBatched)
        if(variant == 0 or variant == 2): dumpYaml(outDir, outputfile, "_bench-general-batched_beta0.yaml", benchGeneralBatched_beta0)
        if(variant == 0 or variant == 3): dumpYaml(outDir, outputfile, "_bench-general-batched_rotating.yaml", benchGeneralBatched_rotating)
        if(variant == 0 or variant == 4): dumpYaml(outDir, outputfile, "_bench-general-batched_beta0_rotating.yaml", benchGeneralBatched_beta0_rotating)
        if(variant == 0 or variant == 5): dumpYaml(outDir, outputfile, "_bench-general-batched_beta1_rotating.yaml", benchGeneralBatched_beta1_rotating)
        if verify:
            dumpYaml(outDir, outputfile, "_verify-general-batched.yaml", benchGeneralBatched_verify)

def main():
    args = parseArgs()

    if not (args.initialization in ['hpl', 'trig', 'int']):
        raise RuntimeError(f"Initialization {args.initialization} is not allowed. Choose from hpl, trig, or int.")

    for libname in os.listdir(args.libLogic):
        output = os.path.splitext(libname)[0]
        print(f" working on {output}")
        yamlName = os.path.join(args.libLogic,libname)
        if ".yaml" not in yamlName:
          continue
        with open(yamlName) as f:
            logicData = yaml.safe_load(f)

        try:
            os.makedirs(args.outDir)
        except OSError:
            pass

        problem = logicData[4]
        sizeMappings = logicData[7]
        # check if the library is General Batched based on the library name
        isGeneralBatched = True if "_GB.yaml" in os.path.split(args.libLogic)[-1] else False
    
        createYaml(args.initialization, isGeneralBatched, args.duration, args.outDir, output, problem, sizeMappings, args.verify, variant = 0)

if __name__ == "__main__":
    main()

