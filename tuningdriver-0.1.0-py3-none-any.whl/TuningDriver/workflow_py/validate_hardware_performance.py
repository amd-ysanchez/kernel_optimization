import pandas as pd
import matplotlib.pyplot as plt
import sys
import os
import re
import subprocess
import threading
import time
import argparse
import tempfile
from collections import defaultdict
from datetime import datetime
import numpy as np

# Default YAML configuration
DEFAULT_YAML_CONTENT = """
- {function: matmul, transA: T, transB: N, initialization: trig_float, alpha: 1, beta: 0, iters: 6408, cold_iters: 6408, flush: true, rotating: 512, use_gpu_timer: 1, a_type: bf16_r, b_type: bf16_r, c_type: bf16_r, d_type: bf16_r, scale_type: f32_r, compute_type: c_f32_r, M: 4096, N: 4096, K: 8192}
- {function: matmul, transA: T, transB: N, initialization: trig_float, alpha: 1, beta: 0, iters: 169444, cold_iters: 169444, flush: true, rotating: 512, use_gpu_timer: 1, a_type: bf16_r, b_type: bf16_r, c_type: bf16_r, d_type: bf16_r, scale_type: f32_r, compute_type: c_f32_r, M: 32, N: 2048, K: 2048}
- {function: matmul, transA: T, transB: N, initialization: trig_float, alpha: 1, beta: 0, iters: 6180, cold_iters: 6180, flush: true, rotating: 512, use_gpu_timer: 1, a_type: bf16_r, b_type: bf16_r, c_type: bf16_r, d_type: bf16_r, scale_type: f32_r, compute_type: c_f32_r, M: 38912, N: 512, K: 4096}
- {function: matmul, transA: T, transB: N, initialization: trig_float, alpha: 1, beta: 0, iters: 13594, cold_iters: 13594, flush: true, rotating: 512, use_gpu_timer: 1, a_type: f8_r, b_type: f8_r, c_type: f16_r, d_type: f16_r, scale_type: f32_r, compute_type: c_f32_r, M: 4096, N: 4096, K: 8192}
- {function: matmul, transA: T, transB: N, initialization: trig_float, alpha: 1, beta: 0, iters: 168728, cold_iters: 168728, flush: true, rotating: 512, use_gpu_timer: 1, a_type: f8_r, b_type: f8_r, c_type: f16_r, d_type: f16_r, scale_type: f32_r, compute_type: c_f32_r, M: 32, N: 2048, K: 2048}
- {function: matmul, transA: T, transB: N, initialization: trig_float, alpha: 1, beta: 0, iters: 11701, cold_iters: 11701, flush: true, rotating: 512, use_gpu_timer: 1, a_type: f8_r, b_type: f8_r, c_type: f16_r, d_type: f16_r, scale_type: f32_r, compute_type: c_f32_r, M: 38912, N: 512, K: 4096}
""".strip()

class Tee(object):
    def __init__(self, *files):
        self.files = files
    def write(self, obj):
        for f in self.files:
            f.write(obj)
            f.flush()
    def flush(self):
        for f in self.files:
            f.flush()

def get_argument_parser():
    parser = argparse.ArgumentParser(
        description='Run AGT and hipblaslt-bench simultaneously, then plot results',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    parser.add_argument(
        '--agt-path',
        default='/opt/amd-apps/agt_internal/agt_internal',
        help='Path to the AGT tool executable'
    )
    
    parser.add_argument(
        '--hipblaslt-bench-path',
        default='/opt/rocm-7.0.0/bin/hipblaslt-bench',
        help='Path to the hipblaslt-bench executable'
    )
    
    parser.add_argument(
        '--yaml-path',
        help='Path to the hipblaslt-bench input YAML configuration file (optional, uses embedded config if not provided)'
    )
    
    parser.add_argument(
        '--devices',
        default='0,1,2,3,4,5,6,7',
        help='Comma-separated device numbers to validate (default: 0,1,2,3,4,5,6,7). To run AGT only, set to an empty string ""'
    )
    
    parser.add_argument(
        '--unilogcount',
        type=int,
        default=300,
        help='Number of AGT unilog samples to collect (default: 300)'
    )

    parser.add_argument(
        '--unilog-metric',
        type=str,
        default="Post Deep Sleep Freq",
        help='AGT unilog metric to analyze (default: "Post Deep Sleep Freq")'
    )

    parser.add_argument(
        '--freq-drop-tolerance',
        type=float,
        default=0.15,
        help='Fractional drop threshold (e.g., 0.15 for 15%%) to consider a frequency drop significant (default: 0.15)'
    )

    parser.add_argument(
        '--gpu-unstable-threshold',
        type=int,
        default=5,
        help='Number of drops to consider system unstable (default: 3)'
    )
    
    return parser

def parse_arguments():
    parser = get_argument_parser()
    return parser.parse_args()

def create_output_directory():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = f"hw_perf_output_{timestamp}"
    
    os.makedirs(output_dir, exist_ok=True)
    print(f"Created output directory: {output_dir}")
    
    return output_dir

def create_temp_yaml_file():
    temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False)
    temp_file.write(DEFAULT_YAML_CONTENT)
    temp_file.close()
    return temp_file.name

def plot_unilog_metric(unilog_metric, csv_path, output_dir):
    # Check if file exists
    if not os.path.exists(csv_path):
        print(f"Error: File '{csv_path}' not found.")
        return
    
    try:
        # Read the CSV file
        df = pd.read_csv(csv_path)
        
        selected_cols = [col for col in df.columns if unilog_metric in col]
        
        if not selected_cols:
            print(f"No columns containing '{unilog_metric}' found in the CSV file.")
            return
        
        print(f"Found {len(selected_cols)} columns with '{unilog_metric}':")
        for col in selected_cols:
            print(f"  - {col}")
        
        # Group columns by GPU number
        gpu_columns = defaultdict(list)
        pattern = r'GPU(\d+)'
        
        for col in selected_cols:
            match = re.search(pattern, col)
            if match:
                gpu_num = match.group(1)
                gpu_columns[gpu_num].append(col)
        
        if not gpu_columns:
            print("No GPU-specific columns found with pattern 'GPU{number}'")
            return
        
        # Sort GPU numbers for consistent ordering
        sorted_gpu_nums = sorted(gpu_columns.keys(), key=int)
        
        # Calculate subplot layout
        num_gpus = len(sorted_gpu_nums)
        cols = min(3, num_gpus)  # Max 3 columns
        rows = (num_gpus + cols - 1) // cols  # Ceiling division
        
        # Create subplots with optimized figure size for better quality-to-size ratio
        fig, axes = plt.subplots(rows, cols, figsize=(8*cols, 6*rows), dpi=100)
        
        # Handle single subplot case
        if num_gpus == 1:
            axes = [axes]
        elif rows == 1:
            axes = axes if num_gpus > 1 else [axes]
        else:
            axes = axes.flatten()
        
        # Plot each GPU in a separate subplot
        for i, gpu_num in enumerate(sorted_gpu_nums):
            ax = axes[i]
            gpu_cols = gpu_columns[gpu_num]
            
            print(f"\nPlotting GPU{gpu_num} with {len(gpu_cols)} XCD columns:")
            
            # Plot each XCD column for this GPU
            for col in gpu_cols:
                # Remove NaN values for plotting
                data = df[col].dropna()
                if len(data) > 0:
                    # Extract XCD number for cleaner label
                    xcd_match = re.search(r'XCD(\d+)', col)
                    if xcd_match:
                        xcd_label = f"XCD{xcd_match.group(1)}"
                    else:
                        xcd_label = col
                    
                    # Optimized line settings for quality and visibility
                    ax.plot(data.index, data.values, label=xcd_label, 
                           marker='o', markersize=1.5, linewidth=0.8, alpha=0.9)
                    print(f"  - {col} ({len(data)} data points)")
            
            # Customize each subplot with optimized fonts
            ax.set_title(f'GPU{gpu_num} - {unilog_metric}', 
                        fontsize=14, fontweight='bold')
            ax.set_xlabel('Time stamp', fontsize=11)
            ax.set_ylabel('Frequency', fontsize=11)
            ax.legend(fontsize=9, loc='best')
            ax.grid(True, alpha=0.3)
            
            # Optimize tick parameters for better readability
            ax.tick_params(axis='both', which='major', labelsize=9)
        
        # Hide unused subplots
        for i in range(num_gpus, len(axes)):
            axes[i].set_visible(False)
        
        # Adjust layout with tighter padding
        plt.tight_layout(pad=2.0)
        
        # Show the plot
        plt.show()
        
        # Save plot in output directory
        plot_filename = 'analysis_result.png'
        output_path = os.path.join(output_dir, plot_filename)
        plt.savefig(output_path, dpi=150, bbox_inches='tight', 
                    facecolor='white', edgecolor='none')
        print(f"Plot saved as: {output_path}")
    
    except Exception as e:
        print(f"Error processing the CSV file: {e}")

def count_frequency_drops(unilog_metric, csv_path, tolerance, unstable_threshold):
    print("\n" + "="*100)
    print(f"Analyzing frequency drops for metric '{unilog_metric}' with tolerance {tolerance*100:.1f}% and unstable threshold {unstable_threshold}...")
    print("="*100)

    min_drop_length = 1
    max_drop_length = 10
    idle_threshold = 1000

    df = pd.read_csv(csv_path)
    selected_cols = [col for col in df.columns if unilog_metric in col]
    gpu_columns = {}
    pattern = r'GPU(\d+)'
    for col in selected_cols:
        match = re.search(pattern, col)
        if match:
            gpu_num = match.group(1)
            gpu_columns.setdefault(gpu_num, []).append(col)

    drop_counts = {}
    for gpu_num, cols in gpu_columns.items():
        print(f"Analyzing GPU{gpu_num}...")
        freq_matrix = df[cols].values  # shape: (num_samples, num_xcds)
        avg_freq = np.nanmean(freq_matrix, axis=1)
        drops = 0
        i = 1
        while i < len(avg_freq):
            prev = avg_freq[i-1]
            curr = avg_freq[i]

            # Ignore idle periods
            if prev < idle_threshold and curr < idle_threshold:
                i += 1
                continue

            # Detect drop
            if prev > 0 and (prev - curr) / prev > tolerance:
                # Look ahead for recovery
                drop_start = i
                drop_end = i
                while drop_end < len(avg_freq) and avg_freq[drop_end] < prev * (1 - tolerance/2):
                    drop_end += 1
                drop_length = drop_end - drop_start

                # Check if frequency recovers to near previous value
                if drop_length >= min_drop_length and drop_length <= max_drop_length:
                    if drop_end < len(avg_freq) and abs(avg_freq[drop_end] - prev) < prev * 0.05:
                        drops += drop_length
                        print(f"  Drop detected at Time stamp {i}: {prev:.2f} -> {curr:.2f} (length {drop_length}), recovery to {avg_freq[drop_end]:.2f}")
                        i = drop_end  # Skip to recovery point
                        continue
                i = drop_end
            else:
                i += 1

        drop_counts[gpu_num] = drops
        if drops >= unstable_threshold:
            print(f"  [UNSTABLE] Exceeded threshold ({unstable_threshold}) drops!")
        print(f"Result: {drops} frequency drop(s) detected\n")
    return drop_counts

def run_agt_command(agt_path, output_csv, unilogcount):
    """
    Run the AGT command in a separate thread
    
    Args:
        agt_path (str): Path to the AGT tool
        output_csv (str): Output CSV file path
        unilogcount (int): Number of unilog samples to collect
    """

    cmd = [
        "sudo", agt_path,
        "-unilog=pm",
        "-unilogallgroups",
        "-unilogperiod=50",
        "-i=0,5,10,15,20,25,30,35",
        f"-unilogcount={unilogcount}"
    ]
    
    print(f"Starting AGT command: {' '.join(cmd)}")
    
    try:
        result = subprocess.run(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
        
        if result.returncode == 0:
            print("AGT command completed successfully")
        else:
            print(f"AGT command failed with return code {result.returncode}")
            print(f"Error: {result.stderr}")
    except Exception as e:
        print(f"Error running AGT command: {e}")

def run_hipblaslt_bench(hipblaslt_bench_path, yaml_path, devices, output_dir):
    """
    Run the hipblaslt-bench command for each device
    
    Args:
        hipblaslt_bench_path (str): Path to hipblaslt-bench
        yaml_path (str): Path to the YAML configuration file
        devices (list): List of device numbers
        output_dir (str): Output directory for log files
    """
    if not devices:
        print("\nNo devices selected. Skipping hipblaslt-bench execution.\n")
        return

    processes = []
    log_files = []
    
    print(f"Starting hipblaslt-bench for devices: {devices}")
    print(f"Using YAML config: {yaml_path}")
    
    try:
        # Start a process for each device
        for device in devices:
            log_file = os.path.join(output_dir, f"hipblaslt_bench_output_device_{device}.log")
            log_files.append(log_file)
            
            # Build command: hipblaslt-bench --device N --yaml path/to/yaml 2>&1 | tee device_N.log
            cmd = f"{hipblaslt_bench_path} --device {device} --yaml {yaml_path}"
            
            print(f"Starting device {device}: {cmd}")
            
            # Start process in background with proper output redirection
            with open(log_file, 'w') as log_f:
                process = subprocess.Popen(
                    cmd.split(),
                    stdout=log_f,
                    stderr=subprocess.STDOUT,
                    text=True
                )
            processes.append((process, device, log_file))
        
        # Wait for all processes to complete
        print(f"\nWaiting for all {len(processes)} hipblaslt-bench processes to complete...")
        
        for process, device, log_file in processes:
            return_code = process.wait()
            if return_code == 0:
                print(f"Device {device} completed successfully (log: {log_file})")
            else:
                print(f"Device {device} failed with return code {return_code} (log: {log_file})")
        
        print("All hipblaslt-bench processes completed")
        
    except Exception as e:
        print(f"Error running hipblaslt-bench commands: {e}")
        # Try to terminate any running processes
        for process, device, log_file in processes:
            if process.poll() is None:
                print(f"Terminating process for device {device}")
                process.terminate()

def main():
    """
    Main function to coordinate AGT monitoring, hipblaslt-bench execution, and plotting
    """
    args = parse_arguments()
    
    output_dir = create_output_directory()

    log_path = os.path.join(output_dir, "validate_hardware_performance.log")
    log_file = open(log_path, "w")
    sys.stdout = Tee(sys.__stdout__, log_file)
    sys.stderr = Tee(sys.__stderr__, log_file)
    
    # Validate that the specified tools exist
    if not os.path.exists(args.agt_path):
        print(f"Error: AGT tool not found at '{args.agt_path}'")
        sys.exit(1)
    
    if not os.path.exists(args.hipblaslt_bench_path):
        print(f"Error: hipblaslt-bench not found at '{args.hipblaslt_bench_path}'")
        sys.exit(1)
    
    # Handle YAML configuration
    temp_yaml_file = None
    if args.yaml_path:
        # Use provided YAML file
        if not os.path.exists(args.yaml_path):
            print(f"Error: YAML file not found at '{args.yaml_path}'")
            sys.exit(1)
        yaml_path = args.yaml_path
        print(f"Using provided YAML config: {yaml_path}")
    else:
        # Create temporary YAML file with embedded configuration
        temp_yaml_file = create_temp_yaml_file()
        yaml_path = temp_yaml_file
        print(f"Using embedded YAML config (temporary file: {yaml_path})")
    
    try:
        if args.devices.strip() == "":
            device_list = []
        else:
            device_list = [int(d.strip()) for d in args.devices.split(',') if d.strip() != ""]
        print(f"Will test devices: {device_list}")
    except ValueError:
        print(f"Error: Invalid device numbers '{args.devices}'. Use comma-separated integers.")
        sys.exit(1)
    
    print("="*100)
    print("Starting concurrent AGT monitoring and hipblaslt-bench execution")
    print("="*100)
    print(f"Output directory: {output_dir}")
    print(f"AGT path: {args.agt_path}")
    print(f"hipblaslt-bench path: {args.hipblaslt_bench_path}")
    print(f"YAML config: {yaml_path}")
    print(f"Devices: {device_list}")
    print(f"AGT unilogcount: {args.unilogcount}")
    print("="*100)

    agt_output_file = os.path.join(output_dir, 'unilog.csv')
    
    try:
        # Create threads for both commands
        agt_thread = threading.Thread(
            target=run_agt_command,
            args=(args.agt_path, agt_output_file, args.unilogcount)
        )
        
        hipblaslt_thread = threading.Thread(
            target=run_hipblaslt_bench,
            args=(args.hipblaslt_bench_path, yaml_path, device_list, output_dir)
        )
        
        # Start both threads
        print("\nStarting AGT monitoring...")
        agt_thread.start()
        
        # Give AGT a moment to start up
        time.sleep(2)
        
        print("Starting hipblaslt-bench processes...")
        hipblaslt_thread.start()
        
        # Wait for both threads to complete
        
        print("\nWaiting for both AGT and hipblaslt-bench to complete...")
        agt_thread.join()
        hipblaslt_thread.join()
        
        print("\nBoth commands completed!")
        
        # Check if AGT output file was created
        # Note: AGT might create the file in current directory, so check both locations
        current_dir_agt_file = 'unilog.csv'
        
        # First check if AGT created file in current directory and move it
        if os.path.exists(current_dir_agt_file):
            import shutil
            shutil.move(current_dir_agt_file, agt_output_file)
            print(f"Moved AGT output file to: {agt_output_file}")
        
        if os.path.exists(agt_output_file):
            print(f"\nAGT output file created: {agt_output_file}")
            
            # Give a moment for file to be fully written
            time.sleep(1)
            
            # Generate the plot
            print(f"\nGenerating {args.unilog_metric} plot...")
            plot_unilog_metric(args.unilog_metric, agt_output_file, output_dir)
            count_frequency_drops(args.unilog_metric, agt_output_file, args.freq_drop_tolerance, args.gpu_unstable_threshold)
        else:
            print(f"\nError: AGT output file '{agt_output_file}' was not created")
            # Check for any unilog files in current directory
            unilog_files = [f for f in os.listdir('.') if f.startswith('unilog') and f.endswith('.csv')]
            if unilog_files:
                print(f"Found these unilog files in current directory: {unilog_files}")
                # Move the most recent one
                most_recent = max(unilog_files, key=os.path.getctime)
                import shutil
                shutil.move(most_recent, agt_output_file)
                print(f"Moved {most_recent} to {agt_output_file}")
                plot_unilog_metric(args.unilog_metric, agt_output_file, output_dir)
                count_frequency_drops(args.unilog_metric, agt_output_file, args.freq_drop_tolerance, args.gpu_unstable_threshold)
            else:
                sys.exit(1)
    
    finally:
        # Clean up temporary YAML file if created
        if temp_yaml_file and os.path.exists(temp_yaml_file):
            os.unlink(temp_yaml_file)
            print(f"\nCleaned up temporary YAML file: {temp_yaml_file}")

    log_file.close()

if __name__ == "__main__":
    main()
