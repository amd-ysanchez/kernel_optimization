from typing import Union, Iterable

import ast
import re
import os
import yaml
import glob
import pandas as pd

import logging
logger = logging.getLogger(f"benchmark:{os.path.basename(__file__).split('.')[0]}")


def parse_type(val: str):
    """
    Tries to convert a string value to a numeric one. If not possible retuns the original value.
    """
    import ast
    try:
        val = ast.literal_eval(val)
    except ValueError:
        pass
    return val


def uniq(iterator: Iterable):
    """
    Emulates the 'uniq' unix command, trimming duplicated consecutive lines.
    """
    previous = float("NaN")  # Not equal to anything
    for value in iterator:
        if previous != value:
            yield value
            previous = value
            
def uniq_counts(iterator: Iterable):
    """
    Aggregates unique lines and returns their count. 
    """
    lines = {}
    for value in iterator:
        value = value.strip()
        if value not in lines:
            lines[value] = 0
        lines[value] += 1
    return lines.items()

def read_yaml(input_file: str) -> Union[list, dict]:
    """
    Reads a YAML file and returns its contents, with type check for a dictionary or list.
    """
    with open(input_file, 'r') as f:
        data = yaml.safe_load(f)
    if not isinstance(data, (dict, list)):
        raise TypeError(f"YAML file contents of type {type(data)} found.") 
    
    return data


def write_yaml(data: Union[list, dict], output_file: str):
    """
    Writes the provided data to a YAML file.
    """
    with open(output_file, 'w') as f:
        yaml.dump(data, f, default_flow_style=None, sort_keys=False, width=5000)


def commands_to_yaml(log_file: str, in_place: bool = False) -> str:
    """
    Parses hipBLASLt call file (MASK set to 32) output and tries to convert it to YAML (MASK=64 format).
    
    Args:
        log_file (str):  Path to the hipBLASLt log file
        in_place (bool): If set, it will modify the log file in place, otherwise it will save
                         it with the same name with yaml extension.
    Returns:
        str: The path for the updated log file
        
    Raises:
        FileNotFoundError: If the some/all of the files do not exist
        ValueError: If the benchmark log file content is not valid
    """
    logger.info(f"Attempting to convert log file to YAML format.")
    rows = []
    try:
        for i, (line, counts) in enumerate(uniq_counts(open(log_file))):
            if 'hipblaslt-bench' not in line:
                continue
            line = line.replace('hipblaslt-bench', '')
            line = re.sub(r'--algo_method index', f'', line)
            line = re.sub(r'--solution_index [0-9]+', f'', line)
            line = re.sub(r'--api_method c', f'', line)
            ctype = re.findall(r'--compute_type .+', line)
            if len(ctype) > 0:
                ctype = f"c_{ctype[0].split(' ')[1]}"
                line = re.sub(r'--compute_type .+', f'--compute_type {ctype} ', line)
            line = line.strip()
            params = [p.strip().split(" ") for p in line.split("-") if len(p) > 0]
            row = {p[0]: parse_type(p[1]) if len(p) > 1 else True for p in params}
            if 'function' not in row:
                row['function'] = 'matmul'
            row["M"] = row.pop("m")
            row["N"] = row.pop("n")
            row["K"] = row.pop("k")
            row["call_counts"] = counts
            rows.append(row)
    except KeyError:
        pass
        
    if len(rows) == 0:
        raise TypeError(f"{log_file} format is not valid.")
    
    if not in_place:
        log_file = f"{os.path.splitext(log_file)[0]}.yaml"
    
    write_yaml(rows, log_file)
    logger.info(f"Converted log file written to {log_file}")
    return log_file


def aggregate_logs(log_dir: str, output_name: str = "merged.yaml") -> str:
    """
    Merges all valid log files in a folder.
    
    Args:
        log_dir (str):     Path to the directory where the log files are placed.
        output_name (str): Destination path for the merged file.
        
    Returns:
        str: The path for the merged log file
        
    Raises:
        FileNotFoundError: If the some/all of the files do not exist.
        ValueError: If no valid log files are found.
    """
    files = glob.glob(f"{log_dir}/*.*")
    fname = os.path.join(log_dir, output_name)
    
    merged_data = []
    for yaml_file in files:
        if yaml_file == fname:
            continue
            
        with open(yaml_file, 'r') as f:
            data = yaml.safe_load(f)
        if not isinstance(data, (dict, list)): 
            try:
                cvt_file = commands_to_yaml(yaml_file)
                data = read_yaml(cvt_file)
            except (TypeError, KeyError):
                continue

        merged_data.extend(data)

    if len(merged_data) == 0:
        raise ValueError(f"No valid files found in {log_dir}")
    
    df = pd.DataFrame(merged_data)
    cols = [c for c in df.columns if c != "call_count"]
    if "call_count" not in df.columns:
        df["call_count"] = 1
    df = df.groupby(cols, dropna=False, sort=False).sum("call_count").reset_index()
    
    data = [{k: v for k, v in r.items() if pd.notnull(v)} for r in df.to_dict(orient='records')]    
    write_yaml(data, fname)
    logger.info(f"Aggregated log(s) written to {fname}")
    return fname


def parse_grid_points(latency_file: str, output_file: str):
    """
    Parses the grid points used from env TENSILE_DB = 0x8012
    
    Args:
        latency_file (str):  Path to benchmark latency log.
        output_file (str):   Destination path for the parsed grid point information.
        
    Raises:
        FileNotFoundError:     If the latency file does not exist.
        IndexError/ValueError: If the latency files contents are not valid.
    """
    res = []
    blocks = open(latency_file).read().split("[0]")
    for grid, bench in zip(blocks[::2], blocks[1::2]):
        raw = grid.split("<-- Best so far")[-2].split("\n")[-1].split(":")[0]
        m_grid, n_grid, b_grid, k_grid = [int(p.strip()) for p in raw.split(",")]
        transA, transB, _, b, m, n, k = bench.split("\n")[1].strip().split(",")[:7]
        res.append(dict(m=m, 
                        n=n, 
                        b=b, 
                        k=k, 
                        transA=transA, 
                        transB=transB, 
                        m_grid=m_grid,
                        n_grid=n_grid,
                        b_grid=b_grid,
                        k_grid=k_grid))

    pd.DataFrame(res).to_csv(output_file, index=False)