import pandas as pd
import yaml
import io
import os

from benchmark.parser import read_yaml

import logging
logger = logging.getLogger(f"benchmark:{os.path.basename(__file__).split('.')[0]}")

PERF_COLS = ["hipblaslt-Gflops", "hipblaslt-GB/s", "us"]


def parse_latency(file: str, output_file: str = None) -> pd.DataFrame:
    """
    Parse hipBLASLt benchmark output file into a pandas DataFrame.
    
    Args:
        file (str):        Path to the hipBLASLt benchmark output file
        output_file (str): Path to the generated latency report
        
    Returns:
        pandas.DataFrame: DataFrame containing parsed benchmark results
        
    Raises:
        FileNotFoundError: If the input file doesn't exist
        ValueError: If the input file content is not valid
    """
    
    blocks = open(file).read().split('[0]:')[1:]
    if len(blocks) == 0:
        raise ValueError("The benchmark output file does not have the correct format.")
    
    try:
        header = blocks[0].split("\n")[0]
        data = [header] + [b.split("\n")[1].strip() for b in blocks]
        df = pd.read_csv(io.StringIO("\n".join(data)))
    except (pd.errors.EmptyDataError, IndexError) as e:
        raise ValueError("The benchmark output file may be corrupted.")
    
    if output_file:
        logger.info(f"Benchmark CSV written to {output_file}")
        df.to_csv(output_file)
    
    return df


def summarise_latency(log_file: str, bench_file: str = None, output_file: str = None) -> pd.DataFrame:
    """
    Parses hipBLASLt benchmark output and matches it against the bench yaml file to gather overall workload statistics.
    
    Args:
        log_file (str):    Path to the hipBLASLt benchmark output file
        bench_file (str):  Path to the yaml benchmark file
        output_path (str): Path were to write the output file
        
    Returns:
        pandas.DataFrame: DataFrame containing parsed benchmark results
        
    Raises:
        FileNotFoundError: If the some/all of the files do not exist
        ValueError: If the benchmark log file content is not valid
    """
    df = parse_latency(log_file)
    
    if not "us" in df.columns:
       raise ValueError("Latency information missing from the log file")
    
    if bench_file:
        bench_data = read_yaml(bench_file)
        if len(bench_data) != len(df):
            raise ValueError("Benchmark log and yaml file do not match.")
        
        df["call_count"] = [max(1, el.get("call_count", 1)) for el in bench_data]
    else:
        df["call_count"] = 1
        
    df["total (us)"] = df["call_count"] * df["us"]
    df["% of total"] = 100 * df["total (us)"] / df["total (us)"].sum()
    
    df = df.sort_values("% of total", ascending=False)
    df["accum"] = 100 * df["total (us)"].cumsum() / df["total (us)"].sum()

    if output_file:
        logger.info(f"Benchmark summary CSV written to {output_file}")
        df.to_csv(output_file)
        
    return df

def generate_report(ref: str, tuned: str, output_path: str = None):
    """
    Compare reference and tuned hipBLASLt benchmark results and generate a performance report.
    
    Args:
        ref (str): Path to reference benchmark output file
        tuned (str): Path to tuned benchmark output file
        output_path (str, optional): Path to save the output CSV report. Defaults to "perf_report.csv"
        
    Raises:
        ValueError: If either reference or tuned file paths are invalid
        
    The function:
    1. Loads and parses both benchmark files
    2. Merges the results on non-performance columns
    3. Calculates performance uplift percentage
    4. Saves the comparison report as CSV
    """
    if not os.path.isfile(ref):
        raise ValueError(f"{ref} not found")
    
    if not os.path.isfile(tuned):
        raise ValueError(f"{tuned} not found")
    
    df_ref = parse_latency(ref)    
    df_tuned = parse_latency(tuned)
    
    merge_cols = [c for c in df_ref.columns if c not in PERF_COLS]
    df = pd.merge(df_ref,
                  df_tuned, 
                  on=merge_cols, 
                  suffixes=(" (ref)", " (tuned)"))
    
    df["UPLIFT (%)"] = round(100 * (df_ref["us"] - df_tuned["us"]) / df_ref["us"], 3)
    
    if output_path:
        df.to_csv(output_path, index=False)
    
    return df
    
    