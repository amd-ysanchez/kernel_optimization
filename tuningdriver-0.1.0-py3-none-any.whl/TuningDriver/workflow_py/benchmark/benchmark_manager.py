import sys
import os
# sys.path.append(os.path.dirname(__file__))
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

from benchmark.parser import uniq, aggregate_logs, commands_to_yaml, read_yaml, parse_grid_points
from benchmark.perf import parse_latency, summarise_latency, generate_report
from benchmark.utils import update_yaml_parameters, set_iterations, set_winners

import yaml
import argparse
import subprocess
import pandas as pd
import numpy as np
import re
import stat
import shutil
import glob

import logging       
logger = logging.getLogger(f"benchmark:{os.path.basename(__file__).split('.')[0]}")

HIPBLASLT_BENCH_PATH = "build/release/clients/hipblaslt-bench"


def prepare_search(call_log_file: str, 
                   hipblaslt_bench: str, 
                   output_dir: str,
                   ratio: float = 0.2,
                   n_devices: int = 4,
                   device_st: int = 0,
                   report_file: str = None, 
                   cutoff: float = 0):
    """
    Creates the heuristic search bench calls from hipBLASLt call logs (log level 32) .
    
    Args:
        call_log_file (str):   Path to the hipBLASLt call log. Output from HIPBLASLT_LOG_MASK=32
        hipblaslt_bench (str): Path to the hipblaslt-bench command
        output_dir (str):      Path to the directory where the output script will be written
        ratio (float):         Fraction of the 'proper' number of iterations for the heuristic search.
        n_devices (int):       Number of devices, i.e. splits for the final heuristic search script(s).
        device_st (int):       ID of the first device to split the final script into.
        report_file (str):     Benchmark summary CSV file
        cutoff (float):        keep GEMMS with a percentage of workload contribution higher than this number. Default is 0, which will keep all.
        
    Raises:
        FileNotFoundError: If the log file doesn't exist.
        ValueError:        If the call log file is not valid.
    """
    
    if ratio <= 0:
        raise ValueError(f"ratio must be a flot larger than 0.")
    
    keep = None
    if report_file:
        df = pd.read_csv(report_file, index_col=0)
        fdf = df[df["% of total"] >= cutoff]
        logger.info(f"Kept {len(fdf)}/{len(df)} gemms after filtering by contribution.")
        if cutoff:
            fname, ext = os.path.splitext(report_file)
            fname += "_top" + ext
            fdf.to_csv(fname)
        keep = [i for i in fdf.index]
    
    results_dir = os.path.join(output_dir, f"output")
    os.makedirs(results_dir, exist_ok=True)
    
    lines = []
    for i, line in enumerate(open(call_log_file).readlines()):
        if (keep and i not in keep) or 'hipblaslt-bench' not in line:
            continue
        line = line.rstrip()
        line = re.sub(r'hipblaslt-bench', hipblaslt_bench, line)
        line = re.sub(r'--aux_type\s[^ ]*', '', line) # TODO This gives an error if kept
        line = re.sub(r'--algo_method index', "--algo_method all", line)
        line = re.sub(r'--solution_index\s[0-9]+', "--requested_solution 250000 --skip_slow_solution_ratio 0.5", line)

        iters = int(re.findall(r'--iters [0-9]+', line)[0].split(" ")[1])
        new_iters = min(round(iters * ratio), iters)
        line = re.sub(r'--iters [0-9]+', f'--iters {new_iters}', line)
        line = re.sub(r'--cold_iters [0-9]+', f'--cold_iters {new_iters}', line)
        
        results_file = os.path.join(results_dir, f"gemm_{i}_hs.log")
        line += f" --print_kernel_info --device {device_st} 2>&1 | tee {results_file}\n"
        lines.append(line)
    
    if len(lines) == 0:
        raise ValueError(f"{call_log_file} format is not valid.")
    
    if n_devices < 1:
        logger.warning(f"n_devices was set to {n_devices}, changing to 1")
        n_devices = 1
    
    # Sort by contribution
    if keep:
        lines = [lines[i] for i in np.argsort(np.argsort(keep))]
    
    for d, group in enumerate([lines[i::n_devices] for i in range(n_devices)]):
        if len(group) == 0:
            continue
        for j in range(len(group)):
            group[j] = re.sub(r'--device [0-9]', f'--device {device_st + d}', group[j])
        
        output_file = os.path.join(output_dir, f"heuristic_search_device{device_st + d}.sh")
        open(output_file, "w").writelines(group)
        
        st = os.stat(output_file)
        os.chmod(output_file, st.st_mode | stat.S_IEXEC)
        
    logger.info(f"Bash scripts written to {output_dir}. Example usage: ./heuristic_search_device0.sh")
    


class BenchmarkManager:
    """
    A class to manage hipBLASLt benchmarking workflow including:
    - Benchmark configuration
    - Benchmark execution
    - Log parsing and analysis
    - Heuristic search preparation
    """
    def __init__(self, 
                 hipblaslt_path: str, 
                 log_file : str, 
                 workspace: str = "",
                 device: int = 0,
                 cache: bool = True):
        """
        Initialise the BenchmarkManager with required parameters.
        
        Args:
            hipblaslt_path (str): Path to hipBLASLt installation
            log_file (str): Input benchmark log file in YAML format
            workspace (str): Path to the working space directory 
            device (int): Device to run benchmarks on
        """
        self.log_file = os.path.abspath(log_file)
        self.device = device
        self.hipblaslt_bench = os.path.join(hipblaslt_path, HIPBLASLT_BENCH_PATH)
        self.workspace = os.path.abspath(workspace)
        self.cache = cache
        
        logging.basicConfig(level = logging.DEBUG, format = '%(name)s:%(levelname)s %(message)s')
        
        if not os.path.isfile(self.hipblaslt_bench):
            raise FileNotFoundError(f"hipblaslt-bench not found at {self.hipblaslt_bench}")
        
        logger.info(f"Creating workspace at {self.workspace}")
        os.makedirs(self.workspace, exist_ok=True)
        
        input_folder = os.path.join(self.workspace, "logs")
        os.makedirs(input_folder, exist_ok=True)
        
        if os.path.isdir(self.log_file):
            if self.log_file == input_folder:
                logger.warning(f"Input directory and working directory match, this can cause inconsistencies when re-running the application.")
            logger.warning(f"Log file provided is a directory, attempting to aggregate its contents.")
            self.log_file = aggregate_logs(self.log_file)
        
        if not os.path.isfile(self.log_file):
            raise FileNotFoundError(f"Log data not found in {self.log_file}")
        
        if not self.log_file.endswith(".yaml"):
            logger.warning(f"{self.log_file} does not seem to be a YAML file.")
        
        new_log_file = os.path.join(input_folder, os.path.basename(self.log_file))
        
        if self.cache and os.path.isfile(new_log_file):
            logger.info(f"Using cached log file {new_log_file}")
            self.log_file = new_log_file
            return
        
        if new_log_file != self.log_file:
            logger.info(f"Copying log file to {input_folder}")
            new_log_file = os.path.join(input_folder, os.path.basename(self.log_file))
            shutil.copyfile(self.log_file, new_log_file)
            self.log_file = new_log_file
        else:
            logger.warning(f"Input log file and working log file match, this can cause inconsistencies when re-running the application.")
            
        try:
            read_yaml(self.log_file)
        except TypeError:
            self.log_file = commands_to_yaml(self.log_file, in_place=False)
            
    
    def benchmark(self, 
                  yaml_file: str,
                  output_file: str, 
                  call_log_file: str = None, 
                  grid_points_file: str = None):
        """
        Runs hipblaslt-bench on the input yaml file and stores the to the given path.
        
        Args:
            yaml_file (str):        Path to the input yaml file
            output_file (str):      Path for the output benchmark log
            call_log_file (str):    Path for the calls log
            grid_points_file (str): Path for the grid points log
        
        Raises:
            FileNotFoundError: If the hipblaslt-bench command cannot be executed.
        
        """
        if call_log_file:
            os.environ['HIPBLASLT_LOG_MASK'] = '32'
            os.environ['HIPBLASLT_LOG_FILE'] = call_log_file
        grid_points_file = None
        if grid_points_file:
            os.environ['TENSILE_DB'] = '0x8012'

        logger.info(f"Running hipblaslt-bench for {yaml_file}. Console output will be written to {output_file}.")
        with open(output_file, "w") as f:
            subprocess.run([self.hipblaslt_bench, "--yaml", yaml_file, "--device", str(self.device)],
                            stdout=f, 
                            stderr=subprocess.STDOUT, 
                            check=True, 
                            text=True)
        if call_log_file:
            os.environ['HIPBLASLT_LOG_MASK'] = ''
            os.environ['HIPBLASLT_LOG_FILE'] = ''
            lines = [l for l in uniq(open(call_log_file))]
            open(call_log_file, "w").writelines(lines)
        
        if grid_points_file:
            os.environ['TENSILE_DB'] = ""
            parse_grid_points(output_file, grid_points_file)
            
    
    def configure(self, 
                  bench_log_file: str,
                  grid_points_file: str,
                  iters: int = 100, 
                  duration: float = 0.5):
        """
        This method does:
            - Updates the log file with the appropriate parameters for benchmarking.
            - Does an initial benchmark to capture the GEMM latencies.
            - Updates the log file with the correct iterations for benchmarking. 
        
        Args:
            bench_log_file (str): Path where to store the latency log.
            iters (int):          If set, it will set the hot/cold iterations to this number.
            duration (float):     Duration that each GEMM should have. Used to adjust the iterations.
        
        """
        if self.cache and os.path.isfile(bench_log_file):
            logger.warning("Using cached configuration step. "
                           "If this step was not properly completed re-run this script with --no_cache.")
            return
        
        update_yaml_parameters(self.log_file, iters=iters)        
        
        logger.info(f"Initial benchmarking with iterations set to {iters}.")
        self.benchmark(self.log_file, bench_log_file, grid_points_file=grid_points_file)
        
        latency = parse_latency(bench_log_file)["us"]
        
        set_iterations(self.log_file, latency, duration)        
    
    def analyse(self, 
                output_file: str,
                summary_file: str, 
                call_log_file: str = None):
        """
        This method does:
            - Benchmarks the log (YAML) file and stores the latency log.
            - Generates a summary latency report for the generated latency log.
        
        Args:
            output_file (str):   Path where to store the latency log.
            summary_file (str):  Path where to store the summary CSV file.
            call_log_file (str): If set, it will store the unique calls for each GEMM.
        
        """
        self.benchmark(self.log_file, output_file, call_log_file=call_log_file)
        summarise_latency(output_file, self.log_file, summary_file)

    
    def workflow(self, 
                 duration: float = 0.5, 
                 ratio: float = 0.2,
                 n_devices: int = 4,
                 device_st: int = 0,
                 keep: float = 0,
                 run_search: bool = False,
                 wait: bool = False,
                 **kwargs):

        """
        This method executes the entire workflow from going from the log file from a ticket, 
        to optionally running the generated scripts for heuristic search.
        
        Parameters
        ----------
        duration : float, default=0.5
            Duration in seconds for each benchmark iteration.
        max_iters : int, default=1000
            Maximum number of iterations for heuristic search.
        n_devices : int, default=4
            Number of GPU devices to use for heuristic search.
        device_st : int, default=0
            Starting device ID.
        keep : float, default=0
            Cutoff threshold for keeping solutions. Solutions with performance
            below this threshold will be discarded.
        run_search : bool, default=False
            Whether to run the heuristic search scripts after generating the scripts.
        wait : bool, default=False
            If True and run_search is True, wait for all search processes to complete.
            Otherwise, return immediately after launching processes.
        Notes
        -----
        The workflow consists of:
        1. Configuring and running initial benchmarks
        2. Analyzing benchmark results
        3. Preparing heuristic search scripts
        4. Optionally running search scripts
        If caching is enabled and relevant files exist, steps will be skipped to
        use cached results instead.
        """
        bench_dir = os.path.join(self.workspace, "bench")
        os.makedirs(bench_dir, exist_ok=True)
        
        self.configure(os.path.join(bench_dir, "init_benchmark.log"),
                       os.path.join(bench_dir, "grid_points.csv"),
                       iters=100, 
                       duration=duration)
        
        bench_log_file = os.path.join(bench_dir, "benchmark.log")
        call_log_file = os.path.join(bench_dir, "bench_calls.log")
        summary = os.path.join(bench_dir, "gemms.csv")
        
        if self.cache and os.path.isfile(summary):
            logger.info("Using cached benchmark data.")
        else:
            self.analyse(bench_log_file, summary, call_log_file=call_log_file)     

        hs_dir = os.path.join(self.workspace, "hs")
        os.makedirs(hs_dir, exist_ok=True)
        
        logger.info("Preparing heuristic search scripts.")
        prepare_search(call_log_file, 
                        self.hipblaslt_bench, 
                        hs_dir, 
                        ratio=ratio, 
                        n_devices=n_devices, 
                        device_st=device_st,
                        report_file=summary,
                        cutoff=keep)
        
        if run_search:        
            commands = glob.glob(f"{hs_dir}/*.sh")
            logger.info(f"Running {len(commands)} scripts. Results will be written in {os.path.join(hs_dir, 'output')}")
            logger.info(f"PIDs are:")
            ps = []
            for cmd in commands:
                ps.append(subprocess.Popen(["sh", cmd]))
                logger.info(f"{ps[-1].pid}")            
            
            if wait:
                logger.info(f"Waiting for all processes to finish. This may take a while...")
                for p in ps:
                    p.wait()
        
        logger.info(f"Done!")
    
    def postprocess(self, uplift_thr: float = 4.0, **kwargs):
        """
        This method executes analyses the results from the heuristic search.
        It will benchmark the reference and winner kernels and produce
        performance reports.
        
        Parameters
        ----------
        uplift_thr : float, default=4.0
            Minimum uplift % to be considered as 'improved'.
        Notes
        -----
        The workflow consists of:
        1. Benchmark the gemms with the reference kernels
        2. Benchmark the gemms with the tuned kernels
        3. Generate a filtered (by uplift) performance report
        4. Copies the latency logs of the gemms with uplift for later use
        5. Prints the uplift summary
        If caching is enabled and relevant files exist, steps will be skipped to
        use cached results instead.
        """
        hs_dir = os.path.join(self.workspace, "hs")
        out_dir = os.path.join(hs_dir, 'output')
        scripts = glob.glob(f"{hs_dir}/*.sh")
        if not all(os.path.isdir(d) for d in [hs_dir, out_dir]) or len(scripts) == 0:
            raise ValueError("Nothing to process. Please run the workflow first.")

        total = sum(len(open(f).readlines()) for f in scripts)
        if total != len(glob.glob(f"{out_dir}/*.log")):
            raise ValueError("Number of found ouputs do not match the script(s) content.")
        
        bench_dir = os.path.join(hs_dir, "bench")
        os.makedirs(bench_dir, exist_ok=True)
        
        set_winners(self.log_file, out_dir, bench_dir)
        
        ref_file = os.path.join(bench_dir, "reference-out.log")
        if self.cache and os.path.isfile(ref_file):
            logger.info("Using cached reference benchmark data.")
        else:
            logger.info("Benchmarking reference kernels.")
            self.benchmark(os.path.join(bench_dir, "bench.yaml"), ref_file)
        
        tuned_file = os.path.join(bench_dir, "tuned-out.log")
        if self.cache and os.path.isfile(tuned_file):
            logger.info("Using cached tuned benchmark data.")
        else:
            logger.info("Benchmarking tuned kernels.")
            self.benchmark(os.path.join(bench_dir, "bench_indices.yaml"), tuned_file)

        df = generate_report(ref_file, tuned_file, os.path.join(bench_dir, "raw_perf_report.csv"))        
        df.index = [int(f.split("_")[-2]) for f in sorted(glob.glob(f"{out_dir}/*"), 
                                                          key=lambda x: int(x.split("_")[-2]))]
        df = df.loc[df["UPLIFT (%)"] >= uplift_thr]
        
        perf_file = os.path.join(bench_dir, "perf_report.csv")
        df.to_csv(perf_file)
        logger.info(f"Generated performance report in {perf_file}")
        
        uplift_dir = os.path.join(hs_dir, "uplift")
        os.makedirs(uplift_dir, exist_ok=True)
        for idx in df.index:
            shutil.copy(os.path.join(out_dir, f"gemm_{idx}_hs.log"), uplift_dir)
        logger.info(f"Copied logs with uplift to {uplift_dir}")
        
        ref_df = pd.read_csv(os.path.join(self.workspace, "bench", "gemms.csv"), index_col=0)
        avg_uplift = df["UPLIFT (%)"].mean()
        e2e_uplift = 100 * (ref_df.loc[df.index, "% of total"] / 100 * df["UPLIFT (%)"] / 100).sum()
        
        logger.info(f"GEMMS with uplift = {len(df)}/{len(ref_df)}")
        logger.info(f"Average uplift (%) = {avg_uplift:.4f}")
        logger.info(f"End to end uplift (%) = {e2e_uplift:.4f}")
                
        

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=f"This does a bunch of stuff." 
                                                 f"Gets the yaml GEMM calls to do an initial benchmarking, "
                                                 f"then a proper one with the appropriate settings."
                                                 f"Then a CSV file with the benchmark data is generated, and finally it generates "
                                                 f"the bash cripts to run the heuristic search on those GEMMs.")
    parser.add_argument('hipblaslt', help='Path to hipBLASLt', type=str)
    parser.add_argument('log_file', help='Log yaml file', type=str)
    parser.add_argument('action', help='Which stage to run.', type=str, choices=["workflow", "postprocess"])
    parser.add_argument('--workspace', help='Path to the working space, all files will be saved here. Default is current dir.', type=str, default="")
    parser.add_argument('--device', help='Device to run the initial benchmarks on.', type=int, default=0)
    parser.add_argument('--duration', help='Total benchmark duration in seconds for each GEMM. Default is 0.5.', type=float, default=0.5)
    parser.add_argument('--ratio', help='Fraction of the "proper" number of iterations to run for each GEMM during heuristic search. Default is 0.2', type=float, default=0.2)
    parser.add_argument('--n_devices', help='Number of devices, i.e. splits for the final heuristic search script(s).', type=int, default=4)
    parser.add_argument('--device_st', help='ID of the first device to split the final script into.', type=int, default=0)
    parser.add_argument('--keep', help='Keep GEMMS with a percentage of workload contribution higher than this number. Default is 0, which will keep all GEMMs.', type=float, default=0)
    parser.add_argument('--run', help='If set, will launch the generated heuristic search scripts', action='store_true')
    parser.add_argument('--wait', help='If set, will wait til all heuristic search scripts finish.', action='store_true')
    parser.add_argument('--no_cache', help='If set, will re-do all steps and ignore any existing data that may exist.', action='store_true')
    
    args = parser.parse_args()    
    
    bm = BenchmarkManager(args.hipblaslt, 
                          args.log_file, 
                          workspace=args.workspace, 
                          device=args.device,
                          cache=not args.no_cache)
    
    # getattr(bm, args.action)(**vars(args)) # Could be used like this
    if args.action == "workflow":
        bm.workflow(duration=args.duration,
                    ratio=args.ratio,
                    n_devices=args.n_devices,
                    device_st=args.device_st,
                    keep=args.keep,
                    run_search=args.run,
                    wait=args.wait)
    elif args.action == "postprocess":
        bm.postprocess()
    else:
        raise ValueError(f"Unrecognised action '{args.action}'")
       