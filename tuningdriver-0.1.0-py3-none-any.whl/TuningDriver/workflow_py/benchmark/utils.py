from typing import Sequence
from benchmark.parser import read_yaml, write_yaml

import yaml
import os
import glob

import logging
logger = logging.getLogger(f"benchmark:{os.path.basename(__file__).split('.')[0]}")


def set_iterations(log_file: str, 
                   latency: Sequence[float], 
                   duration: float = 0.5, 
                   output_file: str = None):
    """
    Reads a configurartion benchmark file, and updates the iterations for each GEMM based on the latency input. 
    
    Args:
        log_file (str):            Path to the hipBLASLt log (configuration) YAML file
        latency (Sequence[float]): Latency for each item in the log_file
        duration (float):          Duration that each GEMM should have. Used to adjust the iterations.
        output_file (str):         If set, it will write the updated log file to this path.
        
    Raises:
        FileNotFoundError: If the log file doesn't exist
        ValueError: If the input file content is not valid
    """
    data = read_yaml(log_file)
    if len(data) != len(latency):
        raise ValueError("Log file and latency input sizes do not match.")
        
    for i in range(len(data)):
        iters = max(10, int(duration * 1000000 / float(latency[i])))
        data[i]["iters"] = iters
        data[i]["cold_iters"] = iters

    if not output_file:
        output_file = log_file

    write_yaml(data, output_file)
    logger.info(f"Updated iterations in {output_file}")


def update_yaml_parameters(log_file: str, iters: int = 100):
    """
     Modifies the given YAML benchmark file to set:
        - flush to true
        - rotating to 512
        - if set, cold_iters to 'iters'
        - if set, iters to 'iters'
    Args:
        log_file (str): Path to the hipBLASLt log (configuration) YAML file
        iters (int):    If set, it will set the hot/cold iterations to this number
        
    Raises:
        FileNotFoundError: If the log file doesn't exist
        ValueError: If the input file content is not valid
    """
    data = read_yaml(log_file)
    
    for entry in data:
        entry['flush'] = True
        entry['rotating'] = 512
        if iters:
            entry['cold_iters'] = iters
            entry['iters'] = iters
        entry['initialization'] = 'trig_float'
        if "aux_type" in entry:
            del entry["aux_type"]
    
    write_yaml(data, log_file)
    logger.info(f"Updated YAML parameters for benchmarking in {log_file}")


def set_winners(log_file: str, heuristic_search_dir: str, output_dir: str, iters_multiplier: int = 5):
    """
     Updates the log file with the heuristic search winners indices
    Args:
        log_file (str):             Path to the hipBLASLt log (configuration) YAML file
        heuristic_search_dir (str): Path to the directory containing the heuristic search results
        ouput_dir (str):            Path to the directory where the log files will be saved
        
    Raises:
        FileNotFoundError: If the log file doesn't exist
        ValueError: If the input file content is not valid or if the log dir is empty
        IndexError: If the log file and log dir lengths do not match
    """
    data = read_yaml(log_file)
    
    winners = []
    filtered = []
    for f in sorted(glob.glob(f"{heuristic_search_dir}/*"), key=lambda x: int(x.split("_")[-2])):
        winner = int(open(f).read().split("Winner:")[1].split("--Solution index: ")[1].split("\n")[0])
        idx = int(f.split("_")[-2])
        entry = dict(data[idx])
        entry["algo_method"] = 2
        entry["solution_index"] = winner
        entry["cold_iters"] *= iters_multiplier
        entry["iters"] *= iters_multiplier
        data[idx]["cold_iters"] *= iters_multiplier
        data[idx]["iters"] *= iters_multiplier
        winners.append(entry)
        filtered.append(data[idx])
    
    if len(winners) == 0:
        raise ValueError(f"No data found in {heuristic_search_dir}")
    
    write_yaml(winners, os.path.join(output_dir, "bench_indices.yaml"))
    write_yaml(filtered, os.path.join(output_dir, "bench.yaml"))
    logger.info(f"Writing updated benchmark file with winner indices in {output_dir}")
    
    

def create_tuning_override(heuristic_search_dir: str, output_file: str):
    """
    WIP
    """
    files = [os.path.join(heuristic_search_dir, f) for f in os.listdir(heuristic_search_dir)]
    output = "Git Version: " + open(files[0]).read().split("hipBLASLt git version: ")[1].split("\n")[0] + "\n"
    for f in files:
        data = open(f).read().split("Winner: \n")[1].split("\n")[1:3]
        r = data[0] + f",{int(data[1].split(': ')[1])},gfx942:sramecc+:xnack-,304\n"
        output += r 
    open(output_file, "w").write(output)