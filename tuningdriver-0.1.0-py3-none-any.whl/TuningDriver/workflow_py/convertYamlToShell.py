# This script can be used to convert a YAML configuration file into an executable shell script for mblas-bench. 
# For example, use: python3 --input config.yaml --output config.sh --mblas-path /mblas-bench/build/mblas-bench --device 1 --driver cublaslt
# --------------------------------------------------------------

import yaml
import re
import os
import argparse

def parse_arguments():
    parser = argparse.ArgumentParser(description='Convert YAML to shell script ')
    parser.add_argument('--mblas_path', default='./mbals-bench', help='mblas-path ', required=True)
    parser.add_argument('--input', help='input file, path of YAML ', required=True)
    parser.add_argument('--output', help='output file, path shell script', required=True)
    parser.add_argument('--device', default=0,  help='device id', required=True)
    parser.add_argument('--driver', default='cublaslt', help='output file path (YAML or shell)', required=True)
    return parser.parse_args()

def convert_yaml_to_shell(input, output, mblas_path, driver, device):
    with open(input, 'r') as yaml_file:
        data = yaml.safe_load(yaml_file)

    with open(output, 'w') as shell_file:      
        for entry in data:
            comput_type = entry['compute_type'].removeprefix("c_")
            cmd = (
                f"{mblas_path}  "
                f"--function matmul -m {entry['M']} -n {entry['N']} -k {entry['K']} "
                f"--lda {entry['lda']} --ldb {entry['ldb']} --ldc {entry['ldc']} --ldd {entry['ldd']} "
                f"--alpha {entry['alpha']} --beta {entry['beta']} --transposeA {entry['transA']} --transposeB {entry['transB']} "
                f"--batch_count {entry['batch_count']} --scaleA {entry['scaleA']} --scaleB {entry['scaleB']} "
                f"--a_type {entry['a_type']} --b_type {entry['b_type']} --c_type {entry['c_type']} --d_type {entry['d_type']} "
                f"--compute_type {comput_type} "
                f"--initialization {entry['initialization']} --iters {entry['iters']} --cold_iters {entry['cold_iters']} --rotating {entry['rotating']} --device {device} --driver {driver} \n"
            )
            shell_file.write(cmd)


if __name__ == "__main__":
    args = parse_arguments()
    input_extension = os.path.splitext(args.input)[1].lower()
    if input_extension == '.yaml':
        convert_yaml_to_shell(args.input, args.output, args.mblas_path, args.driver, args.device)
    else:
        raise ValueError("Unsupported input file format. Please provide a .yaml file.")
