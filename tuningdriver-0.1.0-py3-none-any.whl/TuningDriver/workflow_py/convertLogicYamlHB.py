# -*- coding: utf-8 -*-

#  convertLogicYamlHB.py
#
#  This is to convert UserArg logic yaml from input_file_name inType to outType
#
#  how to use
#   1 execute python program as follows
#     example (python3): python3 convertLogicYamlToBIAS.py input_file_name outType
#
#   example1) HHS to BBS
#     before file name: aquavanjaram_Cijk_Alik_Bljk_HHS_BH_Bias_AS_SAV_UserArgs.yaml
#     after  file name: aquavanjaram_Cijk_Alik_Bljk_BBS_BH_Bias_AS_SAV_UserArgs.yaml
#   example2) HHS to HSS
#     before file name: aquavanjaram_Cijk_Alik_Bljk_HHS_BH_Bias_AS_SAV_UserArgs.yaml
#     after  file name: aquavanjaram_Cijk_Alik_Bljk_HSS_BH_Bias_AS_SAV_UserArgs.yaml
#
#  replace the following strings
replaceListHHS = {\
" BiasDataTypeList": '[0, 4]', \
" DataType": "4",\
" DataTypeA": "4",\
" DataTypeB": "4",\
" DataTypeE": "4",\
" DestDataType": "4",\
" MFMA_BF16_1K": "false", \
" KernelNameMin": '_HHS_', \
" SolutionNameMin": '_HHS_' \
}

replaceListBBS = {\
" BiasDataTypeList": '[0, 7]', \
" DataType": "7",\
" DataTypeA": "7",\
" DataTypeB": "7",\
" DataTypeE": "7",\
" DestDataType": "7",\
" MFMA_BF16_1K": "true", \
" KernelNameMin": '_BBS_', \
" SolutionNameMin": '_BBS_' \
}

replaceListHSS = {\
" BiasDataTypeList": '[0, 4]', \
" DataType": "4",\
" DataTypeA": "4",\
" DataTypeB": "4",\
" DataTypeE": "4",\
" DestDataType": "0",\
" MFMA_BF16_1K": "false", \
" KernelNameMin": '_HSS_', \
" SolutionNameMin": '_HSS_' \
}

replaceListBSS = {\
" BiasDataTypeList": '[0, 7]', \
" DataType": "7",\
" DataTypeA": "7",\
" DataTypeB": "7",\
" DataTypeE": "7",\
" DestDataType": "0",\
" MFMA_BF16_1K": "true", \
" KernelNameMin": '_BSS_', \
" SolutionNameMin": '_BSS_' \
}


replaceList = {\
"HHS": replaceListHHS, \
"BBS": replaceListBBS, \
"HSS": replaceListHSS, \
"BSS": replaceListBSS \
}

replaceKeyList = list(replaceListHHS.keys())
typeList = list(replaceList.keys())

import sys
import re
import os
import shutil
import datetime

def replace_line(line, inType, outType):
   for k in replaceKeyList:
       label = k + ":"
       if label in line:
         before = replaceList[inType][k]
         after = replaceList[outType][k]
         line = line.replace(before, after)
   return line

# main process starts from here
argvs = sys.argv
argc = len(argvs)

# parameter check
if (argc < 2):
    print ('Usage: # python %s input_file_name outType' % argvs[0])
    sys.exit(1)

inFile = argvs[1]

# file name check
if (".yaml" not in inFile):
    print ('ERROR: not .yaml')
    sys.exit(1)

# check if inType is in typeList
inType = ""
for t in typeList:
   if t in inFile:
     inType = t
     break

if inType == "":
    print (f'ERROR: unsupported type (supported types = {typeList}')
    sys.exit(1)

outType = argvs[2].upper()

if outType not in typeList:
    print (f'ERROR: unsupported outType (supported types = {typeList}')
    sys.exit(1)

if outType == inType:
    print (f'ERROR: outType is same as inType')
    sys.exit(1)

outFile = inFile.replace(inType, outType)

# open in file
try:
    fin = open(inFile, 'r')
except:
    print ('Usage: %s is not found.' % inFile)
    quit()

lines = fin.readlines()
fin.close()

print(f'output file: {outFile}')
with open(outFile, 'w') as fw:
   for line in lines:
       new_line = replace_line(line, inType, outType)
       fw.write(new_line)

