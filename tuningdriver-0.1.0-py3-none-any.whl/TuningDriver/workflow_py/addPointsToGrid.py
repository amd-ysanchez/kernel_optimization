########################################################################################################################
#
# Copyright (C) 2025 Advanced Micro Devices, Inc. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
########################################################################################################################
#
# Description
# Adds individual points to a grid-tuned library without breaking the grid structure

# Idea
# To explain the idea, we need to know how the solution selection works. It essentially sorts tuples [M,N,K] based on
# M -> N -> K. Then, it performs 3 linear searches; 1) To find higher M = higher_m. 2) To find higher N = higher_n
# across all tuples [higher_m, ., .]. 3) To find closest K = closest_k across all tuples [higher_m, higher_n, .].
# We ultimately can view this process as a tree-based search. It should be emphasized that the solution selection does
# NOT perform a tree (Kd-tree) search, but we want to view it as a tree search to come up with a simple idea to generate
# new points in the grid without any regression to current points in the grid. However, I suspect it would have been way
# faster if it was a tree search. Back to the main issue, the tree would have four levels where the first level
# corresponds to M values, the second level corresponds to N values and the third level is for K values. Finally, the
# last level is the solution index. So, the tree would look like:
#
#     m1         m2
#   n1 n2        n1
# k1 k2 k3      k1 k2
# s1 s2 s3      s4 s5
#
# If we want to add a point to the grid whose solution index should be the same as before, we need to find which tree
# path it would have been mapped to. So by looking at the tree, it is trivial that every M value bigger than m1 and less
# than m2 is mapped to the m2 branch. So if we want to add a new M value to the grid that is between m1 and m2, we need
# to copy the m2 branch and assign a new M value to the new branch:
#
#     m1        m3         m2
#   n1 n2       n1         n1
# k1 k2 k3     k1 k2      k1 k2
# s1 s2 s3     s4 s5      s4 s5
#
# Now, we should do the same thing for adding a new N value for a given M value. For instance, if we want to add an N
# value less than n1 to the new branch that we just created, we should have
#
#     m1          m3            m2
#   n1 n2      n3    n1         n1
# k1 k2 k3    k1 k2 k1 k2      k1 k2
# s1 s2 s3    s4 s5 s4 s5      s4 s5
#
# we then continue till we have the point we wanted to add to the grid.

# Test
# To test the new created liblogic, we basically need to pick some points from the domain (not necessarily from th grid)
# and compare the solution indices that the original and new liblogics return. If the match, then the added points will
# not hurt/improve the performance (apart from the overhead for the solution selection as it has go through more
# points). One pressure test can be done by checking all neighbors for all grid points. For instance, let's say we only
# have one point [16, 32, 64] in the grid. Then, the neighbors are 27 points from the permutation [15:17, 31:33, 63:65].
# All these points should return the same solution index with the original and new liblogic.
# This script can create a config yaml to test all 27 neighbors of all grid points. See below to see how you can
# generate such config yaml. Then, build hipblaslt with both original and new liblogics. Run the bench in both old and
# new hipblaslt builds with the config yaml file, and compare the solution indices.
# Next step is essentially tuning (individually) for the point(s) you added to the grid and updating their solution
# indices.




########################################################################################################################
# Usage:
# 1. Add the points to the main, then:
# $ python3 addPointsToGrid.py -i pathtoliblogic

# 2. To specify the output file you can use -o flag:
# $ python3 addPointsToGrid.py -i pathtoliblogic -o pathtoNEWliblogic

# 3. If you want to also create a config yaml to test the points, run with -t flag.
# This will create a config yaml consisting of all grid points plus all 26 neighbors of each grid point.
# The config yaml includes some basic config flags such as iter, but orientation and dataypes should be added/modified.
# $ python3 addPointsToGrid.py -i pathtoliblogic -t

# 4. As testing for all neighbors of all grid points is exhausting, run with -r mMin mMax nMin nMax kMin kMax flag.
# This will create a config yaml consisting of all grid points where their m is between mMin and mMax, their n is between
# nMin and nMax, and their k is between kMin and kMax. And also all 26 neighbors of them.
# The config yaml includes some basic config flags such as iter, but orientation and dataypes should be added/modified.
# $ python3 addPointsToGrid.py -i pathtoliblogic -t -r 10 200 20 100 1000 2000

# 5. If you want to see some minor information about the grid, run with -v flag.
# $ python3 addPointsToGrid.py -i pathtoliblogic -v

# 6. If you want to use a yaml file instead of manually editing points_to_be_added, run with the -l flag.
# $ python3 addPointsToGrid.py -i pathtoliblogic -l pathtopointstobeaddedlogic -o pathtoNEWliblogic

# TODO: Read the points from the parser




########################################################################################################################
import sys
import argparse
import copy
from sortedcontainers import SortedList
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm import tqdm
import yaml




# ARG PARSER ###########################################################################################################
def parseArgs():
    argParser = argparse.ArgumentParser()

    argParser.add_argument("-i", "--libLogic",
                           help="The original library logic file path")
    # argParser.add_argument( "-p", "--points", help = "Points to be added to the liblogic" )
    argParser.add_argument("-o", "--output_libLogic", nargs='?', default="modified_libLogic.yaml",
                           help="The output library logic file path")
    argParser.add_argument("-t", "--test", action="store_true",
                           help="Generates a config yaml file to test for all 27 neighbors of grid points")
    argParser.add_argument("-r", "--range", nargs="+", type = int,
                           help="Specifies a range mMin, mMax, nMin, nMax, kMin, kMax for creating the test config. " +
                                "It requires -t and accepts 2, 4, or 6 inputs" )
    argParser.add_argument("-v", "--verbose", action="store_true",
                           help="Outputs information about the grid")
    
    argParser.add_argument("-l", "--use-library-for-sizes", default=None,
                           help="Get sizes from the solution mapping of the library")

    argParser.add_argument("-ic", "--input_csv",
                           help="File path to the input csv file containing the points to be added")


    return argParser.parse_args()

# GRID CLASS ###########################################################################################################
class Grid:
    def __init__( self, library_logic_yaml_file ):
        self._library_logic_yaml_file = library_logic_yaml_file
        self._parse_library_logic_yaml_file()

    # Misc. Methods ####################################################################################################
    @staticmethod
    def _flatten_library( library ):
        for x in library[7]:
            yield tuple( [*x[0], *x[1]] )

    def _parse_library_logic_yaml_file( self ):
        print( "Reading the input lib logic yaml file..." )
        with open( self._library_logic_yaml_file ) as l:
            self._library = yaml.safe_load( l )
            df = pd.DataFrame( Grid._flatten_library( self._library ) )
            df.columns = ['M', 'N', 'B', 'K', 'SolutionIndex', 'Efficiency']
            convert_dict = { 'M': int, 'N': int, 'B': int, 'K': int, 'SolutionIndex': int, 'Efficiency': float }
            df = df.astype( convert_dict )
            self._org_library_df = df.copy( deep = True )  # keeping the original df
            # For now, we only keep those sizes with B = 1. B != 1 should be implemented later.
            #df = df[df['B'] == 1]
            self._library_df = df
            self._sort_df()
        print( "Reading the input lib logic yaml file completed!" )

    def _sort_df( self ):
        pd = self._library_df.sort_values( ['M', 'N', 'B', 'K'], ascending = [True, True, True, True] )
        self._library_df = pd

    def _analysis( self ):
        print( 'M values:', self.unique_Ms )
        print( 'No. unique M values:', len( self.unique_Ms ) )
        print( 'N values:', self.unique_Ns )
        print( 'No. unique N values:', len( self.unique_Ns ) )
        print( 'B values:', self.unique_Bs )
        print( 'No. unique B values:', len( self.unique_Bs ) )
        print( 'K values:', self.unique_Ks )
        print( 'No. unique K values:', len( self.unique_Ks ) )
        print( 'Total number of points in the grid:', self.number_of_grid_points )

    # Properties #######################################################################################################
    @property
    def number_of_grid_points( self ):
        return len( self._library_df )

    @property
    def unique_Ms( self ) -> set:
        return list( map( int, sorted( self._library_df['M'].unique() ) ) )

    @property
    def unique_Ns( self ) -> set:
        return list( map( int, sorted( self._library_df['N'].unique() ) ) )

    @property
    def unique_Bs( self ) -> set:
        return list( map( int, sorted( self._library_df['B'].unique() ) ) )

    @property
    def unique_Ks( self ) -> set:
        return list( map( int, sorted( self._library_df['K'].unique() ) ) )


    # Methods ##########################################################################################################
    # Gets all the rows with M = m
    def get_rows_with_M( self, m: int ):
        return copy.deepcopy( self._library_df[ self._library_df['M'] == m ] )

    # Gets all the rows with M = m, N = n
    def get_rows_with_MN( self, m: int, n: int ):
        df = self.get_rows_with_M( m )
        return copy.deepcopy( df[ df['N'] == n ] )

    # Gets all the rows with M = m, N = n, B = b
    def get_rows_with_MNB( self, m: int, n: int, b: int ):
        df = self.get_rows_with_MN( m, n )
        return copy.deepcopy( df[ df['B'] == b ] )

    # Gets all the rows with M = m, N = n, B = b, K = k
    def get_rows_with_MNBK( self, m: int, n: int, b: int, k: int ):
        df = self.get_rows_with_MNB( m, n, b )
        return copy.deepcopy( df[ df['K'] == k ] )


    # Gets unique Ms
    def get_unique_M( self ):
        return SortedList( self._library_df['M'].unique() )

    # Gets unique Ns in M = m
    def get_unique_Ns_in_M( self, m: int ):
        return SortedList( self.get_rows_with_M(m)['N'].unique() )

    # Gets unique Bs in M = m and N = n
    def get_unique_Bs_in_MN( self, m: int, n: int ):
        return SortedList( self.get_rows_with_MN( m, n )['B'].unique() )

    # Gets unique Ks in M = m, N = n, and B = b
    def get_unique_Ks_in_MNB( self, m: int, n: int, b: int ):
        return SortedList( self.get_rows_with_MNB( m, n, b )['K'].unique() )


    # Add points #######################################################################################################
    def add_point( self, m: int, n: int, b: int, k: int ):
        #if b != 1:
        #    raise NotImplementedError( "B not equal to one is not implemented yet!" )
        # Finds the higher value in a sorted list
        def find_higher_value( sorted_list, value ):
            # Find the insertion point where target would fit in sorted order
            idx = sorted_list.bisect_right( value )
            # If the index is within the list bounds, return the element at that index
            if idx < len( sorted_list ):
                return sorted_list[ idx ]
            # If there's no higher value (target is larger than all elements)
            else:
                return sorted_list[ -1 ]

        # Finds the closest value in a sorted list
        def find_closest_value( sorted_list, value ):
            # Find the insertion point where target would fit in sorted order
            idx = sorted_list.bisect_right( value )

            # Check the closest neighbor
            if idx == 0:
                return sorted_list[0]  # Closest is the first element
            if idx == len(sorted_list):
                return sorted_list[-1]  # Closest is the last element

            # Compare the neighbors to find the closest
            before = sorted_list[idx - 1]
            after = sorted_list[idx]

            # Return the closest of the two
            if abs( before - value ) <= abs( after - value ):
                return before
            else:
                return after

        # Check if the point already exists in the grid
        if ( ( self._library_df['M'] == m ) & 
             ( self._library_df['N'] == n ) &
             ( self._library_df['B'] == b ) & 
             ( self._library_df['K'] == k ) ).any():
            print( "[%s, %s, %s, %s]: Adding a point that is already in the grid! Skipping ..." %( m, n, b, k ) )
        else:
            # dataframe to be added to the grid
            df = pd.DataFrame()
            sortedList_M = self.get_unique_M()
            # Check if the M = m node exists
            if m in sortedList_M:
                # higher M is equal to m
                higher_m = m
            else:
                # find the higher m
                higher_m = find_higher_value( sortedList_M, m )
                # rows associated with higher_m
                df_N = self.get_rows_with_M( higher_m )
                # change the value of m
                df_N['M'] = m
                df = pd.concat( [ df, df_N ] )

            # N values corresponding to higher_m
            sortedList_N = self.get_unique_Ns_in_M( higher_m )
            # Check if the M = higher_m and N = n  node exists
            if n in sortedList_N:
                # higher_n is equal to n
                higher_n = n
            else:
                # find the higher n
                higher_n = find_higher_value( sortedList_N, n )
                # rows associated with higher_m and higher_n
                df_B = self.get_rows_with_MN( higher_m, higher_n )
                df_B['M'] = m
                df_B['N'] = n
                df = pd.concat( [ df, df_B ] )
            # B values corresponding to higher_m and higher_n
            sortedList_B = self.get_unique_Bs_in_MN( higher_m, higher_n )
            # Check if the M = higher_m, N = higher_n and B = b  node exists
            if b in sortedList_B:
                # higher_b is equal to b
                higher_b = b
            else:
                # find the higher b
                higher_b = find_higher_value( sortedList_B, b )
                # rows associated with higher_m, higher_n, and higher_b
                df_K = self.get_rows_with_MNB( higher_m, higher_n, higher_b )
                df_K['M'] = m
                df_K['N'] = n
                df_K['B'] = b
                df = pd.concat( [ df, df_K ] )

            # K values corresponding to the higher_m, higher_n, and higher_b
            sortedList_K = self.get_unique_Ks_in_MNB( higher_m, higher_n, higher_b )
            # Check if the M = higher_m, N = n_higher, B = higher_b, and K = k_closest node exists.
            # If it exists, then we have already added the point and nothing more is needed.
            # If not, we add the K value:
            if k not in sortedList_K:
                # find the closest k
                closest_k = find_closest_value( sortedList_K, k )
                # solution index of the grid point we already found
                s = self._library_df[ ( self._library_df['M'] == higher_m ) &
                                      ( self._library_df['N'] == higher_n ) &
                                      ( self._library_df['B'] == higher_b ) &
                                      ( self._library_df['K'] == closest_k ) ]['SolutionIndex'].values[0]
                df_S = {'M': m, 'N': n, 'B': b, 'K': k, 'SolutionIndex': s, 'Efficiency': [0]}
                df = pd.concat( [ df, pd.DataFrame( df_S ) ] )

            # Adding the points
            self._library_df = pd.concat( [self._library_df, df] )
            self._sort_df()




    # Output ###########################################################################################################
    # Outputs the yaml liblogic file. At this point, the added points have the same solution indices as before when
    # they were not added. That is, we should see NO performance drop other than the solution selection overhead.
    def outputLibLogic( self, outputDir ):
        print( 'Writing output lib logic yaml file...' )
        # We want to keep the added points at the end of the liblogic. So, lets get the diff with the original liblogic
        merged_df = pd.merge( self._org_library_df, self._library_df, how = 'outer', indicator = True )
        diff = merged_df[ merged_df['_merge'] == 'right_only' ]
        # Concat with the original to have new points added at the end
        df = pd.concat( [self._org_library_df, diff] )
        # update the loaded yaml
        self._library[7].clear()
        df.reset_index( inplace = True )
        for rowID, row in df.iterrows():
            ls = row.tolist()
            self._library[7].append( list( [ [ ls[1], ls[2], ls[3], ls[4] ], [ ls[5], ls[6] ] ] ) )

        with open(outputDir, 'w') as outfile:
            yaml.safe_dump(self._library, outfile, default_flow_style=None)
        print('Writing output lib logic yaml file completed!')




    # Outputs a test_config.yaml file for some randomly chosen points in the domain. The template dictionary should be
    # modified accordingly (datatype, orientaion, ...)
    def outputTestConfigYAML_random( self, templateDict, num_points ):
        import random
        import time

        # Generate random points in the grid
        random.seed(time.time())
        points = []
        m, n, b, k = 0, 0, 0, 0
        avg_m = np.median(self._library_df['M'].values, 0)
        avg_n = np.median(self._library_df['N'].values, 0)
        avg_b = np.median(self._library_df['B'].values, 0)
        avg_k = np.median(self._library_df['K'].values, 0)
        std_m = np.std(self._library_df['M'].values, 0) / 10
        std_n = np.std(self._library_df['N'].values, 0) / 10
        std_b = np.std(self._library_df['B'].values, 0) / 10
        std_k = np.std(self._library_df['K'].values, 0) / 10
        for _ in range( num_points ):
            while m <= 0:
                m = random.gauss(avg_m, std_m)  # Generate x from Gaussian distribution
            while n <= 0:
                n = random.gauss(avg_n, std_n)  # Generate y from Gaussian distribution
            while b <= 0:
                b = random.gauss(avg_b, std_b)  # Generate y from Gaussian distribution
            while k <= 0:
                k = random.gauss(avg_k, std_k)  # Generate z from Gaussian distribution
            points.append( ( int(m), int(n), int(b), int(k) ) )  # Ensure integers
            m, n, b, k = 0, 0, 0

        ls = []
        for point in points:
            templateDict['M'] = point[0]
            templateDict['N'] = point[1]
            templateDict['B'] = point[2]
            templateDict['K'] = point[3]
            ls.append( copy.deepcopy( templateDict ) )

        with open( 'test_config.yaml', 'w' ) as outfile:
            yaml.safe_dump( ls, outfile, default_flow_style = None )




    # This function outputs a test_config.yaml file which has all the points in the new grid + all 26 neighbours of each
    # point. The template dictionary should be modified accordingly (datatype, orientaion, ...). Also, it is not a good
    # idea to do this for all points of the grid, so we reduce the workload to a range of M and N. This range is
    # hardcoded.
    def outputTestConfigYAML_AllNeighbours( self, templateDict,
                                            mMin: int = 0, mMax: int = 0,
                                            nMin: int = 0, nMax: int = 0,
                                            bMin: int = 0, bMax: int = 0,
                                            kMin: int = 0, kMax: int = 0 ):
        # Pick a portion of the lib -- You can do all the points that would be 27 times the number of points!
        df = self._library_df.copy( deep = True )
        # Test all grid points
        if mMax == 0:
            df = df
        elif nMax == 0:
            df = df[ ( df['M'] >= mMin ) & ( df['M'] <= mMax ) ]
        elif bMax == 0:
            df = df[ ( df['M'] >= mMin ) & ( df['M'] <= mMax ) &
                     ( df['N'] >= nMin ) & ( df['N'] <= nMax ) ]
        elif kMax == 0:
            df = df[ ( df['M'] >= mMin ) & ( df['M'] <= mMax ) &
                     ( df['N'] >= nMin ) & ( df['N'] <= nMax ) &
                     ( df['B'] >= bMin ) & ( df['B'] <= bMax )]
        else:
            df = df[ ( df['M'] >= mMin ) & ( df['M'] <= mMax ) &
                     ( df['N'] >= nMin ) & ( df['N'] <= nMax ) &
                     ( df['B'] >= bMin ) & ( df['B'] <= bMax ) &
                     ( df['K'] >= kMin ) & ( df['K'] <= kMax ) ]

        # check all 27 points surronding each grid point
        points = []
        neighborList = [-1, 0, 1]
        neighborList = [ ( mm, nn, kk ) for mm in neighborList for nn in neighborList for kk in neighborList ]
        for _, row in df.iterrows():
            m, n, k = row['M'], row['N'], row['K']
            for neighbor in neighborList:
                mm, nn, kk = m + neighbor[0], n + neighbor[1], k + neighbor[2]
                if ( mm > 0 ) & ( nn > 0 ) & ( kk > 0 ):
                    points.append( ( int( mm ), int( nn ), int( kk ) ) )  # Ensure positive integers

        ls = []
        for point in points:
            templateDict['M'] = point[0]
            templateDict['N'] = point[1]
            templateDict['K'] = point[2]
            ls.append( copy.deepcopy( templateDict ) )

        with open( 'test_config.yaml', 'w' ) as outfile:
            yaml.safe_dump( ls, outfile, default_flow_style = None )




    # Plots the points of the original grid + the points that has been added to the grid
    def plot( self ):
        # Creating figure
        fig = plt.figure( figsize=( 10, 7 ) )
        ax = plt.axes( projection="3d" )

        # Creating plot
        ax.scatter3D( self._library_df['M'], self._library_df['N'], self._library_df['K'], color="green" )
        ax.set_xlabel( 'M' )
        ax.set_ylabel( 'N' )
        ax.set_zlabel( 'K' )

        # show plot
        plt.show()


libraries_name_to_yaml_content = dict()
def load_yaml_file(yaml_file: str):
    global libraries_name_to_yaml_content

    if yaml_file in libraries_name_to_yaml_content:
        return libraries_name_to_yaml_content[yaml_file]
    else:
        with open(yaml_file) as stream:
            libraries_name_to_yaml_content[yaml_file] = yaml.safe_load(stream)
            return libraries_name_to_yaml_content[yaml_file]
            
# Main #################################################################################################################
def main():
    args = parseArgs()
    inDir = args.libLogic
    # ptDir = args.points
    outDir = args.output_libLogic
    test = args.test
    range = args.range
    verbose = args.verbose
    sizes_from_library = args.use_library_for_sizes

    input_csv = args.input_csv
    points_to_be_added = []
    if input_csv:
        df = pd.read_csv(input_csv, usecols=['m', 'n', 'batch_count', 'k'])
        df = df[['m', 'n', 'batch_count', 'k']]
        points_to_be_added = df.values.tolist()
    else:
        if sizes_from_library:
            library_for_sizes = load_yaml_file(sizes_from_library)
            points_to_be_added = [s for s, _ in library_for_sizes[7]]
        else:
            points_to_be_added = [
                [ 3584, 72, 1, 18944 ], 
                [ 3584, 80, 1, 3584 ]
            ]
   
    grid = Grid( inDir )
    if verbose:
        grid._analysis()

    for p in tqdm( points_to_be_added ):
        grid.add_point( *p )
    print("Points have been added to the grid!")

    if verbose:
        grid._analysis()
    grid.outputLibLogic( outDir )
    if test:
        print( "Generating test config file..." )
        # This is only for testing -- If you want to generate a bench yaml, please update the dict
        templateDict = {'function': 'matmul',
                        'transA': 'N',
                        'transB': 'N',
                        'a_type': 'f16_r',
                        'b_type': 'f16_r',
                        'c_type': 'f16_r',
                        'd_type': 'f16_r',
                        'scale_type': 'f32_r',
                        'compute_type': 'c_f32_r',
                        'alpha': 1,
                        'beta': 0,
                        'iters': 1,
                        'cold_iters': 0,
                        'print_kernel_info': 1,
                        'M': 0,
                        'N': 0,
                        'K': 0}
        if range is None:
            grid.outputTestConfigYAML_AllNeighbours( templateDict )
        elif len(range) in [2, 4, 6]:
            grid.outputTestConfigYAML_AllNeighbours( templateDict, *range )
        else:
            print( "Invalid values for --range!" )
            print( "Couldn't generate test config file!" )
        print( "Generating test config file completed!" )




########################################################################################################################
if __name__ == '__main__':
    main()
