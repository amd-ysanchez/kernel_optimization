########################################################################################################################
#
# Copyright (C) 2025 Advanced Micro Devices, Inc. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
########################################################################################################################

import yaml
import shutil
import argparse
from pathlib import Path
import subprocess
import pandas as pd
import sys
import os
import io
import copy
import tqdm
sys.path.append(os.path.dirname(os.path.dirname(__file__)))

COLS = ['transA','transB','m','n','batch_count','k','a_type']


def find_origami_logic(tuned_logic_file, hipblaslt_path):
    base = os.path.basename(tuned_logic_file)
    pattern = "_".join(base.split("_")[:5])
    if pattern.split('_')[-1] == 'S':
        pattern += 'B'
    origami_path = os.path.join(hipblaslt_path, "library/src/amd_detail/rocblaslt/src/Tensile/Logic/asm_full/gfx950/Origami")
    matched = [os.path.join(origami_path, f) for f in os.listdir(origami_path) if f.startswith(pattern)]

    if len(matched) == 0:
        print("No Origami library found, creating new origami library")
        return None 

    if len(matched) > 1:
        raise ValueError(f'Multiple matching Origami logics found.')
    
    return matched[0]


def create_benchmark_files(logic_file, output_dir, duration=0.5):
    cmd = os.path.join(os.path.dirname(__file__), 'hipblaslt_benchInputCreator.py')

    subprocess.run(["python3", cmd, logic_file, output_dir, "--verify", "--duration", str(duration)], 
                   stdout=subprocess.DEVNULL, 
                   stderr=subprocess.STDOUT, 
                   check=True, 
                   text=True)


def benchmark(hipblaslt_path, bench_file, output_file, device=0):
      
    hipblaslt_bench = os.path.join(hipblaslt_path, 'build/release/clients/staging/hipblaslt-bench')
    
    print(f'Running hipblaslt-bench, output will be saved in {output_file}')
    with open(output_file, "w") as f:
        subprocess.run([hipblaslt_bench, "--yaml", bench_file, "--device", str(device)],
                        stdout=f, 
                        stderr=subprocess.STDOUT, 
                        check=True, 
                        text=True)
        

def build_library(hipblaslt_path, library_dir, output_dir):
    print("Calling TensileCreateLibrary...")
    cmd = os.path.join(hipblaslt_path, 'tensilelite/Tensile/bin/TensileCreateLibrary')
    subprocess.run([cmd, 
                    "--code-object-version",
                    "4", 
                    "--library-format",
                    "msgpack",
                    "--architecture",
                    "gfx950",
                    os.path.abspath(library_dir),
                    output_dir,
                    "HIP"],
                    stdout=subprocess.DEVNULL, 
                    stderr=subprocess.STDOUT, 
                    check=True, 
                    text=True)    


def parse_latency(file: str, output_file: str = None) -> pd.DataFrame:
    """
    Parse hipBLASLt benchmark output file into a pandas DataFrame.
    
    Args:
        file (str):        Path to the hipBLASLt benchmark output file
        output_file (str): Path to the generated latency report
        
    Returns:
        pandas.DataFrame: DataFrame containing parsed benchmark results
        
    Raises:
        FileNotFoundError: If the input file doesn't exist
        ValueError: If the input file content is not valid
    """
    
    blocks = open(file).read().split('[0]:')[1:]
    if len(blocks) == 0:
        raise ValueError("The benchmark output file does not have the correct format.")
    
    try:
        header = blocks[0].split("\n")[0]
        data = [header] + [b.split("\n")[1].strip() for b in blocks]
        df = pd.read_csv(io.StringIO("\n".join(data)))
        if '--Solution index:' in blocks[0]:
            df['SolutionIndex'] = [int(b.split("\n")[2].strip().split('--Solution index: ')[1]) for b in blocks]
    except (pd.errors.EmptyDataError, IndexError) as e:
        raise ValueError("The benchmark output file may be corrupted.")
    
    if output_file:
        df.to_csv(output_file)
    
    return df


def sort_kernels(tuned_logic_file, 
                 hipblaslt_path, 
                 work_dir, 
                 device=0, 
                 weights=None):
    tuned = yaml.safe_load(open(tuned_logic_file))
    
    grouped = {}
    for i, kernel in enumerate(tuned[5]):
        key = (kernel['MacroTile0'], kernel['MacroTile1'], kernel['DepthU'])
        if key not in grouped:
            grouped[key] = []
        kernel['SolutionIndex'] = i
        sizes = [sz for sz in tuned[7] if sz[1][0] == i]
        grouped[key].append((kernel, sizes))
    
    
    work_dir = os.path.join(work_dir, 'sort')
    os.makedirs(work_dir, exist_ok=True)
    sorted_kernels = {}
    tmp_lib = yaml.safe_load(open(tuned_logic_file))
    print(f'Sorting kernels...')
    for key, groups in tqdm.tqdm(grouped.items()):
        key_str = f'MT{key[0]}x{key[1]}x{key[2]}'
        if len(groups) == 1:
            sorted_kernels[key] = [groups[0][0]]
            continue
        
        gdir = os.path.join(work_dir, key_str)
        os.makedirs(gdir, exist_ok=True)
        
        kernels = [g[0] for g in groups]
        sizes = [sz for g in groups for sz in g[1]]
        
        tmp_kernels = []
        for i, k in enumerate(kernels):
            tmp_kernel = copy.deepcopy(k)
            tmp_kernel['SolutionIndex'] = i
            for sz in sizes:
                if sz[1][0] == k['SolutionIndex']:
                    sz[1][0] = i
            tmp_kernels.append(tmp_kernel)
        tmp_lib[5] = tmp_kernels
        tmp_lib[7] = sizes
        lib_dir = os.path.join(gdir, 'lib')
        os.makedirs(lib_dir, exist_ok=True)
        yaml.dump(tmp_lib, open(os.path.join(lib_dir, 'liblogic.yaml'), 'w'), default_flow_style=None, width=5000, default_style=None)
        
        bench_dir = os.path.join(gdir, 'bench')
        create_benchmark_files(lib_dir, bench_dir, 0.5)
        brf = yaml.safe_load(open([os.path.join(bench_dir, f) for f in os.listdir(bench_dir) if f.endswith('bench_rotating.yaml')][0]))
        shutil.rmtree(bench_dir)
        
        all_bench = []
        for i in range(len(kernels)):
            bdata = copy.deepcopy(brf)
            for b in bdata:
                b['print_kernel_info'] = True
                b['algo_method'] = 2
                b['solution_index'] = i
            all_bench.extend(bdata)
            
        yaml.dump(all_bench, 
                  open(os.path.join(gdir, 'bench.yaml'), 'w'), 
                  default_flow_style=None, 
                  width=5000, 
                  default_style=None,
                  sort_keys=False)
        
        if not os.path.isdir(os.path.join(gdir, "tensile", "library")):
            build_library(hipblaslt_path, lib_dir, os.path.join(gdir, "tensile"))
        
        latency_log = os.path.join(gdir, 'latency.log')
        if not os.path.isfile(latency_log):
            os.environ['HIPBLASLT_TENSILE_LIBPATH'] = os.path.join(gdir, "tensile", "library")
            benchmark(hipblaslt_path, os.path.join(gdir, 'bench.yaml'), latency_log, device=device)
            del os.environ['HIPBLASLT_TENSILE_LIBPATH'] 
        
        df = parse_latency(latency_log)        
       
        if weights is not None:
            matched = df.merge(weights, on=COLS)
            if len(df.merge(weights, on=COLS)) > 0:
                df['call_count'] = matched['call_count']
            else:
                print(f'Warning! Some sizes were not found in weights file.')
                df['call_count'] = 1
        else:
            df['call_count'] = 1
        df['total'] = df['call_count'] * df['us']
        
        sorted_sols = df.groupby('SolutionIndex')['total'].sum().values.argsort()
        sorted_kernels[key] = [kernels[ssi] for ssi in sorted_sols]
    
    return sorted_kernels
        

def inject_kernels(origami_logic_file, tuned_logic_file, kernel_groups, output_file, ignore_list=None):
    if origami_logic_file is None:
        print(f"Creating Origami lib from tuned kernels ...")
    
        origami = yaml.load(open(tuned_logic_file), yaml.SafeLoader)
        origami[-1] = "Prediction"
        origami[-5] = None
        origami[-6] = None
    else:
        print(f"Injecting tuned kernels in Origami lib: {origami_logic_file}...")
        
        origami = yaml.load(open(origami_logic_file), yaml.SafeLoader)
    
    origami_dict = {}
    for i, origami_kernel in enumerate(origami[5]):
        key = (origami_kernel['MacroTile0'], origami_kernel['MacroTile1'], origami_kernel['DepthU'])
        origami_dict[key] = i
    
    for key, kernels in kernel_groups.items():
        for kernel in kernels:
            if ignore_list and kernel['SolutionIndex'] in ignore_list:
                # print(f'Skipping kernel #{kernel["SolutionIndex"]}')
                continue
            
            #Warning: Latency not found for MI_M=32, MI_N=32, MI_K=16, Element_Size=16. Returning latency value of 32 (really slow).
            # if kernel["MatrixInstruction"][0] == 32 and \
            #    kernel["MatrixInstruction"][1] == 32 and \
            #    kernel["NumElementsPerBatchStore"] == 16:
            #     continue
            
            kernel = copy.deepcopy(kernel)
            
            kernel['isTuned'] = True
            if key in origami_dict:
                origami[5][origami_dict[key]] = kernel
            else:
                origami[5].append(kernel)
            
            break
            
    kernel_mapping = {}
    for i, kernel in enumerate(origami[5]):
        if kernel.get('isTuned', False):
            kernel_mapping[i] = kernel['SolutionIndex']
        kernel['SolutionIndex'] = i

    yaml.dump(origami, open(output_file, 'w'), default_flow_style=None, width=5000, default_style=None)
    return kernel_mapping


def main(tuned_logic_file, 
         hipblaslt_path, 
         device=0, 
         work_dir="", 
         weights=None):
    
    if not os.path.isfile(tuned_logic_file):
        raise ValueError(f"Logic file '{tuned_logic_file}' not found")
    
    if work_dir == "":
        work_dir = f'WORKDIR_{device}'
    
    print(f"Working on {work_dir}...")
    
    #Find origami lib
    origami_logic_file = find_origami_logic(tuned_logic_file, hipblaslt_path)
    
    tuned_dir = os.path.join(work_dir, 'tuned')
    os.makedirs(tuned_dir, exist_ok=True)
    shutil.copyfile(tuned_logic_file, os.path.join(tuned_dir, os.path.basename(tuned_logic_file)))
    
    benchmark_dir = os.path.join(work_dir, 'benchmarks')
    os.makedirs(benchmark_dir, exist_ok=True)
    
    create_benchmark_files(tuned_dir, benchmark_dir, duration=0.5)
    bench_rotating = [os.path.join(benchmark_dir, f) for f in os.listdir(benchmark_dir) if f.endswith('_bench_rotating.yaml')][0]
    
    content = open(bench_rotating).read().replace('}\n', ', print_kernel_info: True}\n')
    open(bench_rotating, 'w').write(content)
    
    reference_log = os.path.join(work_dir, 'reference-out.log')
    if not os.path.isfile(reference_log):
        benchmark(hipblaslt_path, bench_rotating, reference_log, device=device)
    rdf = parse_latency(reference_log)
    
    if weights is not None:
        wdf = pd.read_csv(weights)
        wdf.rename({'type': 'a_type'}, axis=1, inplace=True)
        matched = rdf.merge(wdf, on=COLS)
        if len(matched) == 0:
            print('Warning')
            rdf['call_count'] = 1
            rdf['weight'] = 1
        else:
            assert len(matched) == len(rdf)
            #TODO partial match
            rdf = matched
            rdf['total'] = rdf['us'] * rdf['call_count']
            rdf['weight'] = rdf['total'] / rdf['total'].sum()
    else:
        rdf['call_count'] = 1
        rdf['weight'] = 1
    
    
    sorted_kernels = sort_kernels(tuned_logic_file, hipblaslt_path, work_dir, device=device, weights=rdf[COLS + ['call_count']] if weights else None)

    rounds_dir = os.path.join(work_dir, 'rounds')
    os.makedirs(rounds_dir, exist_ok=True)
    
    kernels_to_remove = []
    it = 0
    best_round = -1
    best_uplift = 0
    while True:
        print()
        print(f'ROUND {it}...')
        
        inject_dir = os.path.join(rounds_dir, f'{it}_inject')
        os.makedirs(inject_dir, exist_ok=True)
        inject_logic_file = os.path.join(inject_dir, os.path.basename(tuned_logic_file))
        kernel_mapping = inject_kernels(origami_logic_file, tuned_logic_file, sorted_kernels, inject_logic_file, kernels_to_remove)

        build_library(hipblaslt_path, inject_dir, os.path.join(work_dir, "tensile"))
        
        os.environ['HIPBLASLT_TENSILE_LIBPATH'] = os.path.join(work_dir, "tensile", "library")
        tuned_log = os.path.join(work_dir, 'tuned-out.log')
        benchmark(hipblaslt_path, bench_rotating, tuned_log, device=device)
        del os.environ['HIPBLASLT_TENSILE_LIBPATH'] 
        
        tdf = parse_latency(tuned_log)
        tdf['uplift'] = 100 * ((rdf["us"] - tdf["us"]) / rdf["us"]) * rdf['weight']
        tdf['TunedSolutionIndex'] = [kernel_mapping.get(k, -1) for k in tdf['SolutionIndex'].values]
        tdf.to_csv(os.path.join(rounds_dir, f'{it}_latency.csv'), index=False)
        
        round_kernels_to_remove = []
        for k, v in kernel_mapping.items():
            if k not in tdf['SolutionIndex'].values:
                continue
            mask = tdf['SolutionIndex'] == k
            tdfk = tdf.loc[mask]
            rdfk = rdf.loc[mask]
            up = tdfk['uplift'].sum()
            if up <= 0:
                round_kernels_to_remove.append(v)
            
        round_uplift = tdf["uplift"].sum()
        if round_uplift > best_uplift:
            best_uplift = round_uplift
            best_round = it
            
        print(f'Uplift in round {it} ==> {round_uplift}')
        
        if len(round_kernels_to_remove) == 0:
            print("DONE!")
            break
        
        print(f'Removing {len(round_kernels_to_remove)} tuned kernel(s) from the library...')
        it += 1
        kernels_to_remove.extend(round_kernels_to_remove)

    if best_round < 0:
        print(f'No improvement found with the given tuned kernels')
        return

    tdf = pd.read_csv(os.path.join(rounds_dir, f'{best_round}_latency.csv'))
    kernels_to_add = tdf.loc[tdf['TunedSolutionIndex'] >= 0, 'TunedSolutionIndex'].unique()
    kernels_to_remove = [k['SolutionIndex'] for k in yaml.load(open(tuned_logic_file), yaml.SafeLoader)[5] if k['SolutionIndex'] not in kernels_to_add]
    
    print(f'Kernels added to the Origami library: {len(kernels_to_add)}/{len(kernels_to_add) + len(kernels_to_remove)}')
    
    inject_logic_file = os.path.join(rounds_dir, f'{best_round}_inject', os.path.basename(tuned_logic_file))
    
    os.makedirs(os.path.join(work_dir, 'final'), exist_ok=True)
    if origami_logic_file is None: origami_logic_file = tuned_logic_file
    final_logic_file = os.path.join(work_dir, 'final', os.path.basename(origami_logic_file))
    shutil.copyfile(inject_logic_file, final_logic_file)
    print(f'Final logic saved in {final_logic_file}')
    
    

if __name__ == '__main__':
    argParser = argparse.ArgumentParser()
    
    argParser.add_argument("logic_file",
                           help="The tuned kernel library that will replace MT0XMT1xDU in the origami file")
    argParser.add_argument("hipblaslt_path",
                           help="Path to hipBLASLt")
    argParser.add_argument("--device", "-d", default=0, type=int, help="GPU device where benchmarks will be ran")
    argParser.add_argument("--work_dir", default="", type=str, help="Working directory, default will be 'WORKDIR_DEVICE'")
    argParser.add_argument("--weights", "-w", default=None, type=str, help="Call counts file.")
    
    args = argParser.parse_args()
    
    main(args.logic_file, 
         args.hipblaslt_path, 
         device=args.device, 
         work_dir=args.work_dir, 
         weights=args.weights)
