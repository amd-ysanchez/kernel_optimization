
import yaml
import sys
import os
from copy import deepcopy
import pandas as pd
import copy
from collections import defaultdict

# adds missing MTxDU to Origami from GridBased library, and if GB and O share the same MTxDU, it replaces the first appearance of MTxDU in GB (ignores the rest), and add that to Origami. 

#TODO: clean the code

fgrid = "/home/bpoursar/workspace/tuning/PR_TF32_NT/liblogic_epilogue2/gfx950_Cijk_Ailk_Bjlk_S_MX_B_Bias_HAS_SAV_UserArgs.yaml"
forigami = "/home/bpoursar/workspace/rocm-libraries/projects/hipblaslt/library/src/amd_detail/rocblaslt/src/Tensile/Logic/asm_full/gfx950/Origami/gfx950_Cijk_Ailk_Bjlk_S_MX_B_Bias_HAS_SAV_UserArgs.yaml"

gridlib = yaml.safe_load(open(fgrid))
origamilib = yaml.safe_load(open(forigami))

print("grid ", len(gridlib))
print("orig ", len(origamilib))

print("grid kernels", len(gridlib[5]))
print("orig kernels", len(origamilib[5]))
print("orig kernels", type(origamilib[5]))
print("orig kernels", type(origamilib[5][0]))

print("grid kernels", gridlib[5][0])

uniqueOrigamiMTDU = set()
for sol in origamilib[5]:
    MTxDU =(sol['MacroTile0'],sol['MacroTile1'],sol['DepthU'])
    if (MTxDU not in uniqueOrigamiMTDU):
        uniqueOrigamiMTDU.add(MTxDU)

uniqueGridMTDU = set()
newSol ={}
for sol in gridlib[5]:
    MTxDU =(sol['MacroTile0'],sol['MacroTile1'],sol['DepthU'])
    if (MTxDU not in uniqueGridMTDU):
        uniqueGridMTDU.add(MTxDU)
        newSol[MTxDU] = sol

print("len new sol: ", len(newSol))
# print("new sol: ", newSol)

solIndex = len(origamilib[5])


newKernels = []
replacedKernels = []
for MTxDU in uniqueGridMTDU:
    if (MTxDU not in uniqueOrigamiMTDU):
        print("missing kernel", MTxDU)
        sol = newSol[MTxDU]
        sol['SolutionIndex'] = solIndex
        newKernels.append(solIndex)
        solIndex += 1
        origamilib[5].append(sol)
    else: 
        print("replace kernel")
        # brute force
        for index, sol in enumerate(origamilib[5]):
            MTxDU_old =(sol['MacroTile0'],sol['MacroTile1'],sol['DepthU'])
            if (MTxDU_old == MTxDU):
                print ("index", index)
                
                newSolution = newSol[MTxDU]
                newSolution['SolutionIndex'] = index
                replacedKernels.append(index)
                origamilib[5][index] = newSolution
                break

yaml_args = {"default_flow_style": None, "sort_keys": False}
with open("./outputyaml.yaml", "w") as fp:
    # yaml.dump(origamilib, fp)
    yaml.dump(origamilib, fp, **yaml_args)

newKernels.sort()
replacedKernels.sort()

print("new Kernels: ", newKernels)
print("new Kernels: ", replacedKernels)

