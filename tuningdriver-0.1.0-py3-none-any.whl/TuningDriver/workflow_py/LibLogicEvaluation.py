# Usage:

# python3 LibLogicEvaluation.py <path-to-lib-logic>



import argparse
import math
import yaml
import os

def parseArgs():    
    argParser = argparse.ArgumentParser()

    argHelp = {
         "liblogic" : "path to the lib logic. default: ./config.yaml",
        #  "hipblaslt_path" : "path to local hipblaslt repo",
        #  "outdir" : "output path, default: ./",
        #  "cluster": "specify to cluster sizes. 1 - Parth Algo, 2 - Babak Algo"
        }

    argParser.add_argument("liblogic", action="store", type=str, default = './config.yaml', help=argHelp["liblogic"])
    # argParser.add_argument("hipblaslt_path", action="store", type=str, default = '.', help=argHelp["hipblaslt_path"])
    # argParser.add_argument("--cluster", "-c", action="store", type=int, default=2, help=argHelp["cluster"])
    # argParser.add_argument("--outputPath", "-o", action="store", type=str, default = './', help=argHelp["outdir"])

    return argParser.parse_args()

def loadData(filename):
    try:
        stream = open(filename, "r")
    except IOError:
        print("Cannot open file: ", filename)
        sys.stdout.flush()
        sys.exit(-1)
    data = yaml.load(stream, yaml.SafeLoader)
    return data

def main(args):
    print(f" Here is the path to the liblogic: {args.liblogic}")

    data = loadData(args.liblogic)
    # print(" solutions: ")
    # print(data[5])

    uniqueSol = {}
    uniqueMT = set()
    uniqueDU = set()

    for sol in data[5]:
        MTDU = (sol["MacroTile0"], sol["MacroTile1"],  sol["DepthU"])
        uniqueMT.add((sol["MacroTile0"], sol["MacroTile1"]))
        uniqueDU.add(sol["DepthU"])
        # print("here is the sol", MTDU)

        if MTDU in uniqueSol.keys():
            uniqueSol[MTDU] += 1
        else:
            uniqueSol[MTDU] = 1

    
    for key,value in uniqueSol.items():
        print(f" MTxDU, {key[0]}, {key[1]}, {key[2]}, {value}")

    print(f" number of unique sols: {len(uniqueSol)}")
    print(f" number of sols: {len(data[5])}")
    print(f" number of unique MT: {len(uniqueMT)}")
    print(f" number of unique DU: {len(uniqueDU)}")


if __name__ == "__main__":
    args = parseArgs()
    main(args)