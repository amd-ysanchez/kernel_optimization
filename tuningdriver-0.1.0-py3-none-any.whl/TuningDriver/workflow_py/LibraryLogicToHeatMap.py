
# Generates heat map based on the input files from the library logic files.
# Babak Poursartip

import argparse
import os
import yaml
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np
from pylab import *

# p LibraryLogicToHeatMap.py arcturus_Cijk_Ailk_Bjlk_HSS_BH.yaml
# p LibraryLogicToHeatMap.py arcturus_Cijk_Ailk_Bjlk_HSS_BH.yaml --read ./size.yaml
# p LibraryLogicToHeatMap.py asm_full/aldebaran_Cijk_Ailk_Bjlk_HHS_BH.yaml -m 10000 -n 10000 -k 10000 
# p LibraryLogicToHeatMap.py asm_full/aldebaran_Cijk_Ailk_Bljk_HSS_BH.yaml --read ./size.yaml
# p LibraryLogicToHeatMap.py asm_full/aldebaran_Cijk_Ailk_Bljk_HSS_BH.yaml --read ./size.yaml -m 10000 -n 11000 -k 12000 
# p LibraryLogicToHeatMap.py asm_full/aldebaran_Cijk_Ailk_Bljk_HSS_BH.yaml --read ./size.yaml -m 40000 -n 40000 -k 40000 
# p LibraryLogicToHeatMap.py asm_full/aldebaran_Cijk_Ailk_Bljk_HSS_BH.yaml 


# int8_NN
# p LibraryLogicHeatMap.py /home/babakpst/workspace/Tasks/T26|103_int8_inconsistency/NN/tuning07152022_I8II_NN/merged

# int8_NN
# p LibraryLogicHeatMap.py asm_full/aldebaran_Cijk_Alik_Bljk_I8II_BH.yaml

# BSS_TT
# p LibraryLogicHeatMap.py asm_full/aldebaran_Cijk_Alik_Bjlk_BSS_BH.yaml 

# HSS_NT
# p LibraryLogicHeatMap.py asm_full/aldebaran_Cijk_Ailk_Bjlk_HSS_BH.yaml 

# HSS_NN
# p LibraryLogicHeatMap.py asm_full/aldebaran_Cijk_Ailk_Bljk_HSS_BH.yaml 

# HSS_TT
# p LibraryLogicHeatMap.py asm_full/aldebaran_Cijk_Alik_Bjlk_HSS_BH.yaml 

# HHS_NT
# p LibraryLogicHeatMap.py asm_full/aldebaran_Cijk_Ailk_Bjlk_HHS_BH.yaml 

# DB_NN
# p LibraryLogicHeatMap.py asm_full/aldebaran_Cijk_Ailk_Bljk_DB.yaml
# DB_NT
# p LibraryLogicHeatMap.py asm_full/aldebaran_Cijk_Ailk_Bjlk_DB.yaml

# SB_NT
# p LibraryLogicHeatMap.py asm_full/aldebaran_Cijk_Ailk_Bjlk_SB.yaml

# p LibraryLogicHeatMap.py asm_full/aldebaran_Cijk_Ailk_Bjlk_DB.yaml -m 10000 -n 10000 -k 10000 

# option for solution selection for each size.
# print no of sizes/ max/min/median efficiency


typeIndexToName = {0: "f32_r", 1: "f64_r", 2: "f32_c", 3: "f64_c", 4: "f16_r", 5: "i8_r", 6: "i32_r", 7: "bf16_r", 8: "i8_r", 10: "f8_r", 11: "bf8_r", 12: "f8b8", 13: "b8f8"}

def check_positive(value):
    ivalue = int(value)
    if ivalue <= 0:
        raise argparse.ArgumentTypeError("%s is an invalid positive int value" % value)
    return ivalue

def parseArgs():
    argParser = argparse.ArgumentParser()

    h = {"libLogic" : "Input library logic file",
         "outfile"   : "Output size file-default: sizes.yaml",
         "plot"   : "plots the graph",
         "m"   : "max m in the plot",
         "n"   : "max n in the plot",
         "k"   : "max n in the plot",
         "read" : "reads some new sizes from a size.yaml file",
         "sizes": "print sizes in the library in outfile.yaml file"
    }

    argParser.add_argument("libLogic", metavar="logic-file", type=str, help=h["libLogic"])
    argParser.add_argument("--outfile", metavar="output-file", type=str, default = 'sizes.yaml', help=h["outfile"])
    argParser.add_argument("-p", action="store_true", help=h["plot"])
    argParser.add_argument("-s", action="store_true", help=h["sizes"])
    argParser.add_argument("-m", default=0, type=check_positive, help=h["m"])
    argParser.add_argument("-n", default=0, type=check_positive, help=h["n"])
    argParser.add_argument("-k", default=0, type=check_positive, help=h["k"])
    argParser.add_argument("--read", default="", type=str, help=h["read"])

    return argParser.parse_args()

def sizes(sizeMappings):

    nKernels = 0
    x = np.zeros(len(sizeMappings),dtype=int)
    y = np.zeros(len(sizeMappings),dtype=int)
    z = np.zeros(len(sizeMappings),dtype=int)
    c = np.zeros(len(sizeMappings),dtype=float)
    for i in range(len(sizeMappings)):
      x[i]=sizeMappings[i][0][0]
      y[i]=sizeMappings[i][0][1]
      z[i]=sizeMappings[i][0][3]
      c[i]=sizeMappings[i][1][1]
      if (sizeMappings[i][1][0]>nKernels):
        nKernels = sizeMappings[i][1][0] 

    #print(" no of sizes: {}".format(len(sizeMappings)))
    #print(" m range: {} ~ {}".format(min(x),max(x)))
    #print(" n range: {} ~ {}".format(min(y),max(y)))
    #print(" k range: {} ~ {}".format(min(z),max(z)))

    print("{} {} {:.2f} {:.2f} {:.2f} {} {} {} {} {} {}".format( nKernels, len(sizeMappings),np.amin(c),np.amax(c),np.mean(c),min(x),max(x),min(y),max(y),min(z),max(z)))

    return [x,y,z,c]

def sortfuc(size):
    return (size[0],size[1],size[2])

def printMatrices(args, sizeMappings):
    sizes=[]
    for i in range(len(sizeMappings)):
        newSize = (sizeMappings[i][0][0],sizeMappings[i][0][1],sizeMappings[i][0][3])
        if not (newSize in sizes):
            sizes.append(newSize) 
    sizes.sort(key=sortfuc)

    with open(args.outfile,'w') as f:
        for size in sizes:
            f.write(f" - [ {size[0]}, {size[1]}, 1, {size[2]} ] \n")

def readSizes(args,matrices):
    with open(args.read) as f:
        newSizes = yaml.safe_load(f)

    x = np.zeros(len(newSizes),dtype=int)
    y = np.zeros(len(newSizes),dtype=int)
    z = np.zeros(len(newSizes),dtype=int)
    c = np.zeros(len(newSizes),dtype=float)
    
    print(len(newSizes))
    print(x.shape)
    for i in range(len(newSizes)):
      x[i]=newSizes[i][0]
      y[i]=newSizes[i][1]
      z[i]=newSizes[i][3]
      c[i]=100

    return [x,y,z,c]

# === bbk
def plotMatrices(args,matrices,newMatrices):
    
    x = matrices[0]
    y = matrices[1]
    z = matrices[2]
    c = matrices[3]

    maxEff = np.amax(c)
    minEff = np.amin(c)
    meanEff = np.mean(c)

    if len(newMatrices) > 0:
        nx = newMatrices[0]
        ny = newMatrices[1]
        nz = newMatrices[2]
        nc = newMatrices[3]

    print(x.shape[0])
    #colors = np.random.randint(1, 5, size=x.shape[0])
    #colors = np.random.randint(1, 5, size=10)
    
    fig = plt.figure(figsize=(20, 20))
    ax = fig.add_subplot(111, projection='3d')
    
    # setting color bar
    #color_map = cm.ScalarMappable(cmap=cm.Greens_r)
    color_map = cm.ScalarMappable(cmap=cm.rainbow)
    #color_map = cm.ScalarMappable()
    #color_map.set_array(c)
    color_map.set_array([0,100])
    #ax.autoscale(enable=False)
    
    # creating the heatmap
    #img = ax.scatter(x, y, z, marker='s', s=200, color='green')
    #img = ax.scatter(x, y, z, marker='s', s=200, c=c)
    if len(newMatrices) > 0:
      img = ax.scatter(nx, ny, nz, marker='8', s=10, c='r', label='second')
    img = ax.scatter(x, y, z, marker='8', s=50, c=c, label='first')
    
    #ax.scatter(x[:4], y[:4], s=10, c='b', marker="s", label='first')
    #ax.scatter(x[40:],y[40:], s=10, c='r', marker="o", label='second')
    
    #ax.plot(x, y, linestyle='None', marker='o', markerfacecolor=pts_color, markersize=pts_size, markeredgewidth=0)

    plt.colorbar(color_map)

    # adding title and labels
    ax.set_title("performance of master library | size: {}| max: {:5.2f}, min: {:5.2f}, mean: {:5.2f}".format(len(x),maxEff,minEff,meanEff), fontsize=20)
    ax.set_xlabel('m size', fontsize=18)
    ax.set_ylabel('n size', fontsize=18)
    ax.set_zlabel('k size', fontsize=18)

    ax.tick_params(axis = 'both', which = 'major', labelsize = 10)
    ax.tick_params(axis = 'both', which = 'minor', labelsize = 10)    
    #ax.set_xticklabels('m size', rotation=0, fontsize=18)
    #ax.set_yticklabels('n size', rotation=0, fontsize=18)
    #ax.set_zticklabels('k size', rotation=0, fontsize=18)


    if (args.m>0):
        #ax.autoscale(enable=False, axis="x")
        plt.xlim(0, args.m)
        #ax.set_xlim([0, args.m])
        ax.set_xlim3d((0, args.m))
        #plt.xlim((0, args.m))
    if (args.n>0):
        #ax.set_ylim([0, args.n])
        ax.set_ylim3d((0, args.n))
        #plt.ylim((0, args.n))
        plt.ylim(0, args.n)
    if (args.k>0):
        ax.set_zlim3d((0, args.k))
        #plt.set_zlim3d((0, args.k))
    #    plt.zlim(0, args.k)

    # displaying plot
    plt.show()


def main():
    args = parseArgs()

    with open(args.libLogic) as f:
        logicData = yaml.safe_load(f)

    problem = logicData[4]
    sizeMappings = logicData[7]

    matrices=sizes(sizeMappings)
    
    if (args.s):
        print("print sizes in the library")
        printMatrices(args, sizeMappings)

    newMatrices=[]
    if (args.read):
        newMatrices = readSizes(args,matrices)

    if (args.p):
        print("print the library")
        plotMatrices(args, matrices,newMatrices)



if __name__ == "__main__":
    main()
