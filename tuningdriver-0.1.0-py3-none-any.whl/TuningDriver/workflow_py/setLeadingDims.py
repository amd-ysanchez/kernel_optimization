# This script can be used to set leading dimensions based on the datatype to make a better memory alginemnt
# Leadind dimensions of the GEMM sizes are set to satisfy the following conditons, 
# - (lda * AtypeSize) % 16 == 0
# - (ldb * BtypeSize) % 16 == 0
# - (ldc * CtypeSize) % 16 == 0
# e.g. python3 setLeadingDims.py --input config.yaml --output config_memaligned.yaml --fact 16
#-----------------------------------------------------------------------------------------------

import yaml
import argparse
import math

def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=str, help="Input yaml file name")
    parser.add_argument("--output", type=str, help="Output yaml file name")
    parser.add_argument("--fact", type=int, help="Setup leading dimentions with multiply of fact")
    return parser.parse_args()

def get_bpe(dtype: str):
    dt = dtype.lower()
    dtype_map = {
        'f64_r': 8,
        'f32_r': 4,
        'f16_r': 2,
        'bf16_r': 2,
        'f8_r': 1,
        'f8_fnuz_r': 1,
        'bf8_r': 1,
        'bf8_fnuz_r': 1,
        'i8_r': 1,
        'd': 8, # D
        's': 4, # S
        'h': 2, # H
        'b': 2, # B
        'f8': 1, # F8
        'f8n': 1, # F8N
        'b8': 1, # B8
        'b8n': 1, # B8N
    }
    if dt in dtype_map:
        return dtype_map[dt]
    raise ValueError(f'Unsupported data type: {dtype}')


def align_leading_dim(data_type, ldim, condition_fact=16):
    type_size = get_bpe(data_type)
    weight =  ldim*type_size
    if weight% condition_fact !=0 :
        weight = math.ceil(weight/condition_fact) * condition_fact
        print(f" {ldim} is adjusted to {int(weight/type_size)}")
    return int(weight/type_size)

def modify_yaml(in_file, out_file, condition_fact=16):
    with open(in_file, 'r') as file:
        data = yaml.safe_load(file)

    for item in data:
        item['lda'] = align_leading_dim(item.get('a_type'), item.get('lda'), condition_fact)
        item['ldb'] = align_leading_dim(item.get('b_type'), item.get('ldb'), condition_fact)
        item['ldc'] = align_leading_dim(item.get('c_type'), item.get('ldc'), condition_fact)

    with open(out_file, 'w') as file:
        yaml.dump(data, file, default_flow_style=None, sort_keys=False, width=5000)

def main():
    args = parse_arguments()
    modify_yaml(args.input, args.output, args.fact)
    print("Generated!")

if __name__ == "__main__":
    main()
