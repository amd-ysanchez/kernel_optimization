########################################################################################################################
# Description
# This script determines if a GEMM size is of type "Memory-Bound" (MB) or "Compute-Bound" (CB).
# To decide whether a GEMM is MB or CB, we need:
#   1. Hardware information
#   2. GEMM input datatype
#   2. Macro-tile (MT) size used for this GEMM based on the library.
#   3. K dimension of the size
#
# Notes:
#   1. GEMM datatype and asic is independent of the library and the input config. We only parse the sizes in the library
#      and the sizes in the input file, ignoring all datatypes and other information. These should be given in the
#      command line.
#   2. Don't forget to add the asic to 'ASICS' dictionary with the correct values if it not already listed.

########################################################################################################################
# Usage:
# Simply run:
#   python3 CompOrMem.py --asic gfx950 --datatype BF16 --mode 1 --libLogic lib.yaml --inputConfig bench.yaml --outputCSV out.csv
#
# This will parse the lib.yaml library to extract the grid. Then, bench.yaml config file (the same that is fed to 
# hipblaslt-bench) is parsed to extract the sizes that we are interested in knowing whether they are CB or MB.
# Asic and Dataype for the GEMM is also given as CLI.
# The ouput is a csv file (out.csv in this case) where each line corresponds to the size in bench.yaml in the same order.
# In this mode (--mode 1), we exactly evaluate which MT will be used based on the given ibrary.
# In --mode 2, we can pick a MT that gives the best occupancy. In this mode, there is no need to give the path to libLogic.

########################################################################################################################
import sys
import argparse
import copy
from sortedcontainers import SortedList
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tqdm import tqdm
import yaml
import math




# ARG PARSER ###########################################################################################################
ASICS = {
    'gfx950': 
    {
        "CU": 256, 
        "XCC": 8, 
        "L2BW_read_perXCC": 2048, 
        "L2_Eff": 0.75,
        "ALU_throughput": 
        {
            "F64":  256,
            "F32":  256,
            "F16":  4096,
            "BF16": 4096,
            "F8":   8192,
            "BF8":  8192,
            "I8":   8192
        }         
    }
}

BytesPerElement = {
    "F64":  8,
    "F32":  4,
    "F16":  2,
    "BF16": 2,
    "F8":   1,
    "BF8":  1,
    "I8":   1
}

typeIndexToName = {
    0: "F32", 
    1: "F64", 
    2: "F32_C", 
    3: "F64_C", 
    4: "F16", 
    5: "I8", 
    6: "I32", 
    7: "BF16", 
    8: "I8", 
    10: "F8", 
    11: "BF8", 
    12: "F8BF8", 
    13: "BF8F8",
    15: "F8", 
    16: "BF8", 
    17: "F8BF8", 
    18: "BF8F8"
}




# # ARG PARSER ###########################################################################################################
def parseArgs():
    argParser = argparse.ArgumentParser()

    argParser.add_argument("--mode", type = int,
                           help="Mode to do the test; Mode 1 is based on liblogic, and Mode 2 is based on the best \
                            granularity. See the top of the scripts for more info.")
    argParser.add_argument("--asic",
                           help="Architecture: MI300, MI350, ...")
    argParser.add_argument("--datatype",
                           help="Datatype: F16, BF8F8, I8, ...")
    argParser.add_argument("--libLogic",
                           help="The library logic file path")
    argParser.add_argument("--inputConfig",
                           help="The input config yaml file path")
    argParser.add_argument("--outputCSV", nargs='?', default="isComputeBound.csv",
                           help="The output csv file path")
    return argParser.parse_args()




# LIBRARY CLASS ########################################################################################################
class Library:
    def __init__( self, library_logic_yaml_file ):
        self._library_logic_yaml_file = library_logic_yaml_file
        self._parse_library_logic_yaml_file()
        self._read_MTs()




    # Misc. Methods ####################################################################################################
    @staticmethod
    def _flatten_library( library ):
        for x in library[7]:
            yield tuple( [*x[0], *x[1]] )




    def _parse_library_logic_yaml_file( self ):
        print( "Reading the input lib logic yaml file..." )
        with open( self._library_logic_yaml_file ) as l:
            self._library = yaml.safe_load( l )
            df = pd.DataFrame( Library._flatten_library( self._library ) )
            df.columns = ['M', 'N', 'B', 'K', 'SolutionIndex', 'Efficiency']
            df = df.astype( int )
            self._library_df = df
            self._sort_df()
        print( "Reading the input lib logic yaml file completed!" )




    def _sort_df( self ):
        pd = self._library_df.sort_values( ['M', 'N', 'B', 'K'], ascending = [True, True, True, True] ).reset_index( drop = True )
        self._library_df = pd

    


    # Reads the MT size for each size in the library
    def _read_MTs( self ):
        """
        Reads MTs for all solutions based on the library logic
        """
        solutions = self._library[5]
        MT0 = []
        MT1 = []
        for r, row in self._library_df.iterrows():
            sID = row['SolutionIndex']
            # The solutions are sorted based on the SolutionIndex
            solution = solutions[sID]
            MT0.append( solution['MacroTile0'] )
            MT1.append( solution['MacroTile1'] )
        self._library_df['MT0'] = MT0
        self._library_df['MT1'] = MT1
        



   # Properties #######################################################################################################
    @property
    def number_of_grid_points( self ):
        return len( self._library_df )




    @property
    def unique_Ns( self ) -> set:
        return list( map( int, sorted( self._library_df['N'].unique() ) ) )




    @property
    def unique_Ms( self ) -> set:
        return list( map( int, sorted( self._library_df['M'].unique() ) ) )




    @property
    def unique_Bs( self ) -> set:
        return list( map( int, sorted( self._library_df['B'].unique() ) ) )




    @property
    def unique_Ks( self ) -> set:
        return list( map( int, sorted( self._library_df['K'].unique() ) ) )




    # Methods ##########################################################################################################
    # Gets all the rows with M = m
    def get_rows_with_M( self, m: int ):
        return copy.deepcopy( self._library_df[ self._library_df['M'] == m ] )




    # Gets all the rows with M = m, N = n
    def get_rows_with_MN( self, m: int, n: int ):
        df = self.get_rows_with_M( m )
        return copy.deepcopy( df[ df['N'] == n ] )




    # Gets all the rows with M = m, N = n, K = k
    def get_rows_with_MNK( self, m: int, n: int, k: int ):
        df = self.get_rows_with_MN( m, n )
        return copy.deepcopy( df[ df['K'] == k ] )




    # Gets unique Ms
    def get_unique_M( self ):
        return SortedList( self._library_df['M'].unique() )




    # Gets unique Ns in M = m
    def get_unique_Ns_in_M( self, m: int ):
            return SortedList( self.get_rows_with_M(m)['N'].unique() )




    # Gets unique Ks in M = m and N = n
    def get_unique_Ks_in_MN( self, m: int, n: int ):
        return SortedList( self.get_rows_with_MN( m, n )['K'].unique() )
    



    # Add points #######################################################################################################
    def find_MT( self, m: int, n: int, b: int, k: int ):
        """
        Returns the MT that will be used for a given GEMM size based on the library.
        It selects the solution for the size, the same way that it happens in hipblaslt

        Args:
            m (int), n (int), b (int), k (int): The dimensions of the GEMM

        Returns:
            MT0 (int): MacroTile0
            MT1 (int): MacroTile1
        """
        
        def find_higher_value( sorted_list, target ):
            """
            Returns the next higher value than target in a sorted list.
            If the value exists in the array, returns value.

            Args:
                sorted_list (int): the sorted list
                target (int): the target value

            Returns:
                int: the next higher value than target
            """
            # Find the insertion point where target would fit in sorted order
            idx = sorted_list.bisect_right( target )
            if idx > 0 and sorted_list[idx - 1] == target:
                return target
            elif idx < len( sorted_list ):
                return sorted_list[ idx ]
            # If there's no higher value (target is larger than all elements)
            else:
                return sorted_list[ -1 ]

        
        def find_closest_value( sorted_list, target ):
            """
            Returns the closest value to target in a sorted list.
            If the value exists in the array, returns value.

            Args:
                sorted_list (int): the sorted list
                target (int): the target value

            Returns:
                int: the closest value to target
            """
            # Find the insertion point where target would fit in sorted order
            idx = sorted_list.bisect_right( target )

            # Check the closest neighbor
            if idx == 0:
                return sorted_list[0]  # Closest is the first element
            if idx == len(sorted_list):
                return sorted_list[-1]  # Closest is the last element

            # Compare the neighbors to find the closest
            before = sorted_list[idx - 1]
            after = sorted_list[idx]

            # Return the closest of the two
            if abs( before - target ) <= abs( after - target ):
                return before
            else:
                return after

        # Solution Selection
        sortedList_M = self.get_unique_M()
        higher_m = find_higher_value( sortedList_M, m )
        sortedList_N = self.get_unique_Ns_in_M( higher_m )
        # Check if the M = higher_m and N = n  node exist
        higher_n = find_higher_value( sortedList_N, n )
        sortedList_K = self.get_unique_Ks_in_MN( higher_m, higher_n )
        closest_k = find_closest_value( sortedList_K, k )
        row = self._library_df[(self._library_df['M'] == higher_m) & (self._library_df['N'] == higher_n) & (self._library_df['K'] == closest_k)]
        return( row['MT0'].iloc[0], row['MT1'].iloc[0] )


def find_MT( m: int, n: int, b: int, k: int, asic: str ):
    '''
    This function finds the best MT for a given size based on granularity

    Args:
        m (int): M dimension
        n (int): N dimension
        b (int): B dimension
        k (int): K dimension

    Returns:
        MT0, MT1 
    '''
    # Find the max size of tile (min number of tile) in each direction
    maxSizeTile0 = min(math.ceil( m / 16 ) * 16, 256)
    maxSizeTile1 = min(math.ceil( n / 16 ) * 16, 256)
    minNumberOfTiles = math.ceil(m / maxSizeTile0) * math.ceil(n / maxSizeTile1)
    numWaves = max(1, math.ceil(minNumberOfTiles / ASICS[asic]["CU"]))
    # if math.ceil( m / 256 ) * math.ceil( n / 256 ) >= ASICS[asic]["CU"]:
    #     # We cannot perform this in one wave
    #     return min(math.ceil( m / 16 ) * 16, 256), min(math.ceil( n / 16 ) * 16, 256)
    
    numTiles = 0
    MT0_arr = [16]
    MT0_arr.extend([i for i in range(32, 513, 16) if i - 16 <= m]) # allow the tile to be slightly larger
    MT1_arr = [16]
    MT1_arr.extend([i for i in range(32, 513, 16) if i - 16 <= n]) # allow the tile to be slightly larger
    for mt0 in MT0_arr:
        for mt1 in MT1_arr:
            t1 = math.ceil( m / mt0 )
            t2 = math.ceil( n / mt1 )
            tmp = t1 * t2
            if tmp < numWaves * ASICS[asic]["CU"] and tmp >= numTiles:
                MT0 = mt0
                MT1 = mt1
                numTiles = tmp
    return MT0, MT1


def process_sizes( asic: str, datatype: str, mode: int, dir: str, lib ) -> pd.DataFrame:
    '''
    This function reads the bench config file, finds the MTs, and detemines if a GEMM is CB.

    Args:
        asic (str): asic such as gfx950 
        datatype (str): input datatype such as F16, BF8F8, ...
        mode (int): 1 is finding the MT according to the library (solution selection)
                    2 is based on granularity
        dir (str): path to the bench config file
        lib (Library): Library logic if mode is 1

    Returns:
        DF: dataframe with sizes, MTs assigned to them, and CB boolean flag
    '''
    sizes = []
    with open( dir ) as l:
        configYAML = yaml.safe_load( l )
        for c in configYAML:
            sizes.append([c['M'], c['N'], c['batch_count'], c['K']])
    
    sizesWithMTs = []
    for s in sizes:
        if mode == 1:
            mt0, mt1 = lib.find_MT( *s )
        elif mode == 2:
            mt0, mt1 = find_MT( *s, asic )
        modified_k = s[2] * s[3]
        icb = isComputeBound( asic, datatype, modified_k, mt0, mt1 )
        sizesWithMTs.append( [s[0], s[1], s[2], s[3], mt0, mt1, icb] )
    return ( pd.DataFrame( sizesWithMTs, columns=['M', 'N', 'B', 'K', 'MT0', 'MT1', 'isComputeBound'] ) )

def isComputeBound( asic: str, datatype: str, K: int, MT0: int, MT1: int ) -> bool:
    '''
    This function determines if a GEMM is MB or CB, given the library for it, K dimension, and MT sizes.
    It returns "True" if the GEMM is CB, and "False" otherwise.
    '''
    hardware = ASICS[asic]
    BPE = BytesPerElement[datatype] #BytesPerElement
    L2_eff = hardware["L2_Eff"]
    L2BW_perCU = hardware["L2BW_read_perXCC"] * hardware["XCC"] / hardware["CU"]
    
    BytesForMath = MT0 * K * BPE + MT1 * K * BPE + MT0 * MT1 * BPE
    FLOPS = 2 * MT0 * MT1 * K / hardware["ALU_throughput"][datatype]
    roofLine = BytesForMath / FLOPS

    return ( roofLine < L2_eff * L2BW_perCU )


# Main #################################################################################################################
def main():
    args = parseArgs()
    asic = args.asic
    datatype = args.datatype
    mode = args.mode
    inputConfig = args.inputConfig
    outputCSV = args.outputCSV

    if mode == 1:
        libDir = args.libLogic
        lib = Library( libDir )
    elif mode == 2:
        lib = ""
    else:
        raise ValueError("mode value is not supported!")

    sizes = process_sizes( asic, datatype, mode, inputConfig, lib )
    sizes['isComputeBound'].to_csv( outputCSV, index = False )





########################################################################################################################
if __name__ == '__main__':
    main()