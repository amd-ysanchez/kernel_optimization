"""
Generates a csv file with list of sizes for OOB benchmarking. 
python3 ../../generateOOBBenchmarkSizes.py -ds 1 -v -gt all : generate large dataset size (25500) oob sizes for all datatype
python3 ../../generateOOBBenchmarkSizes.py -ds 0 -v -gt all : generate large dataset size (5000) oob sizes for all datatype
python3 ../../generateOOBBenchmarkSizes.py -ds 0 -v -gt BBS -tp : generate large dataset size (5000) oob sizes for BBS datatype and plots sizes
"""

import math
import random
import argparse
from hipblaslt_benchInputCreator import createYaml
import time
import matplotlib.pyplot as plt
import pandas as pd
from CompOrMem import find_MT, isComputeBound
import copy

### Constants ###

LARGE_DATASET = 25500
SMALL_DATASET = 5000

VALIDGEMMTYPE = ["BBS", "HHS", "BSS", "HSS", "F32", "F8HS", "F8BS", "TF32"] # add all: S_MX, F8F8S, ....

K_LIST = [32, 128,256, 1024, 8192, 16384, 131072]

# list of MIs for each datatype # TODO, add MI300
MI = {}
MI["gfx950"] = {
"F8": [
    (4,4,4,16), #MI300
    (16,16,128,1), #MI350
    (32,32,64,1) #MI350
    ],
"F16":[
    (4,4,4,16), #MI300
    #[16,16,4,4] # never use 16x16x4x4
    #[16,16,16,1] #MI300
    #[32,32,4,2] # never use 32x32x4x2
    #[32,32,8,1] #MI300
    (16,16,32,1), #MI350
    (32,32,16,1) #MI350
    ],
"BF16":[
    (4,4,4,16), #MI300
    #[16,16,4,4] # never use 16x16x4x4
    #[16,16,16,1] #MI300
    #[32,32,4,2] # never use 32x32x4x2
    #[32,32,8,1] #MI300
    (16,16,32,1), #MI350
    (32,32,16,1) #MI350
    ],
"F32":[
    (16,16,4,1),
    (32,32,2,1)
    ],
# "X": [
#   (32,32,4,1),
#   (16,16,8,1)
#     ],
"D":[
  (16,16,4,1)
    ],
"C": [
  (16,16,4,1)
    ],
"Z":[
  (16,16,4,1)
    ],
"I8": [
  (32,32,16,1),
  (16,16,32,1),
  (4,4,4,16)
],
}
MI["gfx950"]["X"] = MI["gfx950"]["BF16"]


dataTypeMap = {7: "BF16", 4: "F16", 0: "F32" , 11: "F8"}

DataType = {
      "BBS" : 7,
      "HHS" : 4,
      "BSS" : 7,
      "HSS" : 4,
      "F32" : 0,
      "F8HS": 11,
      "F8BS": 11,
      "TF32": 0
}

ComputeDataType = {
  "BBS" : 0,
  "HHS" : 0,
  "BSS" : 0,
  "HSS" : 0,
  "F32" : 0,
  "F8HS": 0,
  "F8BS": 0,
  "TF32": 0
}

DestDataType = {
  "BBS" : 7,
  "HHS" : 4,
  "BSS" : 0,
  "HSS" : 0,
  "F32" : 0,
  "F8HS": 4,
  "F8BS": 7,
  "TF32" : 0,
}

# map HW to CU
HW2CUCount = {}
HW2CUCount["gfx950"] = 256

### Utility functions ###

def getArgs():
  argParser = argparse.ArgumentParser()
  argParser.add_argument("--datasetSize", "-ds", default =1, type = int, help = "1 for large dataset and 0 for small dataset")
  argParser.add_argument("--hardware", "-hw", default ="gfx950", type = str, help = "specify hardware string, refer to MI dict under Constants for supported HW")
  argParser.add_argument("--gemmType", "-gt", default = "HHS", type = str, help = "specify the gemm type, 'all' for generating for all gemm types")
  argParser.add_argument("--batchType", "-bt", default = "non-batched", type = str, help = "specify the batch type, 'batched', 'non-batched & 'all' for generating both")
  argParser.add_argument("--gran1", "-g1", action = 'store_true', help = "specify to generate granularity 1 sizes. This will genrerate all sizes with round=[1,1] only")
  argParser.add_argument("--verbose", "-v", action = 'store_true', help = "specify to log")
  argParser.add_argument("--toPlot", "-tp", action = 'store_true', help = "specify to generate size plots")
  argParser.add_argument("--noConfig", "-nc", action = 'store_false', help = "specify to not generate hipblaslt-bench yamls")
  return argParser.parse_args()

def generatePairs(n):
    # Function to generate (a,b) ordered pairs where n=a*b
    pairs = []
    for a in range(1, int(n**0.5) + 1):
        if n % a == 0:
            b = n // a
            pairs.append((a, b))
            if a != b:
                pairs.append((b, a))
    pairs.sort(key=lambda x: abs(x[0] - x[1]))
    return pairs

def plotSizePlane(matrices, k=8192, suffix="non_batched"):
  x = []

  y = []
  for [M,N,B,K] in matrices:
    if K != k: continue
    x.append(M)
    y.append(N)
  fig = plt.figure(figsize=(20, 20))
  ax = fig.add_subplot(111)
  img = plt.scatter(x, y, s=50)
  plt.xlim(0,20_000)
  plt.ylim(0,20_000)
  plt.xticks(fontsize=22)
  plt.yticks(fontsize=22)
  plt.xlabel(f'M dim', fontsize=30)
  plt.ylabel(f'N dim', fontsize=30)
  plt.title(f'K={k} size plane', fontsize=30)
  plt.savefig(f"sizeplane_{k}_{suffix}.png")
  plt.close()

def plotMatrices(matrices, suffix="non_batched"):
    # Utility function to plot sizes. 
    # TODO - Clean code.
    nMatrices = len(matrices)

    x=[]
    y=[]
    z=[]
    for M,N,B,K in matrices:
      x.append(M)
      y.append(N)
      z.append(K)
    #c = np.zeros(x.shape[0])

    fig = plt.figure(figsize=(20, 20))
    ax = fig.add_subplot(111, projection='3d')

    img = ax.scatter(x, y, z, marker='8', s=50)
    
    # adding title and labels
    ax.set_title("sizes 25k", fontsize=30)
    ax.set_xlabel('M', fontsize=30, labelpad=20)
    ax.set_ylabel('N size', fontsize=30, labelpad=20)
    ax.set_zlabel('K size', fontsize=30, labelpad=20)
    ax.tick_params(axis = 'both', which = 'major', labelsize = 15)
    ax.tick_params(axis = 'both', which = 'minor', labelsize = 15)        
    
    plt.savefig(f"sizes_{suffix}.png")

def isComputeBoundInternal(s, datatype, asic):
  # Wrapper around Ali's function to classify sizes as MB / CB
  mt0, mt1 = find_MT( *s, asic )
  modified_k = s[2] * s[3]
  return isComputeBound( asic, dataTypeMap[datatype], modified_k, mt0, mt1 )

# Class to log
class Logger:
  def __init__(self, isVerbose = True):
    self.isVerbose = isVerbose
  
  def log(self, msg):
    if not self.isVerbose: return
    print(f"[LOG] - {msg}")

# Class to generate sizes for a gemmType
class OOBSizeGenerator:
  def __init__(self, hardware, gemmType, isBatched = False, datasetSize = 1, isGranAll = True, isVerbose = True):
    self.hardware      = hardware
    self.gemmType      = gemmType
    self.isBatched     = isBatched
    self.datasetSize   = datasetSize
    self.numCUs        = HW2CUCount[hardware]
    self.totalNumSizes = LARGE_DATASET if self.datasetSize else SMALL_DATASET
    self.suffix        = "large" if self.datasetSize else "small"
    self.dataType      = DataType[gemmType]
    self.K_list        = K_LIST
    self.isGranAll     = isGranAll
    self.logger        = Logger(isVerbose)
    self.name          = "batched" if self.isBatched else "non_batched" + f"_{self.suffix}"

    self.logger.log(f"Generating sizes for - {self.gemmType}_{self.name}_{self.suffix} dataset")

    return

  def _generateSpecialSizes(self):
    # Additional sizes to be added with very large dim ~ 10^6
    sizes_list = []
    small_dim = [2, 4, 8, 16, 96]
    vLarge_dim = [1_000_000, 2_000_000, 6_000_000, 12_000_000, 20_000_000]
    for s in small_dim:
      for l in vLarge_dim:
        self.sizes_list.append([s,l,1,s])
        self.sizes_list.append([l,s,1,s])
        self.sizes_list.append([s,s,1,l])
    return

  def _generateLatencyBoundSizes(self):
    # Function to generate latency bound sizes.
    small_dim = [1,2,4,8]
    large_dim = [128, 256, 1024, 4096]
    for ds in small_dim:
      for dl in large_dim:
        for k in self.K_list:
          for b in self.B_list:
            self.sizes_list.append([ds, dl, b, k])
            self.sizes_list.append([dl, ds, b, k])
    return

  def _generateTileList(self):
    # Function to generate list of all valid (MT0,MT1) for a given HW and gemmType
    # HW - "gfx950"
    # gemmType - ['H','B','F8','S','I8','Z','C','D','X','S']

    LIST_OF_WAVEs_TO_INCLUDE = [[4, 1], [2, 2], [1, 4], [1, 2], [2, 1], [1, 1]]
    MIN_MT0 = MIN_MT1 = 16
    MAX_MT0 = MAX_MT1 = 512
    bm_max = 0
    tile_list = set()
    for mi in MI[self.hardware][dataTypeMap[self.dataType]]:
        for bm in range(bm_max + 1):
            MIBlockM = 2 ** bm

            for wave in LIST_OF_WAVEs_TO_INCLUDE:
                waveTileM = 0
                waveTileN = 0

                while True:
                    waveTileM+=1
                    waveTileN=0
                    MatrixInstM = mi[0] * MIBlockM
                    MT0 = MatrixInstM * waveTileM * wave[0]
                    if MT0 < MIN_MT0:
                        continue
                    if MT0 > MAX_MT0:
                        break

                    while True:
                        waveTileN+=1
                        MatrixInstN = mi[1] / MIBlockM * mi[3]
                        MT1 = int(MatrixInstN * waveTileN * wave[1])

                        if MT1 < MIN_MT1:
                            continue
                        if MT1 > MAX_MT1:
                            break

                        # LDS size check for lsu
                        LSU = max(1, 4//wave[0]//wave[1])
                        if LSU > 1 and MT0*MT1*4*LSU > 256*256: # computeDataTypeSize[self.config['DataType']] = 4 bbk fix
                            continue

                        if MT0*MT1 > 256*256:
                            continue
                        # for DU in [32, 64, 128, 256, 512]:
                            # tile_list.add((MT0, MT1, DU, MI[0], MI[1], MI[2], 1))
                            #tile [MT0, MT1, DU, MFMA0, MFMA1, MFMA2, CUOccupancy = 1]
                        # valid_mfmas.append([MI[0], MI[1], MI[2], MI[3], MIBlockM, waveTileM, waveTileN, wave[0], wave[1]])

                        # tile_list.add((MT0, MT1,MI[0], MI[1], MI[2]))
                        tile_list.add((MT0, MT1))
                        # tile_list.add((MT0, MT1,MI[0], MI[1], MI[2], MI[3], MIBlockM, waveTileM, waveTileN, wave[0], wave[1]))

    final_tiles = [tile for tile in tile_list]
    self.logger.log(f"total number of unique tiles: {len(final_tiles)}")

    with open(f"All_Macrotiles_{dataTypeMap[self.dataType]}.txt",'w') as file:
      for tile in final_tiles:
          file.write(f'{tile[0]}, {tile[1]}\n') #, {tile[2]}, {tile[3]}, {tile[4]}\n')
    return final_tiles

  def _generateSizes(self):
    # Function to genreate the general sizes corresponding 
    # to all valid MTs, gran, and tileLayouts
    tileLayouts = generatePairs(self.numCUs)
    self.gran = [0.5, 0.8, 1] if self.isGranAll else [1]

    # generates many duplicates, but they will be eliminated later.
    # This is only for the edge macrotiles.
    rounds = [[1,1], [2,1], [1,2], [2,2], [1,4], [4,1], [1,3], [3,1], [4,4]]
    if not self.isGranAll: rounds = [[1,1]]

    MNBK_MT = []
    size_set = set()

    macroTiles = []
    tiles = self._generateTileList()

    for mt0,mt1 in tiles:
        macroTiles.append([mt0, mt1])

        mnbk_mt = []
        for tileLayout in tileLayouts:
          for g in self.gran:
            for r in rounds:
              M = math.floor(mt0*r[0]*g*tileLayout[0])
              N = math.floor(mt1*r[1]*g*tileLayout[1])          
              for K in self.K_list:
                for B in self.B_list:
                  # if M*N/(256*256) < numCUs / B:
                  if (M,N,B,K) in size_set: continue
                  mnbk_mt.append([M,N,B,K])
                  size_set.add((M,N,B,K))
        MNBK_MT.append(mnbk_mt)

    self.logger.log(f"Number of sizes before sampling - {sum([len(x) for x in MNBK_MT])}")
    self.logger.log(f"num of MT0 x MT1 {len(macroTiles)}")
    
    self.sizesPerMT = MNBK_MT
    return 

  def _sizeSample(self):
    # Function to sample across all generated sizes
    num_small_sizes = len(self.sizes_list)
    num_sizes_per_MT = math.floor((self.totalNumSizes - num_small_sizes) / len(self.sizesPerMT))
    extra_size = 0

    for mnbk_mt in self.sizesPerMT:
      mnbk_mt_sampled = mnbk_mt
      if len(mnbk_mt) > (num_sizes_per_MT+extra_size):
        random.seed()
        mnbk_mt_sampled = random.sample(mnbk_mt, num_sizes_per_MT+extra_size)
        extra_size = 0
      else:
        extra_size += num_sizes_per_MT - len(mnbk_mt)
      
      if self.isGranAll: 
        for mnbk in mnbk_mt_sampled: self.sizes_list.append(mnbk)
      else:
        # in case of gran = [1] no sampling.
        for mnbk in mnbk_mt: self.sizes_list.append(mnbk)
    return

  def _sortAndDumpSizeInfo(self):
    # Add compute/mem bound classification, sort and dump sizes to csv file
    sorted_sizes = copy.deepcopy(self.sizes_list)
    # add c/m bound classification
    for i,size in enumerate(sorted_sizes): sorted_sizes[i].append(isComputeBoundInternal(size, self.dataType, self.hardware))
    # sort sizes. 
    sorted_sizes = sorted(sorted_sizes, key=lambda x: (x[-1], x[0], x[1], x[2], x[3]))
    
    f = open(f"sizes_{self.name}_{self.gemmType}.csv", 'w')
    for s in sorted_sizes:
      f.writelines(f"{s[0]}, {s[1]}, {s[2]}, {s[3]}\n")
    f.close()
    
    self.logger.log(f"Number of {self.name} sizes - {len(self.sizes_list)}")
    return

  def generateAndDumpBenchYAML(self):
    # Funtion to prepare require data structure to generate hipblaslt-bench
    # configs via hipblaslt bench config generator.   
    sizeMapping = []
    for size in self.sizes_list: sizeMapping.append([size, [0, 0.0]])

    trans = [["T","N"], ["N","N"], ["T","T"], ["N","T"]]
    
    fileName = f"workload_{self.suffix}"
    if self.isBatched: fileName += "_batched"
    else: fileName += "_non_batched"
        
    for t in trans:
      problemDict = {}
      problemDict["ComplexConjugateA"] = False
      problemDict["ComplexConjugateB"] = False
      problemDict["TransposeA"] = t[0] == 'T'
      problemDict["TransposeB"] = t[1] == 'T'
      problemDict["DataType"] = DataType[self.gemmType]
      problemDict["DestDataType"] = DestDataType[self.gemmType]
      problemDict["ComputeDataType"] = ComputeDataType[self.gemmType]
      problemDict["HighPrecisionAccumulate"] = (DestDataType[self.gemmType] != ComputeDataType[self.gemmType])
      if self.gemmType == "TF32": problemDict["F32XdlMathOp"] = 10

      start = time.time()
      createYaml('trig', False, 0.0, ".", f"{fileName}_{self.gemmType}_{t[0]}{t[1]}", problemDict, sizeMapping, False, 4)
      end = time.time()
      self.logger.log(f"Execution time {fileName}_{self.gemmType}_{t[0]}{t[1]} : {end - start:.4f} seconds")

  def generateSizes(self):
    # Main function to generate sizes

    dataType = dataTypeMap[self.dataType]
    self.B_list = [1]
    if self.isBatched: self.B_list  = [2, 8, 32, 128, 256, 512, 1024, 2048, 4096, 6144]

    self.sizes_list = []

    # Latency bound sizes 
    if self.isGranAll: self._generateLatencyBoundSizes()

    # # Add special sizes (dim >= 10^6)
    # if self.isGranAll: self._generateSpecialSizes()

    # General sizes
    self._generateSizes()

    # Sample
    self._sizeSample()

    # Classify & sort sizes. Dump as CSV file
    self._sortAndDumpSizeInfo()

    return self.sizes_list

def main():
  args = getArgs()

  hardware      = args.hardware
  datasetSize   = args.datasetSize
  gemmType      = args.gemmType
  isGranAll     = not args.gran1
  toPlot        = args.toPlot
  toGenConfig   = args.noConfig
  batchTypeInp  = args.batchType

  # Parse gemm type
  if gemmType == 'all':
    gemmType = VALIDGEMMTYPE
  else:
    assert gemmType in VALIDGEMMTYPE, f"gemmType not in {VALIDGEMMTYPE}"
    gemmType = [gemmType]

  # Parse batch type
  batchType = [True,False]
  if batchTypeInp == "batched":   batchType = [True]
  elif batchTypeInp == "non-batched": batchType = [False]

  for gemm in gemmType:
    for isBatched in batchType:
      OOBSizeGeneratorObj = OOBSizeGenerator(hardware, gemm, isBatched, datasetSize, isGranAll)

      sizes  = OOBSizeGeneratorObj.generateSizes()
      # if toPlot: plotMatrices(sizes, "batched" if isBatched else "non_batched")
      if toPlot: plotSizePlane(sizes, 8192, "batched" if isBatched else "non_batched")
      if toGenConfig: OOBSizeGeneratorObj.generateAndDumpBenchYAML() 
    
  return

if __name__ == "__main__":
  main()