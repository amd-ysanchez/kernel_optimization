################################################################################
#
# Copyright (C) 2016-2023 Advanced Micro Devices, Inc. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
################################################################################

# This script reads the output of rocblas-bench with ROCBLAS_LAYER=2 (default) or ROCBLAS_LAYER=4, and summarizes the sizes based on GEMM types.
# It covers I8/HHS/HSS/BBS/BSS/SGEMM/DGEMM/CGEMM/ZGEMM.

# Usage
# This script reads a bench yaml (test.yaml) and a latency file and calculate the required iterations for the specified duration (-d). 
# The latency file should contain one line per the each benchmark GEMM in the bench yaml (test.yaml). This is indead the output of ./rocblas-bench --yaml test.yaml (with other iterations).


# python3 .\rocblas-iterations.py --input test.yaml --output benchIterTest.yaml --latency latency.log -d 3

import os
import argparse
import yaml
import math
import re

def parseBenchCofnig():
    argParser = argparse.ArgumentParser()

    h = {"inputfile" : "input bench file",
         "outputfile" : "output file containing bench config with correct iterations",
         "LatencyFile": "calculate the iterations based on latency(us) from the file. The length of data should be equal to the number of GEMMs, otherwise, it sets it to default (9999)",
         "duration" : "total benchmark duration for cold and hot iterations in seconds"
    }

    argParser.add_argument("--input",   action="store", metavar="rocblas_log-file", type=str, help=h["inputfile"])
    argParser.add_argument("--output",  action="store", metavar="output-dir",       type=str, help=h["outputfile"])
    argParser.add_argument("--latency", "-u",    action="store", metavar="itersCal",         type=str, default='', help=h["LatencyFile"])
    argParser.add_argument("--duration", "-d", action="store", type=float, default = 0.0,  help=h["duration"])
    
    return argParser.parse_args()


def readLatencyFile(inputLatency, inputConfig, duration, outputBench):

    latencyUS= open(inputLatency, 'r')
    latencyLines = latencyUS.readlines()

    time = []
    for log in latencyLines:
        logSplit = log.split(',')
        time.append(float(logSplit[-1]))
        # print(f'{log} \n time: {time[-1]}')
    
    config = open(inputConfig, 'r')
    configLines = config.readlines()
    
    count = 0
    if len(configLines) != len(latencyLines):
        print("WARNING: the latency file has a different size than the tota unique sizes")

    

    benchyaml=open(outputBench, "w") 

    for gemm in configLines:

        if count<len(latencyLines):
            iters = math.ceil(duration / time[count])
            print(f"latency: {latencyLines[count].strip()}, iters: {iters}, us {time[count]}" )
        else: 
            iters = 999
        count += 1

        gemmIters = re.sub("iters:.*,", f'iters: {iters},',gemm)
        # print(gemmIters)
        tmp = f"cold_iters: {iters}"
        tmp = tmp +"}"
        gemm = re.sub("cold_iters:.*}", tmp,gemmIters)
        # print(gemm)
        benchyaml.write(gemm)

def main():
    args = parseBenchCofnig()    

    # check if input exists
    if not os.path.isfile(args.input): 
       raise FileNotFoundError("{0} input file does not exist!".format(args.input))

    latency = readLatencyFile(args.latency, args.input, args.duration*1000000, args.output)
    

    print("Done!")

if __name__ == "__main__":
    main()
