"""
How to run the script.
python3 generateAnchorSize.py <CU_COUNT>
To limit sizes to 20 -
python3 generateAnchorSize.py <CU_COUNT> -l 
"""

import itertools
import argparse
import math
import yaml
import os
from hipblaslt_benchInputCreator import createYaml

def parseArgs():    
    argParser = argparse.ArgumentParser()

    h = {
        "CUCount" : "Number of CUs",
        "limit_num_sizes": "If specified the number of sizes are limited to 20 per config"
    }

    argParser.add_argument("CUCount", type=int, help=h["CUCount"])
    argParser.add_argument('--limit_num_sizes', '-l', action='store_true', help=h["limit_num_sizes"])
    return argParser.parse_args()

def generatePairs(n):
    pairs = []
    for a in range(1, int(n**0.5) + 1):
        if n % a == 0:
            b = n // a
            pairs.append((a, b))
            if a != b:
                pairs.append((b, a))
    pairs.sort(key=lambda x: abs(x[0] - x[1]))
    return pairs

def generateLatencyBoundSizes():
    values = [8, 16, 20, 24, 32, 36, 40]
    LB_SIZES = list(itertools.product(values, values, [1], values))
    LB_SIZES = [list(x) for x in LB_SIZES]

    M1N_sizes = list(itertools.product([1], values, [1], values))
    MN1_sizes = list(itertools.product(values, [1], [1], values))
    for x in MN1_sizes: LB_SIZES.append(x)
    for x in M1N_sizes: LB_SIZES.append(x)
    return LB_SIZES

def cleanUpList(a, numSizes = None):
    A = []
    for x in a:
        if x in A: continue
        A.append(x)
    if numSizes is not None and len(A) > numSizes:
        A = A[:numSizes]
    return A

def makeDir(outDir):
    try:
        os.makedirs(outDir)
    except OSError:
        pass
    return

def main(numCUs, num_sizes = None):
    tileLayouts = generatePairs(numCUs)
    #MI355 roofline model is used to design this macrotile.
    #Roofline model used to design the below macro tiles. Below macro tile with fixed K produces compute and memory bound GEMMs
    MTComputeBound = { 
                    "f16"  : [256, 256],
                    "bf16" : [256, 256],
                    "f32"  : [256, 256],
                    "bss"  : [256, 256],
                    "hss"  : [256, 256],
                    "f8f8s": [256, 256],
                    "f8hs" : [256, 256],
                    "tf32" : [256, 256]
                    }

    MTMemoryBound = { 
                    "f16"  : [32, 32],
                    "bf16" : [32, 32],
                    "f32"  : [32, 16],
                    "bss"  : [32, 32],
                    "hss"  : [32, 32],
                    "f8f8s": [32, 32],
                    "f8hs" : [32, 32],
                    "tf32" : [32, 16]                  
                    }

    rounds = [[1,1], [1,2], [2,1], [4,4], [2,2], [1,4], [4,1]] # [4,2], [2,4]

    K_CB = [2048, 4096, 8192, 16384]
    K_MB = [64, 128, 256, 512]

    #Support for BSS, HSS, F8F8S, F8HS, TF32
    dataType = ["f16", "bf16", "f32","bss","hss","f8f8s","f8hs","tf32"]
    
    SIZES_CB = {}
    SIZES_MB = {}
    SIZES_CB_B = {}
    SIZES_MB_B = {}
    SIZES_LB = {}

    granularity = [1, 0.85]
    B_list = [2, 8, 32, 128, 256, 512, 1024, 2048, 4096, 6144]

    for dt in dataType:
        SIZES_CB[dt] = []
        SIZES_CB_B[dt] = []
        SIZES_MB[dt] = []
        SIZES_MB_B[dt] = []
        for round in rounds:
            
            MT_CB = MTComputeBound[dt]
            MT_MB = MTMemoryBound[dt]

            for gran in granularity:
                for tileLayout in tileLayouts:
                    M = math.floor(MT_CB[0] * round[0] * tileLayout[0] * gran)
                    N = math.floor(MT_CB[1] * round[1] * tileLayout[1] * gran)
                    for K in K_CB: SIZES_CB[dt].append([M, N, 1, K])
                    for B in B_list:
                        if M*N/(256*256) >= numCUs*B: continue
                        for K in K_CB: SIZES_CB_B[dt].append([M, N, B, K])
                    M = math.floor(MT_MB[0] * round[0] * tileLayout[0] * gran)
                    N = math.floor(MT_MB[1] * round[1] * tileLayout[1] * gran)  
                    for K in K_MB: SIZES_MB[dt].append([M, N, 1, K])
                    for B in B_list:
                        if M*N/(256*256) >= numCUs*B: continue
                        for K in K_CB: SIZES_MB_B[dt].append([M, N, B, K])

        SIZES_LB[dt] = generateLatencyBoundSizes()
    combinedDict = {}
    size_type = {"MB": "Memory_Bound", "CB": "Compute_Bound", "LB": "Latency_Bound", "MB_B": "Memory_Bound_Batched", "CB_B": "Compute_Bound_Batched"}
    for d in dataType:
        size_dict = {}
        for t, t_name in size_type.items():
            size_dict[t_name] = cleanUpList(locals()[f"SIZES_{t}"][d], num_sizes) # globals()[dict_name]
        combinedDict[d] = size_dict

    transOrders = [["N","T"], ["T","T"],["T","N"],["N","N"]]
    gemmName = {"f16": "HHS", "f32": "SGEMM", "bf16": "BBS","bss":"BSS","hss":"HSS","f8f8s":"F8F8S","f8hs":"F8HS", "tf32":"TF32"}

    # Create
    outDir = "anchorSize_benchWorkload"
    makeDir(outDir)

    #Refer this file for index, hipBLASLt/tensilelite/Tensile/TensileInstructions/DataType.py
    nameToTypeIndex = {"f32": 0, "f16": 4, "bf16": 7, "bss": 4,"hss": 0,"f8f8s":11, "f8hs":11,"tf32":0}
    DestDataTypeIndex = {"f32": 0, "f16": 4, "bf16": 7, "bss": 0, "hss": 0,"f8f8s":11,"f8hs":4,"tf32":0}
    #Note: Later, tf32":0 => should be changed to 10, This needs changes in hipblaslt_benchInputCreator.py
    ComputeDataTypeIndex = {"f32": 0, "f16": 0, "bf16": 0, "bss": 0,"hss": 0,"f8f8s":0,"f8hs":0,"tf32":0}
    
    for transOrder in transOrders:
        for k,v in combinedDict.items():
            dataType = k
            for gemmType, sizeList in v.items():

                problem = {
                    "ComplexConjugateA": False,
                    "TransposeA": (transOrder[0] == "T"),
                    "ComplexConjugateB": False,
                    "TransposeB": (transOrder[1] == "T"),
                    "DataType": nameToTypeIndex[dataType],
                    "DestDataType": DestDataTypeIndex[dataType],
                    "ComputeDataType": ComputeDataTypeIndex[dataType],
                    "HighPrecisionAccumulate": (dataType != "f32"),
                }

                sizeMappings = []
                for i, size in enumerate(sizeList):
                    sizeMappings.append([size, [i, 0.0]])

                initialization = "trig"
                isGeneralBatched = False
                duration = 0.0
                outputfile = "hipblaslt_bench" + gemmName[dataType] + "_" + transOrder[0] + transOrder[1] + "_" + gemmType.split("_")[0]
                verify = True
                outDir_ = os.path.join(outDir, dataType + "_" + transOrder[0] + transOrder[1] + "_" + gemmType)
                makeDir(outDir_)
                createYaml(initialization, isGeneralBatched, duration, outDir_, outputfile, problem, sizeMappings, verify)

    ## Dump sizes into text file.
    f = open(os.path.join(outDir,'anchorSizes.txt'), 'w')

    for k,v in combinedDict.items():
        f.write("- %s\n"%(k))
        for K,V in v.items():
            f.write("  - %s\n"%(K))
            num_sizes_per_gran = len(V) / len(granularity)
            for idx, x in enumerate(V): 
                f.write("    - %s\n"%(str(x)))
                if (idx+1) % num_sizes_per_gran: continue
                f.write(f"    #granularity = {granularity[int(idx/num_sizes_per_gran)]}\n")

if __name__ == "__main__":
    args = parseArgs()
    numCUs = args.CUCount # get from args
    num_sizes = 20 if args.limit_num_sizes else None
    main(numCUs, num_sizes)