########################################################################################################################
#
# Copyright (C) 2025 Advanced Micro Devices, Inc. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
# Description ##########################################################################################################
# This script automatically adds/updates the required epilogues for a library logic.
# It can also be used to convert GEMMs (F8SS -> B8BS).
# 
# Usage ################################################################################################################
# Simply run
#       $python3 LibLogicManager.py libLogicWithoutEpilogue.yaml --outputPath outPath
# to create a liblogic in outPath directory from the original file with epilogues added.
#
# One can also use this script to first convert GEMMs and then add/update epilogues.
# For that, one need to run:
#       $python3 LibLogicManager.py libLogicWithoutEpilogue.yaml --convert F8BS --outputPath outPath
# which converts the original lib to F8BS, updates the epilogues, and stores the file in outPath.
#
# This script also supports rare epilogues such as [Aux, BiasSrcA/B, GG, Grad].
# To add those along with the other required epilogues, one can run:
#       $python3 LibLogicManager.py libLogicWithoutEpilogue.yaml --extraEpilogue GG --outputPath outPath
# to create library logic with GroupedGEMM (GG).
#
# To-Do ################################################################################################################
# 1. Add support for MI300 (F8 fnuz datatypes)
# 2. Clean up the constant section
# 3. Custom kernels should be treated differently
#
########################################################################################################################
import sys
import os
import argparse
from copy import deepcopy
import GEMM_DecoderEncoder
import yaml

# CONSTANTS ############################################################################################################
typeIndexToShortName = {
    0: "S", 
    4: "H", 
    7: "B"
}

typeIndexToNameTEMP = {
    0: ["f32_r", "f32_r"], 
    1: ["f64_r", "f64_r"], 
    4: ["f16_r", "f16_r"], 
    5: ["i8", "i8"], 
    6: ["i32", "i32"], 
    7: ["bf16_r", "bf16_r"], 
    10: ["f8_r", "f8_r"], 
    11: ["bf8_r", "bf8_r"], 
    12: ["f8_r", "bf8_r"], 
    13: ["bf8_r", "f8_r"],
    15: ["f8_r", "f8_r"], 
    16: ["bf8_r", "bf8_r"], 
    17: ["f8_r", "bf8_r"], 
    18: ["bf8_r", "f8_r"]
}

typeIndexToName = {
    0: "f32_r", 
    1: "f64_r", 
    4: "f16_r", 
    5: "i8", 
    6: "i32", 
    7: "bf16_r", 
    # 10: "f8_r", 
    # 11: "bf8_r", 
    # 12: "f8bf8_r", 
    # 13: "bf8f8_r",
    15: "f8_r", 
    16: "bf8_r", 
    17: "f8bf8_r", 
    18: "bf8f8_r"
}

nameToTypeIndex = {}
for key, value in typeIndexToName.items():
    nameToTypeIndex[value] = key
# ARG PARSER ###########################################################################################################
def parseArgs():
    argParser = argparse.ArgumentParser()

    argParser.add_argument("OriginalLibLogic",
                           help="The original library logic file path")
    argParser.add_argument("--extraEpilogue",
                           help="if we need an extra epilogue to be added to the lib. " \
                                "options are: Aux, BiasSrcA, BiasSrcB, GG (GroupedGemm), Grad")
    argParser.add_argument("--mode",
                           help="Mode is either convert or epilogue")
    argParser.add_argument("--outputType",
                           help="output type if we use --mode convert")
    argParser.add_argument("--outputPath",
                           help="output path")

    return argParser.parse_args()

# GRID CLASS ###########################################################################################################
class LibLogic:
    def __init__(self, libLogicPath):
        self._libLogicPath = libLogicPath
        print( "Reading the input lib logic yaml file..." )
        with open(self._libLogicPath) as l:
            self._lib = yaml.safe_load(l)
        print("Reading the input lib logic yaml file completed!")
        # Read the global problem type
        self._problemType = self._lib[4]

    ############################################################################################################
    def convertGEMM(self, outputType: str):
        problemType = self._problemType
        a_type, b_type, c_type, d_type, comp_type, inputA_type, inputB_type = GEMM_DecoderEncoder.decodeGEMMName(outputType)
        assert( c_type == d_type )
        # To handle `F8B8`BS and etc
        if a_type != b_type:
            a_type, _ = a_type.split('_')
            b_type, _ = b_type.split('_')
            a_type = b_type = a_type + b_type + '_r'
        problemType['DataType'] = nameToTypeIndex[a_type]
        if inputA_type and inputB_type:
            problemType['DataTypeA'] = nameToTypeIndex[inputA_type]
            problemType['DataTypeB'] = nameToTypeIndex[inputB_type]
        else:
            problemType['DataTypeA'] = nameToTypeIndex[a_type]
            problemType['DataTypeB'] = nameToTypeIndex[a_type]
        problemType['DataTypeE'] = nameToTypeIndex[d_type]
        problemType['DestDataType'] = nameToTypeIndex[d_type]


    ############################################################################################################
    def updateEpilogues(self, extraEpi: str):
        problemType = self._problemType

        # Activation
        problemType['Activation'] = 1

        # ActivationFuncCall
        problemType['ActivationFuncCall'] = 1
        
        # ActivationType
        problemType['ActivationType'] = 'hipblaslt_all'

        # To apply BiasDataTypeList, we need to find the output datatype
        if problemType['DestDataType'] == 0: #FP32
            biasList = [0]
        elif problemType['DestDataType'] == 4: #FP16
            biasList = [0, 4]
        elif problemType['DestDataType'] == 7: #BF16
            biasList = [0, 7]
        elif problemType['DestDataType'] > 7: #Any 1 byte datatype
            biasList = [0, 4, 7]
        problemType['BiasDataTypeList'] = biasList

        # UseBias
        problemType['UseBias'] = 1

        # BetaOnlyUseBias and UseScaleAB
        if problemType['DataType'] > 7: #Any 1 byte datatype
            problemType['BetaOnlyUseBias'] = 1
            problemType['UseScaleAB'] = 'Scalar'
        else:
            problemType['BetaOnlyUseBias'] = 0
            problemType['UseScaleAB'] = ''

        # UseScaleAlphaVec
        problemType['UseScaleAlphaVec'] = 1

        # For extra epilogues
        if extraEpi == 'Aux':
            problemType['UseE'] = 1
        elif extraEpi == 'BiasSrcA':
            problemType['BiasSrc'] = 'A'
            # This only works with gradient
            problemType['Gradient'] = 1
        elif extraEpi == 'BiasSrcB':
            problemType['BiasSrc'] = 'B'
            # This only works with gradient
            problemType['Gradient'] = 1
        elif extraEpi == 'GG':
            problemType['GroupedGemm'] = 1
        elif extraEpi == 'Grad':
            problemType['Gradient'] = 1
            # Since activation is always enabled, we should enable UseE
            problemType['UseE'] = 1

    ############################################################################################################
    def findNameFromProblemType(self) -> str:
        problemType = self._problemType
        # Layout
        outName = ''
        if not problemType['TransposeA'] and not problemType['TransposeB']: #NN
            outName += 'Cijk_Ailk_Bljk_'
        elif not problemType['TransposeA'] and problemType['TransposeB']: #NT
            outName += 'Cijk_Ailk_Bjlk_'
        elif problemType['TransposeA'] and not problemType['TransposeB']: #TN
            outName += 'Cijk_Alik_Bljk_'
        elif problemType['TransposeA'] and problemType['TransposeB']: #TT
            outName += 'Cijk_Alik_Bjlk_'

        # GEMM name
        inputA_type = typeIndexToNameTEMP[problemType['DataTypeA']][0]
        inputB_type = typeIndexToNameTEMP[problemType['DataTypeB']][0]
        a_type, b_type = typeIndexToNameTEMP[problemType['DataType']]
        c_type, d_type = typeIndexToNameTEMP[problemType['DestDataType']]
        comp_type = 'c_f32_r'
        if inputA_type == inputB_type == a_type:
            GEMMName = GEMM_DecoderEncoder.encodeGEMMName(a_type, b_type, c_type, d_type, comp_type)
        else:
            GEMMName = GEMM_DecoderEncoder.encodeGEMMName(a_type, b_type, c_type, d_type, comp_type, inputA_type, inputB_type)
        if 'GEMM' in GEMMName: # for SGEMM and DGEMM
            GEMMName = GEMMName.replace('GEMM', '')
            outName += GEMMName
            if problemType['Batched']:
                outName += 'B'
            outName += '_'
        else: # for other datatypes
            outName += GEMMName
            outName += '_'
            if problemType['Batched']:
                outName += 'B'
            if problemType['HighPrecisionAccumulate']:
                outName += 'H'
            outName += '_'

        # Bias
        if problemType['UseBias'] == 1:
            outName += 'Bias'
            for bias in problemType['BiasDataTypeList']:
                outName += typeIndexToShortName[bias]
            outName += '_'

        # Aux (UseE)
        if problemType['UseE'] == 1:
            outName += 'Aux_'
        
        # BiasSrc
        if problemType['BiasSrc'] == 'A':
            outName += 'BiasSrcA_'
        elif problemType['BiasSrc'] == 'B':
            outName += 'BiasSrcB_'

        # Grad
        if problemType['GroupedGemm'] == 1:
            outName += 'GG_'

        # Grad
        if problemType['Gradient'] == 1:
            outName += 'Grad_'

        # Activation
        if problemType['Activation'] == 1 and problemType['ActivationComputeDataType'] == 0:
            outName += 'HAS_'
        
        # ScalarAB
        if problemType['UseScaleAB'] == 'Scalar':
            outName += 'SAB_'
        elif problemType['UseScaleAB'] == 'Vector':
            outName += 'SABV_'

        # ScaleAlphaVec
        if problemType['UseScaleAlphaVec'] == 1:
            outName += 'SAV_'

        return outName

    ############################################################################################################
    def updateKernels(self):
        solutionID = 0
        name = self.findNameFromProblemType()
        for kernel in self._lib[5]:
            if 'BaseName' in kernel: # not all kernels have this field
                before, after = kernel['BaseName'].split('_UserArgs_')
                kernel['BaseName'] = name + 'UserArgs_' + after
            before, after = kernel['KernelNameMin'].split('_UserArgs_')
            kernel['KernelNameMin'] = name + 'UserArgs_' + after
            if 'ProblemType' in kernel:
                kernel['ProblemType'] = deepcopy(self._problemType)
            before, after = kernel['SolutionNameMin'].split('_UserArgs_')
            kernel['SolutionNameMin'] = name + 'UserArgs_' + after
            kernel['SolutionIndex'] = solutionID
            solutionID += 1

    ############################################################################################################
    def writeLibLogic(self, dir: str):
        def str_presenter(dumper, data):
            if data in ['hipblaslt_all', 'Scalar', 'Vector', 'A', 'B']:
                return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='')
            return dumper.represent_scalar('tag:yaml.org,2002:str', data)
        yaml.add_representer(str, str_presenter)
        
        outputPath = os.path.join(dir, self._lib[1] + '_' + self.findNameFromProblemType() + 'UserArgs.yaml')
        with open(outputPath, 'w') as outfile:
            yaml.safe_dump(self._lib, outfile, default_flow_style = None)


    
# Main #################################################################################################################
def main():
    args = parseArgs()
    libPath = args.OriginalLibLogic
    extraEpi = args.extraEpilogue
    mode = args.mode
    outPath = args.outputPath

    liblogic = LibLogic( libPath )
    if mode == 'convert':
        outputType = args.outputType
        liblogic.convertGEMM(outputType)
    liblogic.updateEpilogues(extraEpi)
    liblogic.updateKernels()
    liblogic.writeLibLogic(outPath)

########################################################################################################################
if __name__ == '__main__':
    main()
