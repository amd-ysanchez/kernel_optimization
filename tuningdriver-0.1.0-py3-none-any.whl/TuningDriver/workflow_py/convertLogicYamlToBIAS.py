# -*- coding: utf-8 -*-

#  convertLogicYamlToBIAS.py
#
#  This is to convert UserArg logic yaml to BIAS version
#
#  how to use
#   1 execute python program as follows
#     example (Ipython): %run convertLogicYamlToBIAS.py  input_file_name [reverse]
#
#   example) HHS TN
#     before file name: aquavanjaram_Cijk_Alik_Bljk_HHS_BH_UserArgs.yaml
#     after  file name: aquavanjaram_Cijk_Alik_Bljk_HHS_BH_Bias_AS_SAV_UserArgs.yaml
#
#  replace the following strings
replaceListAll = {}
replaceListAll['HHS'] = [\
# [before, after]
['Activation: false'        ,'Activation: true'], \
['ActivationFuncCall: true','ActivationFuncCall: false'], \
['ActivationType: none'     ,'ActivationType: hipblaslt_all'], \
['BiasDataTypeList: []'     ,'BiasDataTypeList: [0, 4]'], \
['UseBias: 0'               ,'UseBias: 1'], \
['UseScaleAlphaVec: false'  ,'UseScaleAlphaVec: true'], \
['UseScaleAlphaVec: 0'      ,'UseScaleAlphaVec: 1'], \
['_UserArgs'                ,'_BiasSH_HAS_SAV_UserArgs'] \
]
replaceListAll['BBS'] = [\
# [replaceListAll, after]
['Activation: false'        ,'Activation: true'], \
['ActivationFuncCall: true','ActivationFuncCall: false'], \
['ActivationType: none'     ,'ActivationType: hipblaslt_all'], \
['BiasDataTypeList: []'     ,'BiasDataTypeList: [0, 7]'], \
['UseBias: 0'               ,'UseBias: 1'], \
['UseScaleAlphaVec: false'  ,'UseScaleAlphaVec: true'], \
['UseScaleAlphaVec: 0'      ,'UseScaleAlphaVec: 1'], \
['_UserArgs'                ,'_BiasSB_HAS_SAV_UserArgs'] \
]

replaceListAll['HSS'] = [\
# [before, after]
['Activation: false'        ,'Activation: true'], \
['ActivationFuncCall: true','ActivationFuncCall: false'], \
['ActivationType: none'     ,'ActivationType: hipblaslt_all'], \
['BiasDataTypeList: []'     ,'BiasDataTypeList: [0, 4]'], \
['UseBias: 0'               ,'UseBias: 1'], \
['UseScaleAlphaVec: false'  ,'UseScaleAlphaVec: true'], \
['UseScaleAlphaVec: 0'      ,'UseScaleAlphaVec: 1'], \
['_UserArgs'                ,'_BiasSH_HAS_SAV_UserArgs'] \
]
replaceListAll['BSS'] = [\
# [replaceListAll, after]
['Activation: false'        ,'Activation: true'], \
['ActivationFuncCall: true','ActivationFuncCall: false'], \
['ActivationType: none'     ,'ActivationType: hipblaslt_all'], \
['BiasDataTypeList: []'     ,'BiasDataTypeList: [0, 7]'], \
['UseBias: 0'               ,'UseBias: 1'], \
['UseScaleAlphaVec: false'  ,'UseScaleAlphaVec: true'], \
['UseScaleAlphaVec: 0'      ,'UseScaleAlphaVec: 1'], \
['_UserArgs'                ,'_BiasSB_HAS_SAV_UserArgs'] \
]

replaceListAll['S_MX'] = [\
# [before, after]
['Activation: false'        ,'Activation: true'], \
['ActivationFuncCall: true','ActivationFuncCall: false'], \
['ActivationType: none'     ,'ActivationType: hipblaslt_all'], \
['BiasDataTypeList: []'     ,'BiasDataTypeList: [0]'], \
['UseBias: 0'               ,'UseBias: 1'], \
['BetaOnlyUseBias: false'   ,'BetaOnlyUseBias: true'], \
['UseScaleAlphaVec: false'  ,'UseScaleAlphaVec: true'], \
['UseScaleAlphaVec: 0'      ,'UseScaleAlphaVec: 1'], \
['_UserArgs'                ,'_BiasS_HAS_SAV_UserArgs'] \
]

replaceListAll['F8HS'] = [\
# [before, after]
['Activation: false'        ,'Activation: true'], \
['ActivationFuncCall: true','ActivationFuncCall: false'], \
['ActivationType: none'     ,'ActivationType: hipblaslt_all'], \
['BiasDataTypeList: []'     ,'BiasDataTypeList: [0, 4]'], \
['UseBias: 0'               ,'UseBias: 1'], \
['BetaOnlyUseBias: false'   ,'BetaOnlyUseBias: true'], \
['UseScaleAlphaVec: false'  ,'UseScaleAlphaVec: true'], \
['UseScaleAlphaVec: 0'      ,'UseScaleAlphaVec: 1'], \
['_UserArgs'                ,'_BiasSH_HAS_SAB_SAV_UserArgs'], \
['UseScaleAB: \'\''         , 'UseScaleAB: "Scalar"']
]

replaceListAll['F8BS'] = [\
# [before, after]
['Activation: false'        ,'Activation: true'], \
['ActivationFuncCall: true','ActivationFuncCall: false'], \
['ActivationType: none'     ,'ActivationType: hipblaslt_all'], \
['BiasDataTypeList: []'     ,'BiasDataTypeList: [0, 7]'], \
['UseBias: 0'               ,'UseBias: 1'], \
['BetaOnlyUseBias: false'   ,'BetaOnlyUseBias: true'], \
['UseScaleAlphaVec: false'  ,'UseScaleAlphaVec: true'], \
['UseScaleAlphaVec: 0'      ,'UseScaleAlphaVec: 1'], \
['_UserArgs'                ,'_BiasSB_HAS_SAB_SAV_UserArgs'], \
['UseScaleAB: \'\''         , 'UseScaleAB: "Scalar"']
]



replaceListAll['F8F8S'] = [\
# [before, after]
['Activation: false'        ,'Activation: true'], \
['ActivationFuncCall: true','ActivationFuncCall: false'], \
['ActivationType: none'     ,'ActivationType: hipblaslt_all'], \
['BiasDataTypeList: []'     ,'BiasDataTypeList: [0, 4, 7]'], \
['UseBias: 0'               ,'UseBias: 1'], \
# ['BetaOnlyUseBias: false'   ,'BetaOnlyUseBias: true'], \
['UseScaleAlphaVec: false'  ,'UseScaleAlphaVec: true'], \
['UseScaleAlphaVec: 0'      ,'UseScaleAlphaVec: 1'], \
['_UserArgs'                ,'_BiasSHB_HAS_SAV_UserArgs'], \
# ['UseScaleAB: \'\''         , 'UseScaleAB: "Scalar"']
]

replaceListAll['F8B8BS'] = [\
# [before, after]
['Activation: false'        ,'Activation: true'], \
['ActivationFuncCall: true','ActivationFuncCall: false'], \
['ActivationType: none'     ,'ActivationType: hipblaslt_all'], \
['BiasDataTypeList: []'     ,'BiasDataTypeList: [0, 7]'], \
['UseBias: 0'               ,'UseBias: 1'], \
['BetaOnlyUseBias: false'   ,'BetaOnlyUseBias: true'], \
['UseScaleAlphaVec: false'  ,'UseScaleAlphaVec: true'], \
['UseScaleAlphaVec: 0'      ,'UseScaleAlphaVec: 1'], \
['_UserArgs'                ,'_BiasSB_HAS_SAB_SAV_UserArgs'], \
['UseScaleAB: \'\''         , 'UseScaleAB: "Scalar"']
]

replaceListAll['B8F8BS'] = [\
# [before, after]
['Activation: false'        ,'Activation: true'], \
['ActivationFuncCall: true','ActivationFuncCall: false'], \
['ActivationType: none'     ,'ActivationType: hipblaslt_all'], \
['BiasDataTypeList: []'     ,'BiasDataTypeList: [0, 7]'], \
['UseBias: 0'               ,'UseBias: 1'], \
['BetaOnlyUseBias: false'   ,'BetaOnlyUseBias: true'], \
['UseScaleAlphaVec: false'  ,'UseScaleAlphaVec: true'], \
['UseScaleAlphaVec: 0'      ,'UseScaleAlphaVec: 1'], \
['_UserArgs'                ,'_BiasSB_HAS_SAB_SAV_UserArgs'], \
['UseScaleAB: \'\''         , 'UseScaleAB: "Scalar"']
]

replaceListAll['S'] = replaceListAll['S_MX']

supportTypes = replaceListAll.keys()

afterYamlList = {}
afterYamlList['BBS'] = afterYamlList['BSS'] = "_BiasSB_HAS_SAV_UserArgs.yaml"
afterYamlList['HHS'] = afterYamlList['HSS'] = "_BiasSH_HAS_SAV_UserArgs.yaml"
afterYamlList['S'] = afterYamlList['S_MX'] = "_BiasS_HAS_SAV_UserArgs.yaml"
afterYamlList['F8BS'] = "_BiasSB_HAS_SAB_SAV_UserArgs.yaml"
afterYamlList['F8HS'] = "_BiasSH_HAS_SAB_SAV_UserArgs.yaml"
afterYamlList['F8F8S'] = "_BiasSHB_HAS_SAV_UserArgs.yaml"
afterYamlList['F8B8BS'] = "_BiasSB_HAS_SAB_SAV_UserArgs.yaml"
afterYamlList['B8F8BS'] = "_BiasSB_HAS_SAB_SAV_UserArgs.yaml"


import sys
import re
import os
import shutil
import datetime

def replace_line(line, reverse, type):
   bef = 0
   aft = 1
   if reverse:
     bef = 1
     aft = 0
   if type in supportTypes:
     replaceList = replaceListAll[type]
     for item in replaceList:
         before = item[bef]
         after = item[aft]
         line = line.replace(before, after)
   return line

# main process starts from here
argvs = sys.argv
argc = len(argvs)

# parameter check
if (argc < 2):
    print ('Usage: # python %s input_file_name  [reverse]' % argvs[0])
    sys.exit(1)

in_file = argvs[1]

type = None
for t in supportTypes:
  if t in in_file:
    type = t
    break
if type == None:
    print ('Unsupported type' % argvs[0])
    sys.exit(1)

beforeYaml = "_UserArgs.yaml"
afterYaml  = afterYamlList[type]

reverse = False
if ("_Bias_" in in_file):
  reverse = True

# swap if it is reverse
if reverse:
  beforeYaml, afterYaml = afterYaml, beforeYaml

# file name check
if (beforeYaml not in in_file):
    print (f'ERROR: not {beforeYaml}')
    sys.exit(1)

outfile = in_file.replace(beforeYaml, afterYaml)

# open file
try:
    fin = open(argvs[1], 'r')
except:
    print ('Usage: %s is not found.' % argvs[1])
    quit()

lines = fin.readlines()
fin.close()

print(f'output file: {outfile}')
with open(outfile, 'w') as fw:
   for line in lines:
       new_line = replace_line(line, reverse, type)
       fw.write(new_line)

