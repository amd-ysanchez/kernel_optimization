import os
import pandas as pd
import io
import argparse

"""
A script to compare performance between reference and tuned hipblaslt-benchmark outputs.
Generates a CSV report with performance metrics and uplift calculations.

usage: generatePerformanceReport.py [-h] [--output_path OUTPUT_PATH] ref tuned

positional arguments:
  ref                   Reference hipblaslt-bench output
  tuned                 Tuned hipblaslt-bench output

options:
  -h, --help            show this help message and exit
  --output_path OUTPUT_PATH, -o OUTPUT_PATH
                        Output path
"""

PERF_COLS = ["hipblaslt-Gflops", "hipblaslt-GB/s", "us"]

def parse(file):
    """
    Parse hipBLASLt benchmark output file into a pandas DataFrame.
    
    Args:
        file (str): Path to the hipBLASLt benchmark output file
        
    Returns:
        pandas.DataFrame: DataFrame containing parsed benchmark results
        
    Raises:
        FileNotFoundError: If the input file doesn't exist
    """
    blocks = open(file).read().split('[0]:')[1:]
    header = blocks[0].split("\n")[0]
    data = [header] + [b.split("\n")[1].strip() for b in blocks]
    return pd.read_csv(io.StringIO("\n".join(data)))

def main(ref, tuned, output_path="perf_report.csv"):
    """
    Compare reference and tuned hipBLASLt benchmark results and generate a performance report.
    
    Args:
        ref (str): Path to reference benchmark output file
        tuned (str): Path to tuned benchmark output file
        output_path (str, optional): Path to save the output CSV report. Defaults to "perf_report.csv"
        
    Raises:
        ValueError: If either reference or tuned file paths are invalid
        
    The function:
    1. Loads and parses both benchmark files
    2. Merges the results on non-performance columns
    3. Calculates performance uplift percentage
    4. Saves the comparison report as CSV
    """
    if not os.path.isfile(ref):
        raise ValueError(f"{ref} not found")
    
    if not os.path.isfile(tuned):
        raise ValueError(f"{tuned} not found")
    
    df_ref = parse(ref)    
    df_tuned = parse(tuned)
    
    merge_cols = [c for c in df_ref.columns if c not in PERF_COLS]
    df = pd.merge(df_ref,
                  df_tuned, 
                  on=merge_cols, 
                  suffixes=(" (ref)", " (tuned)"))
    
    df["UPLIFT (%)"] = round(100 * (df_ref["us"] - df_tuned["us"]) / df_ref["us"], 3)
    
    df.to_csv(output_path, index=False)
    
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Generate performance report for the benchmark/tuned hipblaslt-bench outputs"
    )
    parser.add_argument("ref", help="Reference hipblaslt-bench output")
    parser.add_argument("tuned", help="Tuned hipblaslt-bench output")
    parser.add_argument("--output_path", "-o", help="Output path", default="perf_report.csv")
    args = parser.parse_args()
    
    main(args.ref, args.tuned, args.output_path)