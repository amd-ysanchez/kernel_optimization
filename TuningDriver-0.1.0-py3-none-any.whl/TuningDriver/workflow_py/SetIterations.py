################################################################################
#
# Copyright (C) 2016-2023 Advanced Micro Devices, Inc. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
################################################################################

# This script reads a configurartion benchmark file (rocBLAS or hipBLASLt) and its corresponding output, calculate the iterations based on latency(us) from the bench output, and updates the iteration for each GEMM. 

# Usage
# python3 SetIterations.py --input ./config.yaml --latency ./latency.log --output ./bench_new.yaml -d 3.0
# python3 SetIterations.py --input ./config.yaml --latency ./latency.log -d 3.0

import os
import argparse
import yaml

from yaml import SafeDumper as yamlDumper
from yaml import SafeLoader as yamlLoader

def parseBenchCofnig():
    argParser = argparse.ArgumentParser()

    h = {"inputfile": "input config bench file.",
         "latency": "input latency file (output of rocblas-bench or hipblaslt-bench). The length of data should be equal to the number of GEMMs, otherwise, it sets the iteration to default (9999).",
         "duration": "total benchmark duration in seconds for each GEMM. Default is 3.0.",
         "outputfile": "updated configuration benchmark with new iterations. Default is inputfile_itersUpdated.yaml",
        }

    argParser.add_argument("--input",            action="store", metavar="rocblas/hipblaslt-bench_inputfile", type=str, help=h["inputfile"])
    argParser.add_argument("--latency", "-u",    action="store", metavar="rocblas/hipblaslt-bench_outputfile", type=str, default='', help=h["latency"])
    argParser.add_argument("--duration", "-d",   action="store", metavar="latency of each GEMM benchmark", type=float, default = 3.0,  help=h["duration"])
    argParser.add_argument("--output",           action="store", metavar="updated rocblas/hipblaslt-bench", type=str, default = '', help=h["outputfile"])

    return argParser.parse_args()

def read_latency_file(latencyFile):
        latencyUS= open(latencyFile, 'r')
        Lines = latencyUS.readlines()
        latencyUS.close()
        time = []
        for line in Lines:
            out = line.strip().split(',')
            if out[0] == 'N' or out[0] == 'T':
                time.append(out[-1])
        print(f" Total number of items in the log file: {len(time)}")
        return time

def update_config_yaml(inputfile, duration, outputfile, time):
    benchfile = open(inputfile, 'r')
    configbench = yaml.load(benchfile, yamlLoader)
    benchfile.close()
    assert len(configbench) == len(time), f"The number of sizes in the config bench file ({len(configbench)}) does not match the log ({len(time)}) file."
        
    for bench in range(len(configbench)):
        iters = max(10,int(duration*1000000/float(time[bench])))
        configbench[bench]["iters"] = iters
        configbench[bench]["cold_iters"] = iters

    if outputfile == '':
        outputfile = os.path.splitext(inputfile)[0] +'_iters.yaml'
    print(f"output: {outputfile}")

    with open(outputfile, "w") as f:
        yaml.dump(configbench, f, yamlDumper, default_flow_style=None, sort_keys=False, width=5000)

def main():
    args = parseBenchCofnig()    

    if not os.path.isfile(args.input): 
       raise FileNotFoundError("{0} input file does not exist!".format(args.input))

    if not os.path.isfile(args.latency): 
       raise FileNotFoundError("{0} latency file does not exist!".format(args.input))

    time = read_latency_file(args.latency)

    update_config_yaml(args.input, args.duration, args.output, time)

    print("Done!")

if __name__ == "__main__":
    main()
