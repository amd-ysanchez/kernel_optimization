################################################################################
#
# Copyright (C) 2016-2025 Advanced Micro Devices, Inc. All rights reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
################################################################################

# This script reads any of hipblaslt log (either hipblaslt_LAYER=2 or hipblaslt_LAYER=4), and summarizes the sizes based on GEMM types.
# It covers BF8F8,F8BF8,F8F8/I8/HHS/HSS/BBS/BSS/SGEMM/DGEMM/CGEMM/ZGEMM.

# Usage
# python3 /path/to/hipblaslt-parser.py --input /path/to/hipblaslt.log

# For F8 -> <A_TYPE><B_TYPE><C_TYPE><D_TYPE><COMPUTE_TYPE>

import os
import argparse
import yaml
from yaml import SafeDumper as yamlDumper
import GEMM_DecoderEncoder
import re
import csv

def parseBenchCofnig():
    argParser = argparse.ArgumentParser()

    h = {'inputfile':  'Input file',
         'outputfile': 'Output file containing the summary of all GEMM sizes. Default name is {inputfilename}_summary.txt',
         'verify':     'Add the verification arguments to the hipblaslt-bench input yaml file',
         'bench':      'Create the input yaml file for hipblaslt-bench. Default name is {inputfilename}_bench.yaml',
         'initial':    'Matrix initialization: hpl, trig, int. The default is trig for non Int8 datatype, and int for Int8.'
         }

    argParser.add_argument('--input', action='store', metavar='hipblaslt_log-file', type=str, help=h['inputfile'])
    argParser.add_argument('--output', action='store', metavar='output-dir', type=str, help=h['outputfile'],
                           required=False, default=None)
    argParser.add_argument('--bench', '-b', action='store', metavar='hipblaslt-bench', type=str,
                           required=False, default=None, help=h['bench'])
    argParser.add_argument('--verify', '-v', action='store_true', help=h['verify'])
    argParser.add_argument('--initialization', '-i', action='store', metavar='hpl/trig/int', type=str, default='trig', help=h['initial'])

    return argParser.parse_args()

def parse_log_by_line(line, blas_layer):
    params = {}

    if blas_layer == 2:
        tokens = line.strip().split()
        key = None
        for token in tokens:
            if token.startswith("--") or token.startswith("-"):
                key = token.lstrip("-")
            elif key:
                params[key] = token
                key = None

        newSize = (
            int(params.get("m", 0)),
            int(params.get("n", 0)),
            int(params.get("batch_count", 1)),
            int(params.get("k", 0)),
        )
        callCount = 1
        projNum = 0

    elif blas_layer == 4:
        line = line.strip().lstrip("- {").rstrip("}")
        tokens = line.split(", ")
        for token in tokens:
            key_value = token.split(": ", 1)
            if len(key_value) == 2:
                key, value = key_value
                params[key.strip()] = value.strip()

        newSize = (
            int(params.get("M", 0)),
            int(params.get("N", 0)),
            int(params.get("batch_count", 1)),
            int(params.get("K", 0)),
        )
        callCount = int(params.get("call_count", 1))
        projNum = float(params.get("proj_num", 0))

    return params, newSize, callCount, projNum

def process_hipblaslt_log(filename):
    gemmSizes = {}
    duplicateGemmSizesTracker = {}

    count = 0  # total size in the file
    duplicate_count = 0

    with open(filename, 'r') as config:
        Lines = config.readlines()

    # Strips the newline character
    for line in Lines:
        count += 1

        if 'hipblaslt-bench' in line:
            blas_layer = 2
        elif line.strip().startswith('- {'):
            blas_layer = 4
        else:
            # Skip lines that don't match either format
            print(f'Invalid format detected. Skipping line: {line.strip()}')
            continue

        # Parse the line
        try:
            params, newSize, callCount, projNum = parse_log_by_line(line, blas_layer)
        except Exception as e:
            print(f'Error parsing line: {line.strip()}')
            raise e

        scale_type = params.get('scale_type', 'f32_r')
        grouped_gemm = params.get('grouped_gemm', 'false')
        a_type = params.get('a_type', '')
        b_type = params.get('b_type', '')
        c_type = params.get('c_type', '')
        d_type = params.get('d_type', '')
        compute_type = params.get('compute_type', '')
        transA = params.get('transA', '')
        transB = params.get('transB', '')
        batch_count = int(params.get('batch_count', 1))
        scaleA = params.get('scaleA', '')
        scaleB = params.get('scaleB', '')

        # Determine the gemmtype
        if scale_type != 'f32_r':
            raise NotImplementedError(f'scale_type: {scale_type}')

        if grouped_gemm != 'false':
            raise NotImplementedError(f'grouped_gemm: {grouped_gemm}')

        gemmtype = GEMM_DecoderEncoder.encodeGEMMName(a_type, b_type, c_type, d_type, compute_type)

        if params.get('transA', 'N') == 'N' and params.get('transB', 'N') == 'N':
            gemmtype += '_NN'
        elif params.get('transA', 'N') == 'N' and params.get('transB', 'N') == 'T':
            gemmtype += '_NT'
        elif params.get('transA', 'N') == 'T' and params.get('transB', 'N') == 'N':
            gemmtype += '_TN'
        elif params.get('transA', 'N') == 'T' and params.get('transB', 'N') == 'T':
            gemmtype += '_TT'

        gemmtype += ' ('
        gemmtype += f'IsBatched:{True if batch_count > 1 else False}, '
        gemmtype += f'ScaleType:{scale_type}, ScaleA:{scaleA}, ScaleB:{scaleB}'
        gemmtype += ')'
        
        if gemmtype not in gemmSizes:
            gemmSizes[gemmtype] = {}
            duplicateGemmSizesTracker[gemmtype] = {}

        if newSize not in gemmSizes[gemmtype]:
            gemmSizes[gemmtype][newSize] = (callCount, projNum)
            duplicateGemmSizesTracker[gemmtype][newSize] = 0
        else:
            duplicate_count += 1
            prev_call, prev_proj = gemmSizes[gemmtype][newSize]
            gemmSizes[gemmtype][newSize] = (prev_call + callCount, prev_proj + projNum)
            duplicateGemmSizesTracker[gemmtype][newSize] += 1

    # Sorting
    for gemmtype in gemmSizes:
        gemmSizes[gemmtype] = [(size[0], size[1], size[2], size[3], call_proj[0], call_proj[1])
                               for size, call_proj in gemmSizes[gemmtype].items()]
        gemmSizes[gemmtype].sort(key=sortfuc)

    return [gemmSizes, count, duplicate_count, duplicateGemmSizesTracker]

def sortfuc(size):
    return (size[0], size[1], size[3], size[2]) # M, N, batch_count, K

def createOutput(filename, gemmSizes, count, duplicate_count, duplicateGemmSizesTracker):
    count_unique = 0
    with open(filename, 'w') as f:
        f.write(f'\n -- total bench in the file: {count} - duplicates: {duplicate_count}')

        for gemmtype in gemmSizes:
            f.write(f'\n\n--- {gemmtype} (with duplicates): {len(gemmSizes[gemmtype])} \n')
            for size in gemmSizes[gemmtype]:
                gemmconfig = f' - [{str(size[0]).rjust(6)}, {str(size[1]).rjust(6)}, {str(size[2]).rjust(6)}, {str(size[3]).rjust(6)}]'
                gemmconfig += f' # call_count: {size[4]}'

                duplicate_count_for_size = duplicateGemmSizesTracker[gemmtype].get(size[:4], 1)
                if duplicate_count_for_size > 0:
                    gemmconfig += f', duplicate_count: {duplicate_count_for_size}'

                gemmconfig += '\n'

                f.write(gemmconfig)
            print(f"{gemmtype} # {len(gemmSizes[gemmtype])} sizes")
        f.write(f'\n -- total unique is: {count - duplicate_count}')

    # Write the CSV file
    csv_filename = filename.replace('.txt', '.csv')
    csv_columns = [
        "transA", "transB", "batch_count", "m", "n", "k",
        "a_type", "b_type", "c_type", "d_type", "compute_type", "call_count"
    ]
    csv_rows = []
    for gemmtype in gemmSizes:
        match = re.match(r'^([^\s(]+)', gemmtype)
        if match:
            gemmname = match.group(1)
        else:
            gemmname = gemmtype
        gemmname, _ = gemmname.rsplit('_', 1)
        a_type, b_type, c_type, d_type, compute_type = GEMM_DecoderEncoder.decodeGEMMName(gemmname)
        transA = 'N'
        transB = 'N'
        if '_NN' in gemmtype:
            transA = 'N'
            transB = 'N'
        elif '_NT' in gemmtype:
            transA = 'N'
            transB = 'T'
        elif '_TN' in gemmtype:
            transA = 'T'
            transB = 'N'
        elif '_TT' in gemmtype:
            transA = 'T'
            transB = 'T'
        for size in gemmSizes[gemmtype]:
            m, n, batch_count, k, call_count, _ = size
            row = {
                "transA": transA,
                "transB": transB,
                "batch_count": batch_count,
                "m": m,
                "n": n,
                "k": k,
                "a_type": a_type,
                "b_type": b_type,
                "c_type": c_type,
                "d_type": d_type,
                "compute_type": compute_type,
                "call_count": call_count
            }
            csv_rows.append(row)

    csv_rows.sort(key=lambda x: x['call_count'], reverse=True)

    with open(csv_filename, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=csv_columns)
        writer.writeheader()
        writer.writerows(csv_rows)
    print(f"CSV summary written to {csv_filename}")

def create_hipblaslt_bench(benchFile, gemmSizes, verify, initialization):
    bench = []
    print(f'Creating {benchFile} for below GEMM types...')
    for gemmtype in gemmSizes:
        # get GEMM function type: a/b/c/d/compute_type
        problemDict = {}
        problemDict['function'] = 'matmul'

        match = re.match(r'^([^\s(]+)', gemmtype)
        if match:
            gemmname = match.group(1)
        else:
            gemmname = gemmtype
        gemmname, _ = gemmname.rsplit('_', 1)

        problemDict['a_type'], problemDict['b_type'], problemDict['c_type'], problemDict['d_type'], \
            problemDict['compute_type'] = GEMM_DecoderEncoder.decodeGEMMName(gemmname)

        # Regular expressions to extract Scale related parameters
        scale_type_match = re.search(r'ScaleType:([a-zA-Z0-9_]+)', gemmtype)
        scaleA_match = re.search(r'ScaleA:([a-zA-Z0-9_]+)', gemmtype)
        scaleB_match = re.search(r'ScaleB:([a-zA-Z0-9_]+)', gemmtype)
        scale_type = scale_type_match.group(1) if scale_type_match else None
        scaleA = int(scaleA_match.group(1)) if scaleA_match else 0
        scaleB = int(scaleB_match.group(1)) if scaleB_match else 0

        problemDict['scale_type'] = problemDict['bias_type'] = scale_type
        problemDict['scaleA'] = scaleA
        problemDict['scaleB'] = scaleB

        # get GEMM function and matrix orientation: transA/B, a/b/c/d/compute_type
        if ('NN' in gemmtype):
            problemDict['transA'] = 'N'
            problemDict['transB'] = 'N'
        elif ('NT' in gemmtype):
            problemDict['transA'] = 'N'
            problemDict['transB'] = 'T'
        elif ('TN' in gemmtype):
            problemDict['transA'] = 'T'
            problemDict['transB'] = 'N'
        elif ('TT' in gemmtype):
            problemDict['transA'] = 'T'
            problemDict['transB'] = 'T'

        otherParams = {'alpha': 1, 'beta': 0, 'stride_a': 0, 'stride_b': 0, 'stride_c': 0, 'stride_d': 0, 'rotating': 512, 'flush': 1, 'iters': 10, 'cold_iters': 10, 'print_kernel_info': 1, 'use_gpu_timer': 1}

        # initialization
        if (initialization == 'hpl'):
            init = {'initialization': 'hpl'}
        elif (initialization == 'trig'):
            init = {'initialization': 'trig_float'}
        elif initialization == 'int':
            init = {'initialization': 'rand_int'}

        # # check if the library is General Batched based on the library name
        # generalBatched = True if '_GB.yaml' in os.path.split(args.libLogic)[-1] else False

        # create hipblaslt-bench call for each size
        for size in gemmSizes[gemmtype]:

            sizeDict = {}

            sizeDict['M'] = size[0]
            sizeDict['N'] = size[1]
            sizeDict['K'] = size[3]
            sizeDict['batch_count'] = size[2]

            if ('NN' in gemmtype):
                sizeDict['lda'] = sizeDict['M']
                sizeDict['ldb'] = sizeDict['K']
            elif ('TN' in gemmtype):
                sizeDict['lda'] = sizeDict['K']
                sizeDict['ldb'] = sizeDict['K']
            elif ('NT' in gemmtype):
                sizeDict['lda'] = sizeDict['M']
                sizeDict['ldb'] = sizeDict['N']
            elif ('TT' in gemmtype):
                sizeDict['lda'] = sizeDict['K']
                sizeDict['ldb'] = sizeDict['N']

            sizeDict['ldc'] = sizeDict['M']
            sizeDict['ldd'] = sizeDict['M']

            params = {}
            params.update(problemDict)
            params.update(sizeDict)
            params.update(init)
            params.update(otherParams)

            call_count = {'call_count': size[4]}
            params.update(call_count)

            if size[5] != 0:
                proj_num = {'proj_num': size[5]}
                params.update(proj_num)

            if verify:
                verifyParams = {'norm_check': 1, 'norm_check_assert': 0}
                params.update(verifyParams)

            bench.append(params)

        # write output
        with open(benchFile, 'w') as f:
            if len(bench) > 0:
                yaml.dump(bench, f, yamlDumper, default_flow_style=None, sort_keys=False, width=5000)


def main():
    args = parseBenchCofnig()

    # Extract the base name of the input file without the extension
    input_file_base_name = os.path.splitext(os.path.basename(args.input))[0]

    # Set default output and bench file names
    output = args.output or f'{input_file_base_name}_summary.txt'
    bench = args.bench or f'{input_file_base_name}_bench.yaml'


    # check if input exists
    if not os.path.isfile(args.input):
        raise FileNotFoundError('{0} input file does not exist!'.format(args.input))

    print(f'Processing {args.input}...')
    gemmSizes, count, duplicate_count, duplicateGemmSizesTracker = process_hipblaslt_log(args.input)

    createOutput(output, gemmSizes, count, duplicate_count, duplicateGemmSizesTracker)

    verify = True if args.verify else False
    create_hipblaslt_bench(bench, gemmSizes, verify, args.initialization)

    print('Done!')


if __name__ == '__main__':
    main()