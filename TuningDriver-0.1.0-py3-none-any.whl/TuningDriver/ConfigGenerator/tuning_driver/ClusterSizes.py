"""
This file has clustering algorithms implemented.
Note - Limited to generating groups. 
"""
import math
import numpy as np
import functools

'''
Parth Algo ---->
For each size, generate a feature vector for all (MT0,MT1,GSU,LSU) using compute_score function.
compute_score(size | (MT0,MT1,GSU,LSU)) = 10/round + totalGran
Note - round = math.ceil(tilePerCu)
Intuition - Lower round preferred. If same see totalGranularity (higher is preferred)
Cluster similar sizes based on a similarity score between 2 sizes. 
Similarity score - normalized_dot_product
Similarity Threshold - SIM_THRESHOLD
'''


def get_group_idx_MIs(groups):
    # Helper function to get the index corresponding
    # to MIs in the list of groups.
    for idx in range(len(groups[0])):
        g = groups[0][idx][-1]
        if "MatrixInstruction" in g.keys():
            return idx
    return -2

# This section generates the clusters from the feature matrix


def normalized_dot_product(vector_a, vector_b):
    # Calculate the dot product
    dot_product = np.dot(vector_a, vector_b)

    # Calculate the magnitudes of the vectors
    magnitude_a = np.linalg.norm(vector_a)
    magnitude_b = np.linalg.norm(vector_b)

    # Calculate the normalized dot product
    normalized_dot_product = dot_product / ((magnitude_a * magnitude_b) + 1e-10)
    return normalized_dot_product


def compute_similarity(feature_matrix, i, j):
    return normalized_dot_product(feature_matrix[i][:], feature_matrix[j][:])


SIM_THRESHOLD = 0.98


def generate_clusters_from_feature_matrix(feature_matrix, size_list):
    norms = np.linalg.norm(feature_matrix, axis=1, keepdims=True) + 1e-10
    feature_matrix = feature_matrix / norms

    size_list = np.array(size_list)

    num_size = size_list.shape[0]
    clustered = []
    clusters = {}

    for i in range(num_size):
        if i in clustered:
            continue
        seed_idx = i
        clusters[len(clusters)+1] = [seed_idx]
        for j in range(i+1, num_size):
            if j in clustered:
                continue
            sim_score = compute_similarity(feature_matrix, i, j)
            if sim_score < SIM_THRESHOLD:
                continue
            clustered.append(j)
            clusters[len(clusters)].append(j)

    clusters = dict(sorted(clusters.items(), key=lambda item: -len(item[1])))
    return clusters

# This section generates features


def compute_granularities(size, MT, LSU, GSU, CUs, wave):
    M, N, batch_count, K = size
    MT0, MT1 = MT

    NumTile0 = M / MT0
    NumTile1 = N / MT1

    Tile0Granularity = NumTile0/math.ceil(NumTile0)
    Tile1Granularity = NumTile1/math.ceil(NumTile1)

    TotalTiles = math.ceil(NumTile0) * math.ceil(NumTile1) * batch_count * LSU * GSU

    TilesPerCU = TotalTiles / CUs
    CUGranularity = TilesPerCU / math.ceil(TilesPerCU)

    SIMDPerCU = 4  # TODO - pk - HW dependent, pass it via config
    waveGranularity = min(1.0, math.floor(NumTile0) * math.floor(TilesPerCU+1.0) * wave[0]*wave[1]*LSU / SIMDPerCU)
    # waveGranularity = min (1.0, math.floor(NumTile0) * math.floor(TilesPerCU+1.0) * workGroupSize.x * workGroupSize.y * workGroupSize.z/ WaveFrontSize/SIMDPerCU)
    totalGranularity = Tile0Granularity * Tile1Granularity * CUGranularity * waveGranularity

    return totalGranularity, TilesPerCU


def compute_score(size, MT, LSU, GSU, wave, CUs):
    totalGran, tilePerCu = compute_granularities(size, MT, LSU, GSU, CUs, wave)
    return 10/math.ceil(tilePerCu) + totalGran

# TODO - pk functions repeated from MIDesign. import.


@functools.lru_cache(maxsize=256)
def compute_MT(MI):
    wave = MI[7], MI[8]
    MIBlockM = MI[4]
    waveTileM, waveTileN = MI[5], MI[6]

    MatrixInstM = MI[0] * MIBlockM
    MT0 = MatrixInstM * waveTileM * wave[0]

    MatrixInstN = MI[1] / MIBlockM * MI[3]
    MT1 = int(MatrixInstN * waveTileN * wave[1])
    return tuple([MT0, MT1])


def featurize_sizes(size_list, param_list, CUs):
    feature_matrix_dict = {}
    feature_keys = []
    for idx, size in enumerate(size_list):
        _sz_key = tuple(size)
        feature_matrix_dict[_sz_key] = {}
        params = param_list[idx]
        groups = params["Groups"].get_val()
        mi_group_idx = get_group_idx_MIs(groups)
        for mi_group in groups[0][mi_group_idx]:

            mi = mi_group["MatrixInstruction"].get_val() + [1, 1]
            if "WorkGroup" in mi_group.keys():
                mi[-2] = mi_group["WorkGroup"].get_val()[-1]
            if "GlobalSplitU" in mi_group.keys():
                mi[-1] = mi_group["GlobalSplitU"].get_val()[-1]

            MT = compute_MT(tuple(mi))
            score = compute_score(size, MT, mi[-2], mi[-1], [mi[7], mi[8]], CUs)

            _ft_key = tuple([MT[0], MT[1], mi[-2], mi[-1], mi[7], mi[8]])
            if _ft_key not in feature_keys:
                feature_keys.append(_ft_key)
            feature_matrix_dict[_sz_key][_ft_key] = score

    feature_matrix = []

    for idx, size in enumerate(size_list):
        _sz_key = tuple(size)
        feature_row = []
        for feature in feature_keys:
            if feature in feature_matrix_dict[_sz_key]:
                feature_row.append(feature_matrix_dict[_sz_key][feature])
            else:
                score = compute_score(size, (feature[0], feature[1]), feature[-4],
                                      feature[-3], [feature[-2], feature[-1]], CUs)
                feature_row.append(score)
        feature_matrix.append(feature_row)

    feature_matrix = np.array(feature_matrix)
    return feature_matrix


def cluster_sizes_pk(size_list, param_list, CUs):
    feature_matrix = featurize_sizes(size_list, param_list, CUs)
    clusters = generate_clusters_from_feature_matrix(feature_matrix, size_list)
    return clusters


def reorder_sizes_in_cluster(clusters, size_list):
    """
    Cluster - Cluster ids mapped to size_idx
    """
    for cluster_id, cluster_sizes in clusters.items():
        clusters[cluster_id] = sorted(cluster_sizes, key=lambda idx: (
            size_list[idx][0]*size_list[idx][1], size_list[idx][0], size_list[idx][1]))
    return clusters


'''
Babak Algo ----> 
Use the most performant (MT0,MT1,LSU,GSU) for the size to identify it's cluster.
'''


def cluster_sizes_bbk(size_list, param_list, CUs):
    clusters = {}
    for idx, size in enumerate(size_list):
        groups = param_list[idx]["Groups"].get_val()
        mi_group_idx = get_group_idx_MIs(groups)
        if len(groups[0][mi_group_idx]):
            mi_group = groups[0][mi_group_idx][0]
            mi = mi_group["MatrixInstruction"].get_val() + [1, 1]
            if "WorkGroup" in mi_group.keys():
                mi[-2] = mi_group["WorkGroup"].get_val()[-1]
            if "GlobalSplitU" in mi_group.keys():
                mi[-1] = mi_group["GlobalSplitU"].get_val()[-1]
            MT = compute_MT(tuple(mi))
            LSU, GSU = mi[-2], mi[-1]
            cluster_id = tuple([MT[0], MT[1], LSU, GSU])
        else:
            # size with no mi generated.
            cluster_id = tuple([0, 0, 0, 0])

        if cluster_id not in clusters.keys():
            clusters[cluster_id] = []

        clusters[cluster_id].append(idx)
    return clusters

# Main function called to cluster sizes.


def doCluster(param_list, size_list, CUs, cluster_algo=1):

    # 1.Get cluster of sizes.
    # clusters - dict with key as cluster index and list of sizes as values
    if cluster_algo == 1:
        print("Using clustering algo from Parth")
        clusters = cluster_sizes_pk(size_list, param_list, CUs)
    else:
        print("Using clustering algo from Babak")
        clusters = cluster_sizes_bbk(size_list, param_list, CUs)

    # reorder sizes per cluster
    clusters = reorder_sizes_in_cluster(clusters, size_list)

    return clusters
