from Constants import dataSize
from copy import deepcopy
from ParameterFactory import ParameterFactory
import Parameter
import os

GA_FORK_PARAMS = {
    "1LDSBuffer": [0, 1],
    "WaveSeparateGlobalReadA": [0],
    "WaveSeparateGlobalReadB": [0],
    "NumElementsPerBatchStore": [0, 2, 4, 8, 10, 12, 14, 16],
    "NonTemporalA": [0, 1, 2, 3, 4, 5, 6, 7],  # [0, 1, 4, 7]
    "NonTemporalB": [0, 1, 2, 3, 4, 5, 6, 7],  # [0, 4]
    "NonTemporalC": [0, 1, 2, 3, 4, 5, 6, 7],  # [0, 3, 4]
    "NonTemporalD": [0, 1, 2, 3, 4, 5, 6, 7],  # [0, 3, 4, 7]
    "PrefetchGlobalRead": [1, 2],
    "PrefetchLocalRead": [1],
    "SourceSwap": [0, 1],
    "StaggerU": [0, 8, 16],  # TODO check for MI350
    "StaggerUStride": [64, 128, 256, 512],  # TODO check for MI350
    "StorePriorityOpt": [0, 1],
    "StoreSyncOpt": [0, 1, 4],
    "WorkGroupMapping": [-48, -32, -24, -16, -8, -6, -4, -2, -1, 0, 1, 2, 4, 6, 8, 16, 24, 32, 48],
    "WorkGroupMappingXCC": [1, 2, 4, 8, 16],
    "MIArchVgpr": [0, 1],
    "TransposeLDS": [-1, 0, 1, 2],
    "GlobalSplitUAlgorithm": ["MultipleBuffer"],
    "StreamKXCCMapping": [0, 4, 5, 6, 7, 8],  # TODO [0, 8]
    "UseSgprForGRO": [-1, 0, 1],
    "DirectToLds": [0, 1],
}


def calc_iters(m, n, b, k): 
    return max(round((-(m + n + k) * 0.015 + 431) / b), 5)

def updateGRVW(params, dataType, valid=(1, 2, 3, 4, 6, 8, 16)):
    dsz = dataSize[dataType]
 
    min_grvw = max(1, int(4 / dsz))
    max_grvw = min(max(valid), int(16 / dsz))
 
    grvw = [-1, -2] + list(valid[valid.index(min_grvw):valid.index(max_grvw)+1])
    
    params.update(dict(GlobalReadVectorWidthA=list(grvw),
                       GlobalReadVectorWidthB=list(grvw)))


def updateWGMXCC(params, nCUs):
    if nCUs == 256 and 'WorkGroupMappingXCC' in params:
        params['WorkGroupMappingXCC'].append(32)

    # TODO other configurations, now only for 308 and 256 #CUs


def updateDTVA(params, nCUs, transA):
    if nCUs != 256 and not transA:
        params.update({"DirectToVgprA": [0, 1]})


def removeNegWGM(params):
    if 'WorkGroupMapping' in params:
        params['WorkGroupMapping'] = [v for v in params['WorkGroupMapping'] if v >= 0]


def populateParam(name, values):
    try:
        p = getattr(Parameter, f'Param_{name}')()[name]
    except AttributeError:
        # TODO default values and range
        p = ParameterFactory.create_parameter_class(name, default_value=values)()[name]
    p._value = values
    p._isCommented = False
    return p


def getGroups(params, allGroups, transA, transB, param_factory):
    MIs = [g for g in allGroups.get_val()[0] if "MatrixInstruction" in g[0]]
    groups = MIs

    # TODO check this logic
    if not (transA and not transB):
        clr_ldsti_0 = {'ClusterLocalRead': populateParam('ClusterLocalRead', 0),
                       'LDSTrInst':  populateParam('LDSTrInst', 1)}
        clr_ldsti_1 = {'ClusterLocalRead': populateParam('ClusterLocalRead', 1),
                       'LDSTrInst':  populateParam('LDSTrInst', 0)}
        groups += [[clr_ldsti_0, clr_ldsti_1]]
    else:
        params.update({"ClusterLocalRead": [0, 1]})

    return (groups, )


def updateGAForkParameters(allParams, dataType, nCUs, transA, transB):
    params = deepcopy(GA_FORK_PARAMS)
    param_factory = ParameterFactory()

    params['DepthU'] = allParams['DepthU'].get_val()
    updateGRVW(params, dataType)
    updateWGMXCC(params, nCUs)
    updateDTVA(params, nCUs, transA)

    isStreamK = False
    if 'StreamK' in allParams:
        sk = allParams["StreamK"].get_val()
        isStreamK = sk[0] != 0 or len(sk) > 1
        params['StreamK'] = sk

    if isStreamK:
        removeNegWGM(params)  # TODO remove when fixed
    else:
        if 'StreamK' in params:
            del params['StreamK']
        if 'StreamKXCCMapping' in params:
            del params['StreamKXCCMapping']
        if 'UseSgprForGRO' in params:
            del params['UseSgprForGRO']

    params['Groups'] = getGroups(params, allParams['Groups'], transA, transB, param_factory)

    finalParams = {k: populateParam(k, v) for k, v in sorted(params.items()) if k != 'Groups'}
    finalParams['Groups'] = populateParam('Groups', params['Groups'])
    return finalParams


def updateGASections(allParams, cur_wd, config_name, sizes, soo=False):

    allParams['GlobalParameters']['SleepPercent'] = 50

    iters = max(calc_iters(*sz) for sz in sizes)
    allParams["GlobalParameters"]["EnqueuesPerSync"] = max(iters, allParams["GlobalParameters"]["EnqueuesPerSync"])
    allParams["GlobalParameters"]["NumWarmups"] = max(iters, allParams["GlobalParameters"]["EnqueuesPerSync"])

    allParams['ductile'] = dict(log_file=os.path.join(os.path.abspath(cur_wd), f'{config_name}-optimization.log'),
                                soo=soo)
