import sys
import re
def parseVar(msplt):
    ret = {}
    for _s in msplt:
        eq_split = _s.split('=')
        ret[eq_split[0]] = eq_split[1]
    return ret
def parseAlphaBeta(line):
    alpha_string = alpha_params_regex.search(line).group(0)
    beta_string = beta_params_regex.search(line).group(0)
    ret = {}

    alpha_split = alpha_string.split('=')
    beta_split = beta_string.split('=')

    ret[alpha_split[0]] = alpha_split[1]
    ret[beta_split[0]] = beta_split[1]

    return ret

def convertType(desc):
    if "8F" in desc:
        return "f8_r"
    elif "16F" in desc:
        return "f16_r"
    elif "32F" in desc:
        return "f32_r"
    elif "8I" in desc:
        return "i8_r"
    elif "32I" in desc:
        return "i32_r"

initial_params_regex = re.compile(r'\[(.*?)\]')
alpha_params_regex = re.compile(r'alpha=[0-9]')
beta_params_regex = re.compile(r'beta=[0-9]')
sanity_check_regex = re.compile(r'Processed')

if (len(sys.argv) < 2):
    print("usage: python3 hipblaslt-utility-log-parser.py <filename>")
    exit(-1)

with open(sys.argv[1], encoding="utf-8") as f:
    for line in f:
        if (len(line) < 3):
            continue
        sanity = sanity_check_regex.search(line)

        alpha_beta = parseAlphaBeta(line)
        iter = initial_params_regex.finditer(line)
        i = 0
        if (sanity != None):
            i = -1
        for mval in iter:
            # print(val.group(0))
            mstr = mval.group(0)
            if i == 5:
                #Adesc
                Adesc = parseVar(mstr[1:(len(mstr)-1)].split())
            elif i == 6:
            #     #Bdesc
                Bdesc = parseVar(mstr[1:(len(mstr)-1)].split())
            elif i == 7:
            #     #Cdesc
                Cdesc = parseVar(mstr[1:(len(mstr)-1)].split())
            elif i == 8:
            #     #ddesc 
                Ddesc = parseVar(mstr[1:(len(mstr)-1)].split())
            elif i == 9:
            #     #computesdesc
                computes_desc = parseVar(mstr[1:(len(mstr)-1)].split())
            
            i = i + 1

        transA = computes_desc["transA"][3]
        transB = computes_desc["transB"][3]
        a_type = convertType(Adesc["type"])
        b_type = convertType(Bdesc["type"])
        c_type = convertType(Cdesc["type"])
        d_type = convertType(Ddesc["type"])
        compute_type = convertType(computes_desc["computeType"])
        scale_type = convertType(computes_desc["scaleType"])

        print(f"- {{function: matmul, transA: {transA}, transB: {transB}, a_type: {a_type}, b_type: {b_type}, c_type: {c_type}, d_type: {d_type}, compute_type: c_{compute_type}, scale_type: {scale_type}, M: {Cdesc["rows"]}, N: {Cdesc["cols"]}, K: {Cdesc["ld"]}, ldc: {Cdesc["ld"]}, ldd: {Ddesc["ld"]}, lda: {Adesc["ld"]}, ldb: {Bdesc["ld"]}, initialization: rand_int, alpha: {alpha_beta["alpha"]}, beta: {alpha_beta["beta"]}, iters: 10, cold_iters: 2}}")
